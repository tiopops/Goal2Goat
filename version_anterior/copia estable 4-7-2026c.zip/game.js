

/* ── Ticket translation helper — accesses TRANSLATIONS directly for reliability ── */
function tk(key){
  const e=window.TRANSLATIONS&&window.TRANSLATIONS[key];
  return e?(e[window.LANG||'es']||e['es']||key):key;
}

function flagAsset(name){
const n=name.toLowerCase();
// Special non-ISO flags (England/Scotland/Wales, historical countries)
const special={
'inglaterra':'gb-eng','escocia':'gb-sct','gales':'gb-wls',
'yugoslavia':'rs','checoslovaquia':'cz'
};
for(const k in special){ if(n.includes(k)) return special[k]; }
const map={
'españa':'es','brasil':'br','francia':'fr','alemania':'de',
'polonia':'pl','croacia':'hr','serbia':'rs',
'holanda':'nl','argentina':'ar','italia':'it',
'portugal':'pt','uruguay':'uy','bélgica':'be','belgica':'be',
'austria':'at','camerún':'cm','camerun':'cm',
'chile':'cl','colombia':'co',
'dinamarca':'dk','corea del sur':'kr','estados unidos':'us',
'grecia':'gr','hungría':'hu','hungria':'hu',
'irlanda':'ie','japón':'jp','japon':'jp','marruecos':'ma',
'méxico':'mx','mexico':'mx','nigeria':'ng','noruega':'no',
'paraguay':'py','perú':'pe','peru':'pe','rumanía':'ro','rumania':'ro',
'rusia':'ru','suecia':'se','suiza':'ch','turquía':'tr','turquia':'tr',
'ucrania':'ua','senegal':'sn','costa rica':'cr','ghana':'gh'
};
for (const k in map){ if(n.includes(k)) return map[k]; }
return 'un';
}

function flagEmoji(name, size){
  const cc = flagAsset(name);
  const w = size||40;
  return `<img class="flag-emoji" src="https://flagcdn.com/w80/${cc}.png" srcset="https://flagcdn.com/w160/${cc}.png 2x" alt="${name}" title="${name}" style="width:${w}px;height:auto;display:inline-block;vertical-align:middle;border-radius:2px;box-shadow:0 0 0 1px rgba(0,0,0,.1)">`;
}

let playersDB = [{"id": "p_1_0", "name": "Iker Casillas", "positions": ["POR"], "overall": 91}, {"id": "p_1_1", "name": "Sergio Ramos", "positions": ["DFC"], "overall": 86}, {"id": "p_1_2", "name": "Gerard Piqué", "positions": ["DFC"], "overall": 86}, {"id": "p_1_3", "name": "Carles Puyol", "positions": ["DFC"], "overall": 85}, {"id": "p_1_4", "name": "Joan Capdevila", "positions": ["LI", "DFC"], "overall": 80}, {"id": "p_1_5", "name": "Álvaro Arbeloa", "positions": ["LD", "DFC"], "overall": 78}, {"id": "p_1_6", "name": "Xavi Hernández", "positions": ["MC"], "overall": 92}, {"id": "p_1_7", "name": "Andrés Iniesta", "positions": ["MC"], "overall": 93}, {"id": "p_1_8", "name": "Sergio Busquets", "positions": ["MC"], "overall": 83}, {"id": "p_1_9", "name": "Xabi Alonso", "positions": ["MC"], "overall": 87}, {"id": "p_1_10", "name": "Pedro Rodríguez", "positions": ["EI", "ED"], "overall": 84}, {"id": "p_1_11", "name": "David Silva", "positions": ["ED", "EI"], "overall": 87}, {"id": "p_1_12", "name": "David Villa", "positions": ["DC"], "overall": 91}, {"id": "p_1_13", "name": "Fernando Torres", "positions": ["DC"], "overall": 85}, {"id": "p_1_14", "name": "Cesc Fàbregas", "positions": ["DC", "EI"], "overall": 86}, {"id": "p_1_15", "name": "Jesús Navas", "positions": ["ED", "EI"], "overall": 78}, {"id": "p_2_0", "name": "Iker Casillas", "positions": ["POR"], "overall": 90}, {"id": "p_2_1", "name": "Gerard Piqué", "positions": ["DFC"], "overall": 87}, {"id": "p_2_2", "name": "Sergio Ramos", "positions": ["DFC"], "overall": 87}, {"id": "p_2_3", "name": "Carles Puyol", "positions": ["DFC"], "overall": 85}, {"id": "p_2_4", "name": "Jordi Alba", "positions": ["LI", "DFC"], "overall": 84}, {"id": "p_2_5", "name": "Álvaro Arbeloa", "positions": ["LD", "DFC"], "overall": 79}, {"id": "p_2_6", "name": "Xavi Hernández", "positions": ["MC"], "overall": 91}, {"id": "p_2_7", "name": "Andrés Iniesta", "positions": ["MC"], "overall": 93}, {"id": "p_2_8", "name": "Sergio Busquets", "positions": ["MC"], "overall": 85}, {"id": "p_2_9", "name": "Xabi Alonso", "positions": ["MC"], "overall": 88}, {"id": "p_2_10", "name": "David Silva", "positions": ["EI", "ED"], "overall": 88}, {"id": "p_2_11", "name": "Jesús Navas", "positions": ["ED", "EI"], "overall": 79}, {"id": "p_2_12", "name": "Fernando Torres", "positions": ["DC"], "overall": 84}, {"id": "p_2_13", "name": "Cesc Fàbregas", "positions": ["DC"], "overall": 87}, {"id": "p_2_14", "name": "Pedro Rodríguez", "positions": ["DC", "EI"], "overall": 83}, {"id": "p_2_15", "name": "David Villa", "positions": ["DC", "ED"], "overall": 88}, {"id": "p_4_0", "name": "Marcos", "positions": ["POR"], "overall": 85}, {"id": "p_4_1", "name": "Lúcio", "positions": ["DFC"], "overall": 86}, {"id": "p_4_2", "name": "Roque Júnior", "positions": ["DFC"], "overall": 78}, {"id": "p_4_3", "name": "Edmílson", "positions": ["DFC"], "overall": 82}, {"id": "p_4_4", "name": "Roberto Carlos", "positions": ["LI", "DFC"], "overall": 90}, {"id": "p_4_5", "name": "Cafu", "positions": ["LD", "DFC"], "overall": 89}, {"id": "p_4_6", "name": "Gilberto Silva", "positions": ["MC"], "overall": 85}, {"id": "p_4_7", "name": "Kléberson", "positions": ["MC"], "overall": 80}, {"id": "p_4_8", "name": "Ronaldinho", "positions": ["EI", "ED"], "overall": 92}, {"id": "p_4_9", "name": "Rivaldo", "positions": ["ED", "EI"], "overall": 91}, {"id": "p_4_10", "name": "Ronaldo Nazário", "positions": ["DC"], "overall": 97}, {"id": "p_4_11", "name": "Edmundo", "positions": ["DC"], "overall": 78}, {"id": "p_4_12", "name": "Luizão", "positions": ["DC", "EI"], "overall": 76}, {"id": "p_4_13", "name": "Denílson", "positions": ["DC", "ED"], "overall": 79}, {"id": "p_4_14", "name": "Juninho Paulista", "positions": ["MC"], "overall": 79}, {"id": "p_4_15", "name": "Edílson", "positions": ["MC"], "overall": 76}, {"id": "p_6_0", "name": "Bodo Illgner", "positions": ["POR"], "overall": 84}, {"id": "p_6_1", "name": "Jürgen Kohler", "positions": ["DFC"], "overall": 86}, {"id": "p_6_2", "name": "Guido Buchwald", "positions": ["DFC"], "overall": 84}, {"id": "p_6_3", "name": "Klaus Augenthaler", "positions": ["DFC"], "overall": 82}, {"id": "p_6_4", "name": "Andreas Brehme", "positions": ["LI", "DFC"], "overall": 87}, {"id": "p_6_5", "name": "Stefan Reuter", "positions": ["LD", "DFC"], "overall": 80}, {"id": "p_6_6", "name": "Lothar Matthäus", "positions": ["MC"], "overall": 93}, {"id": "p_6_7", "name": "Thomas Häßler", "positions": ["MC"], "overall": 85}, {"id": "p_6_8", "name": "Olaf Thon", "positions": ["MC"], "overall": 80}, {"id": "p_6_9", "name": "Pierre Littbarski", "positions": ["MC"], "overall": 81}, {"id": "p_6_10", "name": "Jürgen Klinsmann", "positions": ["EI", "ED"], "overall": 92}, {"id": "p_6_11", "name": "Rudi Völler", "positions": ["ED", "EI"], "overall": 88}, {"id": "p_6_12", "name": "Karl-Heinz Riedle", "positions": ["DC"], "overall": 78}, {"id": "p_6_13", "name": "Uwe Bein", "positions": ["DC"], "overall": 76}, {"id": "p_6_14", "name": "Frank Mill", "positions": ["DC", "EI"], "overall": 74}, {"id": "p_6_15", "name": "Thomas Berthold", "positions": ["DFC", "MC"], "overall": 80}, {"id": "p_7_0", "name": "Manuel Neuer", "positions": ["POR"], "overall": 93}, {"id": "p_7_1", "name": "Mats Hummels", "positions": ["DFC"], "overall": 87}, {"id": "p_7_2", "name": "Jérôme Boateng", "positions": ["DFC"], "overall": 86}, {"id": "p_7_3", "name": "Per Mertesacker", "positions": ["DFC"], "overall": 83}, {"id": "p_7_4", "name": "Benedikt Höwedes", "positions": ["LI", "DFC"], "overall": 81}, {"id": "p_7_5", "name": "Philipp Lahm", "positions": ["LD", "DFC"], "overall": 89}, {"id": "p_7_6", "name": "Bastian Schweinsteiger", "positions": ["MC"], "overall": 88}, {"id": "p_7_7", "name": "Toni Kroos", "positions": ["MC"], "overall": 89}, {"id": "p_7_8", "name": "Sami Khedira", "positions": ["MC"], "overall": 84}, {"id": "p_7_9", "name": "Mesut Özil", "positions": ["EI", "ED"], "overall": 88}, {"id": "p_7_10", "name": "Thomas Müller", "positions": ["ED", "EI"], "overall": 89}, {"id": "p_7_11", "name": "Miroslav Klose", "positions": ["DC"], "overall": 87}, {"id": "p_7_12", "name": "André Schürrle", "positions": ["DC"], "overall": 82}, {"id": "p_7_13", "name": "Mario Götze", "positions": ["DC", "EI"], "overall": 85}, {"id": "p_7_14", "name": "Lukas Podolski", "positions": ["DC", "ED"], "overall": 81}, {"id": "p_7_15", "name": "Christoph Kramer", "positions": ["MC"], "overall": 76}, {"id": "p_8_0", "name": "Nery Pumpido", "positions": ["POR"], "overall": 80}, {"id": "p_8_1", "name": "Oscar Ruggeri", "positions": ["DFC"], "overall": 84}, {"id": "p_8_2", "name": "José Luis Brown", "positions": ["DFC"], "overall": 81}, {"id": "p_8_3", "name": "Néstor Clausen", "positions": ["DFC"], "overall": 76}, {"id": "p_8_4", "name": "Julio Olarticoechea", "positions": ["LI", "DFC"], "overall": 79}, {"id": "p_8_5", "name": "José Luis Cuciuffo", "positions": ["LD", "DFC"], "overall": 78}, {"id": "p_8_6", "name": "Diego Armando Maradona", "positions": ["EI", "MC"], "overall": 98}, {"id": "p_8_7", "name": "Jorge Burruchaga", "positions": ["MC"], "overall": 84}, {"id": "p_8_8", "name": "Sergio Batista", "positions": ["MC"], "overall": 80}, {"id": "p_8_9", "name": "Ricardo Giusti", "positions": ["MC"], "overall": 78}, {"id": "p_8_10", "name": "Jorge Valdano", "positions": ["EI", "ED"], "overall": 86}, {"id": "p_8_11", "name": "Héctor Enrique", "positions": ["MC"], "overall": 76}, {"id": "p_8_12", "name": "Claudio Borghi", "positions": ["MC"], "overall": 76}, {"id": "p_8_13", "name": "Ramón Díaz", "positions": ["DC"], "overall": 78}, {"id": "p_8_14", "name": "Pedro Pasculli", "positions": ["DC"], "overall": 75}, {"id": "p_8_15", "name": "Marcelo Trobbiani", "positions": ["ED", "EI"], "overall": 73}, {"id": "p_9_0", "name": "Emiliano Martínez", "positions": ["POR"], "overall": 88}, {"id": "p_9_1", "name": "Cristian Romero", "positions": ["DFC"], "overall": 85}, {"id": "p_9_2", "name": "Nicolás Otamendi", "positions": ["DFC"], "overall": 82}, {"id": "p_9_3", "name": "Lisandro Martínez", "positions": ["DFC"], "overall": 84}, {"id": "p_9_4", "name": "Nicolás Tagliafico", "positions": ["LI", "DFC"], "overall": 81}, {"id": "p_9_5", "name": "Nahuel Molina", "positions": ["LD", "DFC"], "overall": 80}, {"id": "p_9_6", "name": "Rodrigo De Paul", "positions": ["MC"], "overall": 84}, {"id": "p_9_7", "name": "Enzo Fernández", "positions": ["MC"], "overall": 85}, {"id": "p_9_8", "name": "Alexis Mac Allister", "positions": ["MC"], "overall": 83}, {"id": "p_9_9", "name": "Ángel Di María", "positions": ["EI", "ED"], "overall": 86}, {"id": "p_9_10", "name": "Julián Álvarez", "positions": ["DC", "EI"], "overall": 86}, {"id": "p_9_11", "name": "Lionel Messi", "positions": ["EI", "DC"], "overall": 97}, {"id": "p_9_12", "name": "Lautaro Martínez", "positions": ["DC"], "overall": 86}, {"id": "p_9_13", "name": "Paulo Dybala", "positions": ["DC", "EI"], "overall": 82}, {"id": "p_9_14", "name": "Leandro Paredes", "positions": ["MC"], "overall": 78}, {"id": "p_9_15", "name": "Alejandro Gómez", "positions": ["DC", "ED"], "overall": 77}, {"id": "p_10_0", "name": "Fabien Barthez", "positions": ["POR"], "overall": 87}, {"id": "p_10_1", "name": "Laurent Blanc", "positions": ["DFC"], "overall": 86}, {"id": "p_10_2", "name": "Marcel Desailly", "positions": ["DFC"], "overall": 88}, {"id": "p_10_3", "name": "Lilian Thuram", "positions": ["DFC"], "overall": 87}, {"id": "p_10_4", "name": "Bixente Lizarazu", "positions": ["LI", "DFC"], "overall": 85}, {"id": "p_10_5", "name": "Christian Karembeu", "positions": ["LD", "DFC"], "overall": 79}, {"id": "p_10_6", "name": "Didier Deschamps", "positions": ["MC"], "overall": 84}, {"id": "p_10_7", "name": "Emmanuel Petit", "positions": ["MC"], "overall": 85}, {"id": "p_10_8", "name": "Youri Djorkaeff", "positions": ["MC"], "overall": 86}, {"id": "p_10_9", "name": "Zinedine Zidane", "positions": ["MC", "EI"], "overall": 94}, {"id": "p_10_10", "name": "Thierry Henry", "positions": ["EI", "ED"], "overall": 88}, {"id": "p_10_11", "name": "Robert Pirès", "positions": ["ED", "EI"], "overall": 84}, {"id": "p_10_12", "name": "David Trezeguet", "positions": ["DC"], "overall": 84}, {"id": "p_10_13", "name": "Christophe Dugarry", "positions": ["DC"], "overall": 79}, {"id": "p_10_14", "name": "Patrick Vieira", "positions": ["MC"], "overall": 86}, {"id": "p_10_15", "name": "Stéphane Guivarc'h", "positions": ["DC"], "overall": 76}, {"id": "p_11_0", "name": "Hugo Lloris", "positions": ["POR"], "overall": 87}, {"id": "p_11_1", "name": "Raphaël Varane", "positions": ["DFC"], "overall": 88}, {"id": "p_11_2", "name": "Samuel Umtiti", "positions": ["DFC"], "overall": 82}, {"id": "p_11_3", "name": "Lucas Hernández", "positions": ["LI", "DFC"], "overall": 83}, {"id": "p_11_4", "name": "Benjamin Pavard", "positions": ["LD", "DFC"], "overall": 81}, {"id": "p_11_5", "name": "Presnel Kimpembe", "positions": ["DFC"], "overall": 79}, {"id": "p_11_6", "name": "N'Golo Kanté", "positions": ["MC"], "overall": 89}, {"id": "p_11_7", "name": "Paul Pogba", "positions": ["MC"], "overall": 87}, {"id": "p_11_8", "name": "Blaise Matuidi", "positions": ["MC"], "overall": 82}, {"id": "p_11_9", "name": "Kylian Mbappé", "positions": ["EI", "ED"], "overall": 91}, {"id": "p_11_10", "name": "Antoine Griezmann", "positions": ["DC", "EI"], "overall": 90}, {"id": "p_11_11", "name": "Olivier Giroud", "positions": ["DC"], "overall": 84}, {"id": "p_11_12", "name": "Ousmane Dembélé", "positions": ["ED", "EI"], "overall": 81}, {"id": "p_11_13", "name": "Florian Thauvin", "positions": ["ED", "EI"], "overall": 79}, {"id": "p_11_14", "name": "Steven Nzonzi", "positions": ["MC"], "overall": 80}, {"id": "p_11_15", "name": "Corentin Tolisso", "positions": ["MC"], "overall": 78}, {"id": "p_13_0", "name": "Gianluigi Buffon", "positions": ["POR"], "overall": 91}, {"id": "p_13_1", "name": "Fabio Cannavaro", "positions": ["DFC"], "overall": 90}, {"id": "p_13_2", "name": "Alessandro Nesta", "positions": ["DFC"], "overall": 87}, {"id": "p_13_3", "name": "Marco Materazzi", "positions": ["DFC"], "overall": 83}, {"id": "p_13_4", "name": "Fabio Grosso", "positions": ["LI", "DFC"], "overall": 81}, {"id": "p_13_5", "name": "Gianluca Zambrotta", "positions": ["LD", "DFC"], "overall": 84}, {"id": "p_13_6", "name": "Andrea Pirlo", "positions": ["MC"], "overall": 90}, {"id": "p_13_7", "name": "Gennaro Gattuso", "positions": ["MC"], "overall": 84}, {"id": "p_13_8", "name": "Mauro Camoranesi", "positions": ["MC"], "overall": 80}, {"id": "p_13_9", "name": "Francesco Totti", "positions": ["EI", "ED"], "overall": 89}, {"id": "p_13_10", "name": "Luca Toni", "positions": ["ED", "EI"], "overall": 85}, {"id": "p_13_11", "name": "Alessandro Del Piero", "positions": ["DC"], "overall": 88}, {"id": "p_13_12", "name": "Alberto Gilardino", "positions": ["DC"], "overall": 81}, {"id": "p_13_13", "name": "Vincenzo Iaquinta", "positions": ["DC", "EI"], "overall": 77}, {"id": "p_13_14", "name": "Daniele De Rossi", "positions": ["MC"], "overall": 84}, {"id": "p_13_15", "name": "Simone Perrotta", "positions": ["MC"], "overall": 78}, {"id": "p_17_0", "name": "Rui Patrício", "positions": ["POR"], "overall": 84}, {"id": "p_17_1", "name": "Pepe", "positions": ["DFC"], "overall": 84}, {"id": "p_17_2", "name": "José Fonte", "positions": ["DFC"], "overall": 81}, {"id": "p_17_3", "name": "Bruno Alves", "positions": ["DFC"], "overall": 80}, {"id": "p_17_4", "name": "Raphaël Guerreiro", "positions": ["LI", "DFC"], "overall": 81}, {"id": "p_17_5", "name": "Cédric Soares", "positions": ["LD", "DFC"], "overall": 78}, {"id": "p_17_6", "name": "William Carvalho", "positions": ["MC"], "overall": 82}, {"id": "p_17_7", "name": "João Moutinho", "positions": ["MC"], "overall": 83}, {"id": "p_17_8", "name": "Adrien Silva", "positions": ["MC"], "overall": 79}, {"id": "p_17_9", "name": "Renato Sanches", "positions": ["MC"], "overall": 80}, {"id": "p_17_10", "name": "Cristiano Ronaldo", "positions": ["EI", "DC"], "overall": 95}, {"id": "p_17_11", "name": "Nani", "positions": ["ED", "EI"], "overall": 81}, {"id": "p_17_12", "name": "Ricardo Quaresma", "positions": ["ED", "EI"], "overall": 80}, {"id": "p_17_13", "name": "André Silva", "positions": ["DC"], "overall": 76}, {"id": "p_17_14", "name": "João Mário", "positions": ["MC", "ED"], "overall": 78}, {"id": "p_17_15", "name": "Éder", "positions": ["DC"], "overall": 76}, {"id": "p_18_0", "name": "Danijel Subašić", "positions": ["POR"], "overall": 85}, {"id": "p_18_1", "name": "Dejan Lovren", "positions": ["DFC"], "overall": 81}, {"id": "p_18_2", "name": "Domagoj Vida", "positions": ["DFC"], "overall": 80}, {"id": "p_18_3", "name": "Šime Vrsaljko", "positions": ["LD", "DFC"], "overall": 79}, {"id": "p_18_4", "name": "Ivan Strinić", "positions": ["LI", "DFC"], "overall": 77}, {"id": "p_18_5", "name": "Borna Barišić", "positions": ["LI", "DFC"], "overall": 76}, {"id": "p_18_6", "name": "Luka Modrić", "positions": ["MC"], "overall": 93}, {"id": "p_18_7", "name": "Ivan Rakitić", "positions": ["MC"], "overall": 88}, {"id": "p_18_8", "name": "Marcelo Brozović", "positions": ["MC"], "overall": 82}, {"id": "p_18_9", "name": "Ivan Perišić", "positions": ["EI", "ED"], "overall": 86}, {"id": "p_18_10", "name": "Mario Mandžukić", "positions": ["DC"], "overall": 86}, {"id": "p_18_11", "name": "Ante Rebić", "positions": ["ED", "EI"], "overall": 81}, {"id": "p_18_12", "name": "Andrej Kramarić", "positions": ["DC"], "overall": 81}, {"id": "p_18_13", "name": "Milan Badelj", "positions": ["MC"], "overall": 78}, {"id": "p_18_14", "name": "Marko Pjaca", "positions": ["DC", "EI"], "overall": 76}, {"id": "p_18_15", "name": "Nikola Kalinić", "positions": ["DC", "ED"], "overall": 77}, {"id": "p_21_0", "name": "Peter Schmeichel", "positions": ["POR"], "overall": 89}, {"id": "p_21_1", "name": "Lars Olsen", "positions": ["DFC"], "overall": 82}, {"id": "p_21_2", "name": "Kent Nielsen", "positions": ["DFC"], "overall": 77}, {"id": "p_21_3", "name": "Torben Piechnik", "positions": ["DFC"], "overall": 76}, {"id": "p_21_4", "name": "Jan Heintze", "positions": ["LI", "DFC"], "overall": 79}, {"id": "p_21_5", "name": "Kim Christofte", "positions": ["LD", "DFC"], "overall": 75}, {"id": "p_21_6", "name": "John Jensen", "positions": ["MC"], "overall": 80}, {"id": "p_21_7", "name": "Kim Vilfort", "positions": ["MC"], "overall": 83}, {"id": "p_21_8", "name": "Henrik Andersen", "positions": ["MC"], "overall": 78}, {"id": "p_21_9", "name": "Brian Laudrup", "positions": ["EI", "ED"], "overall": 87}, {"id": "p_21_10", "name": "Flemming Povlsen", "positions": ["ED", "EI"], "overall": 81}, {"id": "p_21_11", "name": "Henrik Larsen", "positions": ["DC"], "overall": 83}, {"id": "p_21_12", "name": "Bent Christensen", "positions": ["DC"], "overall": 76}, {"id": "p_21_13", "name": "Lars Elstrup", "positions": ["MC"], "overall": 76}, {"id": "p_21_14", "name": "Peter Rasmussen", "positions": ["DC", "EI"], "overall": 73}, {"id": "p_21_15", "name": "Claus Christiansen", "positions": ["DC", "ED"], "overall": 73}, {"id": "p_22_0", "name": "Thibaut Courtois", "positions": ["POR"], "overall": 89}, {"id": "p_22_1", "name": "Vincent Kompany", "positions": ["DFC"], "overall": 86}, {"id": "p_22_2", "name": "Toby Alderweireld", "positions": ["DFC"], "overall": 84}, {"id": "p_22_3", "name": "Jan Vertonghen", "positions": ["DFC"], "overall": 84}, {"id": "p_22_4", "name": "Thomas Meunier", "positions": ["LD", "DFC"], "overall": 78}, {"id": "p_22_5", "name": "Nacer Chadli", "positions": ["LI", "DFC"], "overall": 78}, {"id": "p_22_6", "name": "Kevin De Bruyne", "positions": ["MC"], "overall": 91}, {"id": "p_22_7", "name": "Axel Witsel", "positions": ["MC"], "overall": 82}, {"id": "p_22_8", "name": "Marouane Fellaini", "positions": ["MC"], "overall": 79}, {"id": "p_22_9", "name": "Eden Hazard", "positions": ["EI", "ED"], "overall": 91}, {"id": "p_22_10", "name": "Romelu Lukaku", "positions": ["DC"], "overall": 87}, {"id": "p_22_11", "name": "Dries Mertens", "positions": ["DC", "EI"], "overall": 82}, {"id": "p_22_12", "name": "Yannick Carrasco", "positions": ["ED", "EI"], "overall": 80}, {"id": "p_22_13", "name": "Mousa Dembélé", "positions": ["MC"], "overall": 80}, {"id": "p_22_14", "name": "Michy Batshuayi", "positions": ["DC"], "overall": 77}, {"id": "p_22_15", "name": "Adnan Januzaj", "positions": ["DC", "ED"], "overall": 76}, {"id": "p_23_0", "name": "Pablo Larios", "positions": ["POR"], "overall": 78}, {"id": "p_23_1", "name": "Fernando Quirarte", "positions": ["DFC"], "overall": 79}, {"id": "p_23_2", "name": "Rafael Amador", "positions": ["DFC"], "overall": 75}, {"id": "p_23_3", "name": "Miguel España", "positions": ["LI", "DFC"], "overall": 75}, {"id": "p_23_4", "name": "Javier López", "positions": ["LD", "DFC"], "overall": 73}, {"id": "p_23_5", "name": "Mario Villa", "positions": ["DFC"], "overall": 73}, {"id": "p_23_6", "name": "Hugo Sánchez", "positions": ["DC"], "overall": 90}, {"id": "p_23_7", "name": "Carlos Hermosillo", "positions": ["DC"], "overall": 75}, {"id": "p_23_8", "name": "Manuel Negrete", "positions": ["MC"], "overall": 81}, {"id": "p_23_9", "name": "Javier Aguirre", "positions": ["MC"], "overall": 78}, {"id": "p_23_10", "name": "Tomás Boy", "positions": ["MC"], "overall": 80}, {"id": "p_23_11", "name": "Luis Flores", "positions": ["EI", "ED"], "overall": 76}, {"id": "p_23_12", "name": "Carlos de los Cobos", "positions": ["MC"], "overall": 74}, {"id": "p_23_13", "name": "Mario Ortiz", "positions": ["DC", "EI"], "overall": 73}, {"id": "p_23_14", "name": "Sergio Lugo", "positions": ["DC", "ED"], "overall": 73}, {"id": "p_23_15", "name": "Javier Hernández sr.", "positions": ["ED", "EI"], "overall": 74}, {"id": "p_24_0", "name": "Brad Friedel", "positions": ["POR"], "overall": 82}, {"id": "p_24_1", "name": "Eddie Pope", "positions": ["DFC"], "overall": 79}, {"id": "p_24_2", "name": "Jeff Agoos", "positions": ["DFC"], "overall": 75}, {"id": "p_24_3", "name": "Gregg Berhalter", "positions": ["DFC"], "overall": 76}, {"id": "p_24_4", "name": "Tony Sanneh", "positions": ["LI", "DFC"], "overall": 75}, {"id": "p_24_5", "name": "Frankie Hejduk", "positions": ["LD", "DFC"], "overall": 76}, {"id": "p_24_6", "name": "Claudio Reyna", "positions": ["MC"], "overall": 84}, {"id": "p_24_7", "name": "John O'Brien", "positions": ["MC"], "overall": 78}, {"id": "p_24_8", "name": "Pablo Mastroeni", "positions": ["MC"], "overall": 75}, {"id": "p_24_9", "name": "Earnie Stewart", "positions": ["MC"], "overall": 77}, {"id": "p_24_10", "name": "Landon Donovan", "positions": ["EI", "ED"], "overall": 84}, {"id": "p_24_11", "name": "DaMarcus Beasley", "positions": ["ED", "EI"], "overall": 79}, {"id": "p_24_12", "name": "Brian McBride", "positions": ["DC"], "overall": 81}, {"id": "p_24_13", "name": "Josh Wolff", "positions": ["DC"], "overall": 75}, {"id": "p_24_14", "name": "Clint Mathis", "positions": ["DC", "EI"], "overall": 77}, {"id": "p_24_15", "name": "Cobi Jones", "positions": ["DC", "ED"], "overall": 76}, {"id": "p_25_0", "name": "Yoshikatsu Kawaguchi", "positions": ["POR"], "overall": 80}, {"id": "p_25_1", "name": "Tsuneyasu Miyamoto", "positions": ["DFC"], "overall": 78}, {"id": "p_25_2", "name": "Naoki Matsuda", "positions": ["DFC"], "overall": 76}, {"id": "p_25_3", "name": "Ryuzo Morioka", "positions": ["DFC"], "overall": 75}, {"id": "p_25_4", "name": "Koji Nakata", "positions": ["LI", "DFC"], "overall": 75}, {"id": "p_25_5", "name": "Hiroaki Morishima", "positions": ["LD", "DFC"], "overall": 74}, {"id": "p_25_6", "name": "Hidetoshi Nakata", "positions": ["MC"], "overall": 86}, {"id": "p_25_7", "name": "Junichi Inamoto", "positions": ["MC"], "overall": 79}, {"id": "p_25_8", "name": "Shinji Ono", "positions": ["MC"], "overall": 81}, {"id": "p_25_9", "name": "Toshiya Fujita", "positions": ["MC"], "overall": 75}, {"id": "p_25_10", "name": "Atsushi Yanagisawa", "positions": ["DC"], "overall": 76}, {"id": "p_25_11", "name": "Naohiro Takahara", "positions": ["DC"], "overall": 76}, {"id": "p_25_12", "name": "Masashi Nakayama", "positions": ["DC", "EI"], "overall": 78}, {"id": "p_25_13", "name": "Shoji Jo", "positions": ["DC", "ED"], "overall": 73}, {"id": "p_25_14", "name": "Akinori Nishizawa", "positions": ["ED", "EI"], "overall": 76}, {"id": "p_25_15", "name": "Teruyoshi Ito", "positions": ["MC"], "overall": 74}, {"id": "p_26_0", "name": "Lee Woon-jae", "positions": ["POR"], "overall": 81}, {"id": "p_26_1", "name": "Hong Myung-bo", "positions": ["DFC"], "overall": 84}, {"id": "p_26_2", "name": "Choi Jin-cheul", "positions": ["DFC"], "overall": 76}, {"id": "p_26_3", "name": "Kim Tae-young", "positions": ["DFC"], "overall": 76}, {"id": "p_26_4", "name": "Lee Young-pyo", "positions": ["LI", "DFC"], "overall": 80}, {"id": "p_26_5", "name": "Song Chong-gug", "positions": ["LD", "DFC"], "overall": 78}, {"id": "p_26_6", "name": "Park Ji-sung", "positions": ["MC"], "overall": 84}, {"id": "p_26_7", "name": "Yoo Sang-chul", "positions": ["MC"], "overall": 81}, {"id": "p_26_8", "name": "Kim Nam-il", "positions": ["MC"], "overall": 77}, {"id": "p_26_9", "name": "Lee Chun-soo", "positions": ["MC"], "overall": 78}, {"id": "p_26_10", "name": "Ahn Jung-hwan", "positions": ["DC"], "overall": 82}, {"id": "p_26_11", "name": "Seol Ki-hyeon", "positions": ["EI", "ED"], "overall": 79}, {"id": "p_26_12", "name": "Hwang Sun-hong", "positions": ["DC"], "overall": 78}, {"id": "p_26_13", "name": "Cha Du-ri", "positions": ["LD", "MC"], "overall": 76}, {"id": "p_26_14", "name": "Kim Do-hoon", "positions": ["DC", "ED"], "overall": 75}, {"id": "p_26_15", "name": "Choi Tae-uk", "positions": ["ED", "EI"], "overall": 75}, {"id": "p_27_0", "name": "Yassine Bounou", "positions": ["POR"], "overall": 86}, {"id": "p_27_1", "name": "Romain Saïss", "positions": ["DFC"], "overall": 80}, {"id": "p_27_2", "name": "Nayef Aguerd", "positions": ["DFC"], "overall": 79}, {"id": "p_27_3", "name": "Achraf Dari", "positions": ["DFC"], "overall": 75}, {"id": "p_27_4", "name": "Noussair Mazraoui", "positions": ["LD", "DFC"], "overall": 80}, {"id": "p_27_5", "name": "Achraf Hakimi", "positions": ["LD", "DFC"], "overall": 86}, {"id": "p_27_6", "name": "Sofyan Amrabat", "positions": ["MC"], "overall": 83}, {"id": "p_27_7", "name": "Azzedine Ounahi", "positions": ["MC"], "overall": 80}, {"id": "p_27_8", "name": "Selim Amallah", "positions": ["MC"], "overall": 75}, {"id": "p_27_9", "name": "Abdelhamid Sabiri", "positions": ["MC"], "overall": 76}, {"id": "p_27_10", "name": "Hakim Ziyech", "positions": ["EI", "ED"], "overall": 84}, {"id": "p_27_11", "name": "Sofiane Boufal", "positions": ["ED", "EI"], "overall": 78}, {"id": "p_27_12", "name": "Youssef En-Nesyri", "positions": ["DC"], "overall": 82}, {"id": "p_27_13", "name": "Abderrazak Hamdallah", "positions": ["DC"], "overall": 75}, {"id": "p_27_14", "name": "Walid Cheddira", "positions": ["DC", "EI"], "overall": 74}, {"id": "p_27_15", "name": "Zakaria Aboukhlal", "positions": ["DC", "ED"], "overall": 75}, {"id": "p_28_0", "name": "Peter Rufai", "positions": ["POR"], "overall": 82}, {"id": "p_28_1", "name": "Uche Okechukwu", "positions": ["DFC"], "overall": 77}, {"id": "p_28_2", "name": "Augustine Eguavoen", "positions": ["DFC"], "overall": 78}, {"id": "p_28_3", "name": "Benedict Iroha", "positions": ["DFC"], "overall": 75}, {"id": "p_28_4", "name": "Chidi Nwanu", "positions": ["LI", "DFC"], "overall": 73}, {"id": "p_28_5", "name": "Mobi Oparaku", "positions": ["LD", "DFC"], "overall": 73}, {"id": "p_28_6", "name": "Jay-Jay Okocha", "positions": ["EI", "ED"], "overall": 87}, {"id": "p_28_7", "name": "Sunday Oliseh", "positions": ["MC"], "overall": 81}, {"id": "p_28_8", "name": "Emmanuel Amunike", "positions": ["MC"], "overall": 82}, {"id": "p_28_9", "name": "Samson Siasia", "positions": ["MC"], "overall": 75}, {"id": "p_28_10", "name": "Mutiu Adepoju", "positions": ["MC"], "overall": 76}, {"id": "p_28_11", "name": "Finidi George", "positions": ["ED", "EI"], "overall": 83}, {"id": "p_28_12", "name": "Rashidi Yekini", "positions": ["DC"], "overall": 85}, {"id": "p_28_13", "name": "Daniel Amokachi", "positions": ["DC"], "overall": 81}, {"id": "p_28_14", "name": "Victor Ikpeba", "positions": ["DC", "EI"], "overall": 79}, {"id": "p_28_15", "name": "Friday Ekpo", "positions": ["DC", "ED"], "overall": 72}, {"id": "p_29_0", "name": "Thomas N'Kono", "positions": ["POR"], "overall": 84}, {"id": "p_29_1", "name": "Stephen Tataw", "positions": ["DFC"], "overall": 78}, {"id": "p_29_2", "name": "Emmanuel Kundé", "positions": ["DFC"], "overall": 78}, {"id": "p_29_3", "name": "Benjamin Massing", "positions": ["DFC"], "overall": 75}, {"id": "p_29_4", "name": "André Kana-Biyik", "positions": ["LI", "DFC"], "overall": 76}, {"id": "p_29_5", "name": "Bertin Ebwellé", "positions": ["LD", "DFC"], "overall": 73}, {"id": "p_29_6", "name": "Roger Milla", "positions": ["DC"], "overall": 86}, {"id": "p_29_7", "name": "François Omam-Biyik", "positions": ["EI", "ED"], "overall": 80}, {"id": "p_29_8", "name": "Cyrille Makanaky", "positions": ["MC"], "overall": 79}, {"id": "p_29_9", "name": "Emile Mbouh", "positions": ["MC"], "overall": 75}, {"id": "p_29_10", "name": "Louis-Paul Mfedé", "positions": ["MC"], "overall": 74}, {"id": "p_29_11", "name": "Victor Ndip Akem", "positions": ["MC"], "overall": 73}, {"id": "p_29_12", "name": "Eugène Ekéké", "positions": ["DC"], "overall": 75}, {"id": "p_29_13", "name": "Jean-Claude Pagal", "positions": ["DC", "EI"], "overall": 73}, {"id": "p_29_14", "name": "Roger Feutmba", "positions": ["DC", "ED"], "overall": 73}, {"id": "p_29_15", "name": "Jules Nyongha", "positions": ["ED", "EI"], "overall": 73}, {"id": "p_31_0", "name": "Justo Villar", "positions": ["POR"], "overall": 82}, {"id": "p_31_1", "name": "Paulo da Silva", "positions": ["DFC"], "overall": 79}, {"id": "p_31_2", "name": "Antolín Alcaraz", "positions": ["DFC"], "overall": 78}, {"id": "p_31_3", "name": "Darío Verón", "positions": ["DFC"], "overall": 75}, {"id": "p_31_4", "name": "Denis Caniza", "positions": ["LI", "DFC"], "overall": 76}, {"id": "p_31_5", "name": "Claudio Morel Rodríguez", "positions": ["LD", "DFC"], "overall": 75}, {"id": "p_31_6", "name": "Roque Santa Cruz", "positions": ["DC"], "overall": 82}, {"id": "p_31_7", "name": "Óscar Cardozo", "positions": ["DC"], "overall": 80}, {"id": "p_31_8", "name": "Cristian Riveros", "positions": ["MC"], "overall": 78}, {"id": "p_31_9", "name": "Víctor Cáceres", "positions": ["MC"], "overall": 76}, {"id": "p_31_10", "name": "Enrique Vera", "positions": ["MC"], "overall": 76}, {"id": "p_31_11", "name": "Edgar Barreto", "positions": ["MC"], "overall": 78}, {"id": "p_31_12", "name": "Nelson Haedo Valdez", "positions": ["EI", "ED"], "overall": 78}, {"id": "p_31_13", "name": "Lucas Barrios", "positions": ["DC", "EI"], "overall": 77}, {"id": "p_31_14", "name": "Edgar Benítez", "positions": ["DC", "EI"], "overall": 75}, {"id": "p_31_15", "name": "Santiago Salcedo", "positions": ["DC", "ED"], "overall": 73}, {"id": "p_32_0", "name": "David Ospina", "positions": ["POR"], "overall": 84}, {"id": "p_32_1", "name": "Mario Yepes", "positions": ["DFC"], "overall": 79}, {"id": "p_32_2", "name": "Cristián Zapata", "positions": ["DFC"], "overall": 78}, {"id": "p_32_3", "name": "Pablo Armero", "positions": ["LI", "DFC"], "overall": 76}, {"id": "p_32_4", "name": "Santiago Arias", "positions": ["LD", "DFC"], "overall": 78}, {"id": "p_32_5", "name": "Éder Álvarez Balanta", "positions": ["DFC"], "overall": 75}, {"id": "p_32_6", "name": "James Rodríguez", "positions": ["EI", "ED"], "overall": 89}, {"id": "p_32_7", "name": "Juan Cuadrado", "positions": ["MC", "ED"], "overall": 82}, {"id": "p_32_8", "name": "Fredy Guarín", "positions": ["MC"], "overall": 80}, {"id": "p_32_9", "name": "Carlos Sánchez", "positions": ["MC"], "overall": 79}, {"id": "p_32_10", "name": "Abel Aguilar", "positions": ["MC"], "overall": 75}, {"id": "p_32_11", "name": "Jackson Martínez", "positions": ["DC"], "overall": 80}, {"id": "p_32_12", "name": "Carlos Bacca", "positions": ["DC"], "overall": 81}, {"id": "p_32_13", "name": "Teófilo Gutiérrez", "positions": ["DC"], "overall": 77}, {"id": "p_32_14", "name": "Juan Fernando Quintero", "positions": ["ED", "EI"], "overall": 78}, {"id": "p_32_15", "name": "Adrián Ramos", "positions": ["DC", "ED"], "overall": 75}, {"id": "p_40_0", "name": "Rüştü Reçber", "positions": ["POR"], "overall": 84}, {"id": "p_40_1", "name": "Alpay Özalan", "positions": ["DFC"], "overall": 80}, {"id": "p_40_2", "name": "Bülent Korkmaz", "positions": ["DFC"], "overall": 78}, {"id": "p_40_3", "name": "Fatih Akyel", "positions": ["DFC"], "overall": 76}, {"id": "p_40_4", "name": "Ümit Davala", "positions": ["LI", "DFC"], "overall": 78}, {"id": "p_40_5", "name": "Ogün Temizkanoğlu", "positions": ["LD", "DFC"], "overall": 73}, {"id": "p_40_6", "name": "Hakan Şükür", "positions": ["DC"], "overall": 84}, {"id": "p_40_7", "name": "Nihat Kahveci", "positions": ["DC"], "overall": 80}, {"id": "p_40_8", "name": "Tugay Kerimoğlu", "positions": ["MC"], "overall": 81}, {"id": "p_40_9", "name": "Emre Belözoğlu", "positions": ["MC"], "overall": 80}, {"id": "p_40_10", "name": "Yıldıray Baştürk", "positions": ["MC"], "overall": 77}, {"id": "p_40_11", "name": "Hasan Şaş", "positions": ["MC"], "overall": 79}, {"id": "p_40_12", "name": "İlhan Mansız", "positions": ["EI", "ED"], "overall": 78}, {"id": "p_40_13", "name": "Ümit Karan", "positions": ["ED", "EI"], "overall": 75}, {"id": "p_40_14", "name": "Tayfun Korkut", "positions": ["DC", "EI"], "overall": 73}, {"id": "p_40_15", "name": "Tayfur Havutçu", "positions": ["DC", "ED"], "overall": 74}, {"id": "p_41_0", "name": "Antonis Nikopolidis", "positions": ["POR"], "overall": 81}, {"id": "p_41_1", "name": "Traianos Dellas", "positions": ["DFC"], "overall": 80}, {"id": "p_41_2", "name": "Michalis Kapsis", "positions": ["DFC"], "overall": 76}, {"id": "p_41_3", "name": "Takis Fyssas", "positions": ["LI", "DFC"], "overall": 76}, {"id": "p_41_4", "name": "Giourkas Seitaridis", "positions": ["LD", "DFC"], "overall": 78}, {"id": "p_41_5", "name": "Stelios Venetidis", "positions": ["LD", "DFC"], "overall": 73}, {"id": "p_41_6", "name": "Theodoros Zagorakis", "positions": ["MC"], "overall": 82}, {"id": "p_41_7", "name": "Kostas Katsouranis", "positions": ["MC"], "overall": 78}, {"id": "p_41_8", "name": "Angelos Basinas", "positions": ["MC"], "overall": 78}, {"id": "p_41_9", "name": "Stylianos Giannakopoulos", "positions": ["MC"], "overall": 75}, {"id": "p_41_10", "name": "Giorgos Karagounis", "positions": ["MC", "ED"], "overall": 79}, {"id": "p_41_11", "name": "Angelos Charisteas", "positions": ["DC"], "overall": 81}, {"id": "p_41_12", "name": "Demis Nikolaidis", "positions": ["DC"], "overall": 77}, {"id": "p_41_13", "name": "Zisis Vryzas", "positions": ["EI", "ED"], "overall": 75}, {"id": "p_41_14", "name": "Vassilios Tsiartas", "positions": ["EI", "ED"], "overall": 76}, {"id": "p_41_15", "name": "Vassilis Lakis", "positions": ["DC", "EI"], "overall": 72}, {"id": "p_42_0", "name": "Florin Prunea", "positions": ["POR"], "overall": 79}, {"id": "p_42_1", "name": "Gheorghe Popescu", "positions": ["DFC"], "overall": 82}, {"id": "p_42_2", "name": "Miodrag Belodedici", "positions": ["DFC"], "overall": 80}, {"id": "p_42_3", "name": "Daniel Prodan", "positions": ["DFC"], "overall": 75}, {"id": "p_42_4", "name": "Dan Petrescu", "positions": ["LD", "DFC"], "overall": 80}, {"id": "p_42_5", "name": "Ioan Lupescu", "positions": ["LI", "DFC"], "overall": 78}, {"id": "p_42_6", "name": "Gheorghe Hagi", "positions": ["MC", "EI"], "overall": 89}, {"id": "p_42_7", "name": "Ilie Dumitrescu", "positions": ["MC"], "overall": 80}, {"id": "p_42_8", "name": "Tibor Selymes", "positions": ["MC"], "overall": 75}, {"id": "p_42_9", "name": "Cristian Dulca", "positions": ["MC"], "overall": 73}, {"id": "p_42_10", "name": "Florin Răducioiu", "positions": ["EI", "ED"], "overall": 79}, {"id": "p_42_11", "name": "Adrian Ilie", "positions": ["ED", "EI"], "overall": 76}, {"id": "p_42_12", "name": "Dorinel Munteanu", "positions": ["MC"], "overall": 76}, {"id": "p_42_13", "name": "Viorel Moldovan", "positions": ["DC"], "overall": 76}, {"id": "p_42_14", "name": "Gheorghe Craioveanu", "positions": ["DC", "ED"], "overall": 73}, {"id": "p_42_15", "name": "Ioan Vlădoiu", "positions": ["DC"], "overall": 73}, {"id": "p_43_0", "name": "Packie Bonner", "positions": ["POR"], "overall": 82}, {"id": "p_43_1", "name": "Paul McGrath", "positions": ["DFC"], "overall": 85}, {"id": "p_43_2", "name": "Mick McCarthy", "positions": ["DFC"], "overall": 76}, {"id": "p_43_3", "name": "Kevin Moran", "positions": ["DFC"], "overall": 78}, {"id": "p_43_4", "name": "Steve Staunton", "positions": ["LI", "DFC"], "overall": 77}, {"id": "p_43_5", "name": "Chris Morris", "positions": ["LD", "DFC"], "overall": 74}, {"id": "p_43_6", "name": "Liam Brady", "positions": ["MC"], "overall": 81}, {"id": "p_43_7", "name": "Andy Townsend", "positions": ["MC"], "overall": 78}, {"id": "p_43_8", "name": "Ray Houghton", "positions": ["MC"], "overall": 79}, {"id": "p_43_9", "name": "Ronnie Whelan", "positions": ["MC"], "overall": 78}, {"id": "p_43_10", "name": "Kevin Sheedy", "positions": ["ED", "EI"], "overall": 78}, {"id": "p_43_11", "name": "John Aldridge", "positions": ["DC"], "overall": 78}, {"id": "p_43_12", "name": "Niall Quinn", "positions": ["DC"], "overall": 78}, {"id": "p_43_13", "name": "Tony Cascarino", "positions": ["DC"], "overall": 76}, {"id": "p_43_14", "name": "David O'Leary", "positions": ["DFC", "MC"], "overall": 77}, {"id": "p_43_15", "name": "David Kelly", "positions": ["DC", "ED"], "overall": 73}, {"id": "p_46_0", "name": "Igor Akinfeev", "positions": ["POR"], "overall": 83}, {"id": "p_46_1", "name": "Sergei Ignashevich", "positions": ["DFC"], "overall": 78}, {"id": "p_46_2", "name": "Ilya Kutepov", "positions": ["DFC"], "overall": 74}, {"id": "p_46_3", "name": "Andrei Semyonov", "positions": ["DFC"], "overall": 73}, {"id": "p_46_4", "name": "Yuri Zhirkov", "positions": ["LI", "DFC"], "overall": 78}, {"id": "p_46_5", "name": "Mário Fernandes", "positions": ["LD", "DFC"], "overall": 76}, {"id": "p_46_6", "name": "Aleksandr Golovin", "positions": ["MC"], "overall": 81}, {"id": "p_46_7", "name": "Roman Zobnin", "positions": ["MC"], "overall": 77}, {"id": "p_46_8", "name": "Alan Dzagoev", "positions": ["MC"], "overall": 76}, {"id": "p_46_9", "name": "Daler Kuzyaev", "positions": ["MC"], "overall": 75}, {"id": "p_46_10", "name": "Denis Cheryshev", "positions": ["EI", "ED"], "overall": 79}, {"id": "p_46_11", "name": "Aleksandr Samedov", "positions": ["ED", "EI"], "overall": 74}, {"id": "p_46_12", "name": "Artem Dzyuba", "positions": ["DC"], "overall": 79}, {"id": "p_46_13", "name": "Fedor Smolov", "positions": ["DC"], "overall": 76}, {"id": "p_46_14", "name": "Anton Miranchuk", "positions": ["DC", "EI"], "overall": 74}, {"id": "p_46_15", "name": "Yuri Gazinsky", "positions": ["DC", "ED"], "overall": 72}, {"id": "p_47_0", "name": "Oleksandr Shovkovskiy", "positions": ["POR"], "overall": 81}, {"id": "p_47_1", "name": "Vladislav Vashchuk", "positions": ["DFC"], "overall": 76}, {"id": "p_47_2", "name": "Andriy Nesmachniy", "positions": ["DFC"], "overall": 75}, {"id": "p_47_3", "name": "Vyacheslav Sviderskyi", "positions": ["DFC"], "overall": 75}, {"id": "p_47_4", "name": "Andriy Husin", "positions": ["LI", "DFC"], "overall": 75}, {"id": "p_47_5", "name": "Bohdan Shust", "positions": ["LD", "DFC"], "overall": 72}, {"id": "p_47_6", "name": "Andriy Shevchenko", "positions": ["DC"], "overall": 88}, {"id": "p_47_7", "name": "Anatoliy Tymoshchuk", "positions": ["MC"], "overall": 84}, {"id": "p_47_8", "name": "Serhiy Rebrov", "positions": ["MC", "EI"], "overall": 80}, {"id": "p_47_9", "name": "Oleh Husyev", "positions": ["MC"], "overall": 76}, {"id": "p_47_10", "name": "Ruslan Rotan", "positions": ["MC"], "overall": 75}, {"id": "p_47_11", "name": "Andriy Voronin", "positions": ["EI", "ED"], "overall": 79}, {"id": "p_47_12", "name": "Maksym Kalynychenko", "positions": ["ED", "EI"], "overall": 76}, {"id": "p_47_13", "name": "Artem Milevskyi", "positions": ["DC"], "overall": 75}, {"id": "p_47_14", "name": "Andriy Vorobei", "positions": ["DC", "EI"], "overall": 73}, {"id": "p_47_15", "name": "Yevhen Levchenko", "positions": ["DC", "ED"], "overall": 72}, {"id": "p_48_0", "name": "Vladimir Stojković", "positions": ["POR"], "overall": 78}, {"id": "p_48_1", "name": "Nemanja Vidić", "positions": ["DFC"], "overall": 87}, {"id": "p_48_2", "name": "Branislav Ivanović", "positions": ["DFC", "LD"], "overall": 84}, {"id": "p_48_3", "name": "Aleksandar Luković", "positions": ["DFC"], "overall": 75}, {"id": "p_48_4", "name": "Neven Subotić", "positions": ["LI", "DFC"], "overall": 78}, {"id": "p_48_5", "name": "Ivan Obradović", "positions": ["LD", "DFC"], "overall": 73}, {"id": "p_48_6", "name": "Dejan Stanković", "positions": ["MC"], "overall": 82}, {"id": "p_48_7", "name": "Zdravko Kuzmanović", "positions": ["MC"], "overall": 75}, {"id": "p_48_8", "name": "Miloš Krasić", "positions": ["MC", "ED"], "overall": 79}, {"id": "p_48_9", "name": "Gojko Kačar", "positions": ["MC"], "overall": 73}, {"id": "p_48_10", "name": "Milan Jovanović", "positions": ["EI", "ED"], "overall": 78}, {"id": "p_48_11", "name": "Zoran Tošić", "positions": ["ED", "EI"], "overall": 76}, {"id": "p_48_12", "name": "Marko Pantelić", "positions": ["DC"], "overall": 76}, {"id": "p_48_13", "name": "Nikola Žigić", "positions": ["DC"], "overall": 78}, {"id": "p_48_14", "name": "Danko Lazović", "positions": ["DC", "EI"], "overall": 75}, {"id": "p_48_15", "name": "Milan Smiljanić", "positions": ["DC", "ED"], "overall": 72}, {"id": "p_49_0", "name": "Frode Grodås", "positions": ["POR"], "overall": 78}, {"id": "p_49_1", "name": "Ronny Johnsen", "positions": ["DFC"], "overall": 81}, {"id": "p_49_2", "name": "Henning Berg", "positions": ["DFC"], "overall": 80}, {"id": "p_49_3", "name": "Dan Eggen", "positions": ["DFC"], "overall": 73}, {"id": "p_49_4", "name": "Gunnar Halle", "positions": ["LD", "DFC"], "overall": 74}, {"id": "p_49_5", "name": "Erland Johnsen", "positions": ["LI", "DFC"], "overall": 75}, {"id": "p_49_6", "name": "Ole Gunnar Solskjær", "positions": ["DC"], "overall": 82}, {"id": "p_49_7", "name": "Tore André Flo", "positions": ["DC"], "overall": 81}, {"id": "p_49_8", "name": "Kjetil Rekdal", "positions": ["MC"], "overall": 76}, {"id": "p_49_9", "name": "Øyvind Leonhardsen", "positions": ["MC"], "overall": 76}, {"id": "p_49_10", "name": "Stig Inge Bjørnebye", "positions": ["LI", "MC"], "overall": 76}, {"id": "p_49_11", "name": "Erik Mykland", "positions": ["MC"], "overall": 74}, {"id": "p_49_12", "name": "Jostein Flo", "positions": ["EI", "DC"], "overall": 75}, {"id": "p_49_13", "name": "Steffen Iversen", "positions": ["DC", "EI"], "overall": 76}, {"id": "p_49_14", "name": "Egil Østenstad", "positions": ["DC", "EI"], "overall": 73}, {"id": "p_49_15", "name": "Håvard Flo", "positions": ["DC", "ED"], "overall": 72}, {"id": "p_team_brasil_1982_0", "name": "Waldir Peres", "positions": ["POR"], "overall": 82}, {"id": "p_team_brasil_1982_1", "name": "Leandro", "positions": ["LD"], "overall": 84}, {"id": "p_team_brasil_1982_2", "name": "Oscar", "positions": ["DFC"], "overall": 83}, {"id": "p_team_brasil_1982_3", "name": "Luízinho", "positions": ["DFC"], "overall": 82}, {"id": "p_team_brasil_1982_4", "name": "Junior", "positions": ["LI"], "overall": 85}, {"id": "p_team_brasil_1982_5", "name": "Toninho Cerezo", "positions": ["MC"], "overall": 85}, {"id": "p_team_brasil_1982_6", "name": "Falcão", "positions": ["MC"], "overall": 92}, {"id": "p_team_brasil_1982_7", "name": "Sócrates", "positions": ["EI", "MC"], "overall": 93}, {"id": "p_team_brasil_1982_8", "name": "Zico", "positions": ["EI", "DC"], "overall": 94}, {"id": "p_team_brasil_1982_9", "name": "Éder", "positions": ["EI"], "overall": 87}, {"id": "p_team_brasil_1982_10", "name": "Paulo Isidoro", "positions": ["ED"], "overall": 83}, {"id": "p_team_brasil_1982_11", "name": "Serginho", "positions": ["DC"], "overall": 82}, {"id": "p_team_brasil_1982_12", "name": "Batista", "positions": ["DFC", "MC"], "overall": 80}, {"id": "p_team_brasil_1982_13", "name": "Dirceu", "positions": ["MC", "EI"], "overall": 84}, {"id": "p_team_brasil_1982_14", "name": "Reinaldo", "positions": ["DC"], "overall": 82}, {"id": "p_team_brasil_1982_15", "name": "Paulo Roberto", "positions": ["MC"], "overall": 83}, {"id": "p_team_argentina_1978_0", "name": "Ubaldo Fillol", "positions": ["POR"], "overall": 86}, {"id": "p_team_argentina_1978_1", "name": "Jorge Olguín", "positions": ["LD"], "overall": 82}, {"id": "p_team_argentina_1978_2", "name": "Daniel Passarella", "positions": ["DFC"], "overall": 90}, {"id": "p_team_argentina_1978_3", "name": "Luis Galván", "positions": ["DFC"], "overall": 82}, {"id": "p_team_argentina_1978_4", "name": "Alberto Tarantini", "positions": ["LI"], "overall": 81}, {"id": "p_team_argentina_1978_5", "name": "Omar Larrosa", "positions": ["MC"], "overall": 82}, {"id": "p_team_argentina_1978_6", "name": "Américo Gallego", "positions": ["MC"], "overall": 83}, {"id": "p_team_argentina_1978_7", "name": "Osvaldo Ardiles", "positions": ["MC"], "overall": 87}, {"id": "p_team_argentina_1978_8", "name": "Leopoldo Luque", "positions": ["DC"], "overall": 85}, {"id": "p_team_argentina_1978_9", "name": "Mario Kempes", "positions": ["DC", "EI"], "overall": 93}, {"id": "p_team_argentina_1978_10", "name": "René Houseman", "positions": ["ED"], "overall": 84}, {"id": "p_team_argentina_1978_11", "name": "Norberto Alonso", "positions": ["EI", "MC"], "overall": 83}, {"id": "p_team_argentina_1978_12", "name": "Ricardo Villa", "positions": ["MC"], "overall": 82}, {"id": "p_team_argentina_1978_13", "name": "Daniel Bertoni", "positions": ["ED"], "overall": 83}, {"id": "p_team_argentina_1978_14", "name": "Hugo Gatti", "positions": ["POR"], "overall": 82}, {"id": "p_team_argentina_1978_15", "name": "Jorge Carrascosa", "positions": ["MC"], "overall": 80}, {"id": "p_team_holanda_1988_0", "name": "Hans van Breukelen", "positions": ["POR"], "overall": 84}, {"id": "p_team_holanda_1988_1", "name": "Berry van Aerle", "positions": ["LD"], "overall": 82}, {"id": "p_team_holanda_1988_2", "name": "Ronald Koeman", "positions": ["DFC"], "overall": 90}, {"id": "p_team_holanda_1988_3", "name": "Adri van Tiggelen", "positions": ["DFC"], "overall": 82}, {"id": "p_team_holanda_1988_4", "name": "Jan Wouters", "positions": ["MC", "DFC"], "overall": 84}, {"id": "p_team_holanda_1988_5", "name": "Gerald Vanenburg", "positions": ["MC"], "overall": 83}, {"id": "p_team_holanda_1988_6", "name": "Ruud Gullit", "positions": ["DC", "EI"], "overall": 95}, {"id": "p_team_holanda_1988_7", "name": "Frank Rijkaard", "positions": ["MC"], "overall": 91}, {"id": "p_team_holanda_1988_8", "name": "Marco van Basten", "positions": ["DC"], "overall": 96}, {"id": "p_team_holanda_1988_9", "name": "John van 't Schip", "positions": ["EI", "MC"], "overall": 84}, {"id": "p_team_holanda_1988_10", "name": "Rob Witschge", "positions": ["MC"], "overall": 82}, {"id": "p_team_holanda_1988_11", "name": "Wim Kieft", "positions": ["DC"], "overall": 83}, {"id": "p_team_holanda_1988_12", "name": "Hans Gillhaus", "positions": ["EI", "DC"], "overall": 82}, {"id": "p_team_holanda_1988_13", "name": "Arnold Mühren", "positions": ["MC"], "overall": 84}, {"id": "p_team_holanda_1988_14", "name": "Erwin Koeman", "positions": ["LD", "MC"], "overall": 83}, {"id": "p_team_holanda_1988_15", "name": "Peter Boeve", "positions": ["DFC"], "overall": 80}, {"id": "p_team_senegal_2002_0", "name": "Tony Sylva", "positions": ["POR"], "overall": 82}, {"id": "p_team_senegal_2002_1", "name": "Lamine Diatta", "positions": ["DFC"], "overall": 82}, {"id": "p_team_senegal_2002_2", "name": "Ferdinand Coly", "positions": ["LD"], "overall": 83}, {"id": "p_team_senegal_2002_3", "name": "Pape Bouba Diop", "positions": ["DFC"], "overall": 82}, {"id": "p_team_senegal_2002_4", "name": "Omar Daf", "positions": ["LI"], "overall": 81}, {"id": "p_team_senegal_2002_5", "name": "Khalilou Fadiga", "positions": ["MC"], "overall": 84}, {"id": "p_team_senegal_2002_6", "name": "Aliou Cissé", "positions": ["MC"], "overall": 82}, {"id": "p_team_senegal_2002_7", "name": "El Hadji Diouf", "positions": ["DC", "EI"], "overall": 86}, {"id": "p_team_senegal_2002_8", "name": "Salif Diao", "positions": ["MC"], "overall": 83}, {"id": "p_team_senegal_2002_9", "name": "Henri Camara", "positions": ["DC"], "overall": 84}, {"id": "p_team_senegal_2002_10", "name": "Souleymane Camara", "positions": ["DC"], "overall": 81}, {"id": "p_team_senegal_2002_11", "name": "Habib Beye", "positions": ["LD", "MC"], "overall": 82}, {"id": "p_team_senegal_2002_12", "name": "Mamadou Niang", "positions": ["DC"], "overall": 82}, {"id": "p_team_senegal_2002_13", "name": "Amdy Faye", "positions": ["MC"], "overall": 81}, {"id": "p_team_senegal_2002_14", "name": "Moussa N'Diaye", "positions": ["EI"], "overall": 81}, {"id": "p_team_senegal_2002_15", "name": "Pape Thiaw", "positions": ["DFC", "MC"], "overall": 80}, {"id": "p_team_costa_rica_2014_0", "name": "Keylor Navas", "positions": ["POR"], "overall": 90}, {"id": "p_team_costa_rica_2014_1", "name": "Michael Umaña", "positions": ["DFC"], "overall": 81}, {"id": "p_team_costa_rica_2014_2", "name": "Óscar Duarte", "positions": ["DFC"], "overall": 82}, {"id": "p_team_costa_rica_2014_3", "name": "Giancarlo González", "positions": ["DFC"], "overall": 81}, {"id": "p_team_costa_rica_2014_4", "name": "Junior Díaz", "positions": ["LI"], "overall": 80}, {"id": "p_team_costa_rica_2014_5", "name": "David Myrie", "positions": ["LD"], "overall": 79}, {"id": "p_team_costa_rica_2014_6", "name": "Bryan Ruiz", "positions": ["MC", "EI"], "overall": 84}, {"id": "p_team_costa_rica_2014_7", "name": "Yeltsin Tejeda", "positions": ["MC"], "overall": 80}, {"id": "p_team_costa_rica_2014_8", "name": "Celso Borges", "positions": ["MC"], "overall": 82}, {"id": "p_team_costa_rica_2014_9", "name": "Joel Campbell", "positions": ["EI", "DC"], "overall": 83}, {"id": "p_team_costa_rica_2014_10", "name": "Marco Ureña", "positions": ["DC"], "overall": 80}, {"id": "p_team_costa_rica_2014_11", "name": "José Miguel Cubero", "positions": ["DFC", "MC"], "overall": 80}, {"id": "p_team_costa_rica_2014_12", "name": "Álvaro Saborío", "positions": ["DC"], "overall": 81}, {"id": "p_team_costa_rica_2014_13", "name": "Johnny Acosta", "positions": ["DFC"], "overall": 79}, {"id": "p_team_costa_rica_2014_14", "name": "Diego Calvo", "positions": ["LD"], "overall": 78}, {"id": "p_team_costa_rica_2014_15", "name": "Randall Brenes", "positions": ["MC"], "overall": 79}, {"id": "p_team_ghana_2010_0", "name": "Richard Kingson", "positions": ["POR"], "overall": 81}, {"id": "p_team_ghana_2010_1", "name": "Hans Sarpei", "positions": ["LI"], "overall": 80}, {"id": "p_team_ghana_2010_2", "name": "John Mensah", "positions": ["DFC"], "overall": 83}, {"id": "p_team_ghana_2010_3", "name": "Jonathan Mensah", "positions": ["DFC"], "overall": 80}, {"id": "p_team_ghana_2010_4", "name": "Samuel Inkoom", "positions": ["LD"], "overall": 80}, {"id": "p_team_ghana_2010_5", "name": "Anthony Annan", "positions": ["MC"], "overall": 81}, {"id": "p_team_ghana_2010_6", "name": "Kevin-Prince Boateng", "positions": ["MC", "EI"], "overall": 85}, {"id": "p_team_ghana_2010_7", "name": "Kwadwo Asamoah", "positions": ["MC", "LI"], "overall": 84}, {"id": "p_team_ghana_2010_8", "name": "Sulley Muntari", "positions": ["MC"], "overall": 83}, {"id": "p_team_ghana_2010_9", "name": "Asamoah Gyan", "positions": ["DC"], "overall": 87}, {"id": "p_team_ghana_2010_10", "name": "André Ayew", "positions": ["EI", "DC"], "overall": 84}, {"id": "p_team_ghana_2010_11", "name": "John Paintsil", "positions": ["LD"], "overall": 80}, {"id": "p_team_ghana_2010_12", "name": "Dominic Adiyiah", "positions": ["DC"], "overall": 80}, {"id": "p_team_ghana_2010_13", "name": "Stephen Appiah", "positions": ["MC"], "overall": 83}, {"id": "p_team_ghana_2010_14", "name": "Laryea Kingston", "positions": ["MC", "EI"], "overall": 80}, {"id": "p_team_ghana_2010_15", "name": "Jordan Ayew", "positions": ["EI", "DC"], "overall": 82}, {"id": "p_team_uruguay_2010_0", "name": "Fernando Muslera", "positions": ["POR"], "overall": 85}, {"id": "p_team_uruguay_2010_1", "name": "Maxi Pereira", "positions": ["LD"], "overall": 82}, {"id": "p_team_uruguay_2010_2", "name": "Diego Lugano", "positions": ["DFC"], "overall": 84}, {"id": "p_team_uruguay_2010_3", "name": "Diego Godín", "positions": ["DFC"], "overall": 90}, {"id": "p_team_uruguay_2010_4", "name": "Jorge Fucile", "positions": ["LI"], "overall": 80}, {"id": "p_team_uruguay_2010_5", "name": "Álvaro Pereira", "positions": ["LI", "MC"], "overall": 82}, {"id": "p_team_uruguay_2010_6", "name": "Egidio Arévalo Ríos", "positions": ["MC"], "overall": 81}, {"id": "p_team_uruguay_2010_7", "name": "Diego Pérez", "positions": ["DFC", "MC"], "overall": 80}, {"id": "p_team_uruguay_2010_8", "name": "Edinson Cavani", "positions": ["DC", "EI"], "overall": 91}, {"id": "p_team_uruguay_2010_9", "name": "Luis Suárez", "positions": ["DC"], "overall": 94}, {"id": "p_team_uruguay_2010_10", "name": "Diego Forlán", "positions": ["DC", "EI"], "overall": 90}, {"id": "p_team_uruguay_2010_11", "name": "Sebastián Abreu", "positions": ["DC"], "overall": 80}, {"id": "p_team_uruguay_2010_12", "name": "Andrés Scotti", "positions": ["DFC"], "overall": 79}, {"id": "p_team_uruguay_2010_13", "name": "Nicolás Lodeiro", "positions": ["MC", "EI"], "overall": 82}, {"id": "p_team_uruguay_2010_14", "name": "Sebastián Eguren", "positions": ["MC"], "overall": 80}, {"id": "p_team_uruguay_2010_15", "name": "Carlos Bueno", "positions": ["DC"], "overall": 79}, {"id": "p_team_suecia_1994_0", "name": "Thomas Ravelli", "positions": ["POR"], "overall": 85}, {"id": "p_team_suecia_1994_1", "name": "Roland Nilsson", "positions": ["LD"], "overall": 83}, {"id": "p_team_suecia_1994_2", "name": "Patrik Andersson", "positions": ["DFC"], "overall": 82}, {"id": "p_team_suecia_1994_3", "name": "Joachim Björklund", "positions": ["DFC"], "overall": 81}, {"id": "p_team_suecia_1994_4", "name": "Pontus Kåmark", "positions": ["DFC"], "overall": 80}, {"id": "p_team_suecia_1994_5", "name": "Klas Ingesson", "positions": ["MC"], "overall": 82}, {"id": "p_team_suecia_1994_6", "name": "Jonas Thern", "positions": ["MC"], "overall": 83}, {"id": "p_team_suecia_1994_7", "name": "Stefan Schwarz", "positions": ["MC"], "overall": 83}, {"id": "p_team_suecia_1994_8", "name": "Kennet Andersson", "positions": ["DC"], "overall": 82}, {"id": "p_team_suecia_1994_9", "name": "Henrik Larsson", "positions": ["DC", "EI"], "overall": 88}, {"id": "p_team_suecia_1994_10", "name": "Martin Dahlin", "positions": ["DC"], "overall": 85}, {"id": "p_team_suecia_1994_11", "name": "Tomas Brolin", "positions": ["EI", "DC"], "overall": 86}, {"id": "p_team_suecia_1994_12", "name": "Håkan Mild", "positions": ["MC"], "overall": 81}, {"id": "p_team_suecia_1994_13", "name": "Jesper Blomqvist", "positions": ["EI"], "overall": 82}, {"id": "p_team_suecia_1994_14", "name": "Jan Eriksson", "positions": ["DFC"], "overall": 79}, {"id": "p_team_suecia_1994_15", "name": "Niklas Alexandersson", "positions": ["LD", "MC"], "overall": 80}, {"id": "p_team_holanda_1988_0", "name": "Hans van Breukelen", "positions": ["POR"], "overall": 84}, {"id": "p_team_holanda_1988_1", "name": "Berry van Aerle", "positions": ["LD"], "overall": 82}, {"id": "p_team_holanda_1988_2", "name": "Ronald Koeman", "positions": ["DFC"], "overall": 90}, {"id": "p_team_holanda_1988_3", "name": "Adri van Tiggelen", "positions": ["DFC"], "overall": 82}, {"id": "p_team_holanda_1988_4", "name": "Jan Wouters", "positions": ["MC", "DFC"], "overall": 84}, {"id": "p_team_holanda_1988_5", "name": "Gerald Vanenburg", "positions": ["MC"], "overall": 83}, {"id": "p_team_holanda_1988_6", "name": "Ruud Gullit", "positions": ["DC", "EI"], "overall": 95}, {"id": "p_team_holanda_1988_7", "name": "Frank Rijkaard", "positions": ["MC"], "overall": 91}, {"id": "p_team_holanda_1988_8", "name": "Marco van Basten", "positions": ["DC"], "overall": 96}, {"id": "p_team_holanda_1988_9", "name": "John van 't Schip", "positions": ["EI", "MC"], "overall": 84}, {"id": "p_team_holanda_1988_10", "name": "Rob Witschge", "positions": ["MC"], "overall": 82}, {"id": "p_team_holanda_1988_11", "name": "Wim Kieft", "positions": ["DC"], "overall": 83}, {"id": "p_team_holanda_1988_12", "name": "Hans Gillhaus", "positions": ["EI", "DC"], "overall": 82}, {"id": "p_team_holanda_1988_13", "name": "Arnold Mühren", "positions": ["MC"], "overall": 84}, {"id": "p_team_holanda_1988_14", "name": "Erwin Koeman", "positions": ["LD", "MC"], "overall": 83}, {"id": "p_team_holanda_1988_15", "name": "Peter Boeve", "positions": ["DFC"], "overall": 80}, {"id": "p_50_0", "name": "Joan García", "positions": ["POR"], "overall": 84}, {"id": "p_50_1", "name": "David Raya", "positions": ["POR"], "overall": 85}, {"id": "p_50_2", "name": "Marc Cucurella", "positions": ["LI", "DFC"], "overall": 84}, {"id": "p_50_3", "name": "Alejandro Grimaldo", "positions": ["LI", "DFC"], "overall": 83}, {"id": "p_50_4", "name": "Eric García", "positions": ["DFC"], "overall": 81}, {"id": "p_50_5", "name": "Marc Pubill", "positions": ["DFC", "LD"], "overall": 79}, {"id": "p_50_6", "name": "Rodri", "positions": ["MC"], "overall": 92}, {"id": "p_50_7", "name": "Martín Zubimendi", "positions": ["MC"], "overall": 86}, {"id": "p_50_8", "name": "Pedri", "positions": ["MC"], "overall": 90}, {"id": "p_50_9", "name": "Fabián Ruiz", "positions": ["MC"], "overall": 85}, {"id": "p_50_10", "name": "Gavi", "positions": ["MC"], "overall": 84}, {"id": "p_50_11", "name": "Mikel Merino", "positions": ["MC", "DC"], "overall": 83}, {"id": "p_50_12", "name": "Lamine Yamal", "positions": ["ED", "EI"], "overall": 91}, {"id": "p_50_13", "name": "Nico Williams", "positions": ["EI", "ED"], "overall": 86}, {"id": "p_50_14", "name": "Mikel Oyarzabal", "positions": ["DC", "EI"], "overall": 85}, {"id": "p_50_15", "name": "Dani Olmo", "positions": ["DC", "MC"], "overall": 86}, {"id": "p_51_0", "name": "Emiliano Martínez", "positions": ["POR"], "overall": 87}, {"id": "p_51_1", "name": "Gerónimo Rulli", "positions": ["POR"], "overall": 80}, {"id": "p_51_2", "name": "Nicolás Otamendi", "positions": ["DFC"], "overall": 83}, {"id": "p_51_3", "name": "Cristian Romero", "positions": ["DFC"], "overall": 86}, {"id": "p_51_4", "name": "Lisandro Martínez", "positions": ["DFC", "LI"], "overall": 85}, {"id": "p_51_5", "name": "Nicolás Tagliafico", "positions": ["LI", "DFC"], "overall": 81}, {"id": "p_51_6", "name": "Nahuel Molina", "positions": ["LD", "DFC"], "overall": 81}, {"id": "p_51_7", "name": "Gonzalo Montiel", "positions": ["LD", "DFC"], "overall": 80}, {"id": "p_51_8", "name": "Enzo Fernández", "positions": ["MC"], "overall": 87}, {"id": "p_51_9", "name": "Giovani Lo Celso", "positions": ["MC"], "overall": 83}, {"id": "p_51_10", "name": "Nicolás Paz", "positions": ["MC", "DC"], "overall": 82}, {"id": "p_51_11", "name": "Rodrigo De Paul", "positions": ["MC"], "overall": 84}, {"id": "p_51_12", "name": "Lionel Messi", "positions": ["EI", "DC"], "overall": 93}, {"id": "p_51_13", "name": "Julián Álvarez", "positions": ["DC", "EI"], "overall": 88}, {"id": "p_51_14", "name": "Lautaro Martínez", "positions": ["DC"], "overall": 88}, {"id": "p_51_15", "name": "José Manuel López", "positions": ["DC"], "overall": 79}, {"id": "p_52_0", "name": "Ederson", "positions": ["POR"], "overall": 86}, {"id": "p_52_1", "name": "Alisson Becker", "positions": ["POR"], "overall": 87}, {"id": "p_52_2", "name": "Marquinhos", "positions": ["DFC"], "overall": 85}, {"id": "p_52_3", "name": "Gabriel Magalhães", "positions": ["DFC"], "overall": 84}, {"id": "p_52_4", "name": "Éder Militão", "positions": ["DFC"], "overall": 82}, {"id": "p_52_5", "name": "Alex Sandro", "positions": ["LI", "DFC"], "overall": 78}, {"id": "p_52_6", "name": "Wesley", "positions": ["LD", "DFC"], "overall": 78}, {"id": "p_52_7", "name": "Bruno Guimarães", "positions": ["MC"], "overall": 86}, {"id": "p_52_8", "name": "Casemiro", "positions": ["MC"], "overall": 83}, {"id": "p_52_9", "name": "Lucas Paquetá", "positions": ["MC"], "overall": 83}, {"id": "p_52_10", "name": "Andreas Pereira", "positions": ["MC"], "overall": 79}, {"id": "p_52_11", "name": "Neymar Jr.", "positions": ["EI", "MC"], "overall": 87}, {"id": "p_52_12", "name": "Vinícius Júnior", "positions": ["EI", "ED"], "overall": 90}, {"id": "p_52_13", "name": "Raphinha", "positions": ["ED", "EI"], "overall": 87}, {"id": "p_52_14", "name": "Gabriel Martinelli", "positions": ["ED", "EI"], "overall": 83}, {"id": "p_52_15", "name": "Matheus Cunha", "positions": ["DC", "EI"], "overall": 82}, {"id": "p_53_0", "name": "Diogo Costa", "positions": ["POR"], "overall": 86}, {"id": "p_53_1", "name": "José Sá", "positions": ["POR"], "overall": 80}, {"id": "p_53_2", "name": "Rúben Dias", "positions": ["DFC"], "overall": 88}, {"id": "p_53_3", "name": "Gonçalo Inácio", "positions": ["DFC"], "overall": 81}, {"id": "p_53_4", "name": "António Silva", "positions": ["DFC"], "overall": 81}, {"id": "p_53_5", "name": "Nuno Mendes", "positions": ["LI", "DFC"], "overall": 85}, {"id": "p_53_6", "name": "João Cancelo", "positions": ["LD", "DFC"], "overall": 83}, {"id": "p_53_7", "name": "Vitinha", "positions": ["MC"], "overall": 86}, {"id": "p_53_8", "name": "João Neves", "positions": ["MC"], "overall": 84}, {"id": "p_53_9", "name": "Bruno Fernandes", "positions": ["MC", "DC"], "overall": 88}, {"id": "p_53_10", "name": "Bernardo Silva", "positions": ["MC", "EI"], "overall": 87}, {"id": "p_53_11", "name": "Rúben Neves", "positions": ["MC"], "overall": 81}, {"id": "p_53_12", "name": "Rafael Leão", "positions": ["EI", "ED"], "overall": 85}, {"id": "p_53_13", "name": "Pedro Neto", "positions": ["ED", "EI"], "overall": 81}, {"id": "p_53_14", "name": "Francisco Conceição", "positions": ["ED", "EI"], "overall": 78}, {"id": "p_53_15", "name": "Cristiano Ronaldo", "positions": ["DC", "EI"], "overall": 86}];
let rawTeams = [
  {"id":"team_1","name":"España 2010","players":["p_1_0","p_1_1","p_1_2","p_1_3","p_1_4","p_1_5","p_1_6","p_1_7","p_1_8","p_1_9","p_1_10","p_1_11","p_1_12","p_1_13","p_1_14","p_1_15"],"flag":"assets/flags/es.png","emoji":"🇪🇸","bonus":{"PASE":5},"style":"tiki_taka"},
  {"id":"team_2","name":"España 2012","players":["p_2_0","p_2_1","p_2_2","p_2_3","p_2_4","p_2_5","p_2_6","p_2_7","p_2_8","p_2_9","p_2_10","p_2_11","p_2_12","p_2_13","p_2_14","p_2_15"],"flag":"assets/flags/es.png","emoji":"🇪🇸","bonus":{"PASE":5},"style":"tiki_taka"},
  {"id":"team_4","name":"Brasil 2002","players":["p_4_0","p_4_1","p_4_2","p_4_3","p_4_4","p_4_5","p_4_6","p_4_7","p_4_8","p_4_9","p_4_10","p_4_11","p_4_12","p_4_13","p_4_14","p_4_15"],"flag":"assets/flags/br.png","emoji":"🇧🇷","bonus":{"TÉCNICA":5},"style":"samba_total"},
  {"id":"team_6","name":"Alemania 1990","players":["p_6_0","p_6_1","p_6_2","p_6_3","p_6_4","p_6_5","p_6_6","p_6_7","p_6_8","p_6_9","p_6_10","p_6_11","p_6_12","p_6_13","p_6_14","p_6_15"],"flag":"assets/flags/de.png","emoji":"🇩🇪","bonus":{"DEFENSA":5},"style":"maquinaria_alemana"},
  {"id":"team_7","name":"Alemania 2014","players":["p_7_0","p_7_1","p_7_2","p_7_3","p_7_4","p_7_5","p_7_6","p_7_7","p_7_8","p_7_9","p_7_10","p_7_11","p_7_12","p_7_13","p_7_14","p_7_15"],"flag":"assets/flags/de.png","emoji":"🇩🇪","bonus":{"DEFENSA":5},"style":"gegenpressing"},
  {"id":"team_8","name":"Argentina 1986","players":["p_8_0","p_8_1","p_8_2","p_8_3","p_8_4","p_8_5","p_8_6","p_8_7","p_8_8","p_8_9","p_8_10","p_8_11","p_8_12","p_8_13","p_8_14","p_8_15"],"flag":"assets/flags/ar.png","emoji":"🇦🇷","bonus":{"ATAQUE":5},"style":"magia_individual"},
  {"id":"team_9","name":"Argentina 2022","players":["p_9_0","p_9_1","p_9_2","p_9_3","p_9_4","p_9_5","p_9_6","p_9_7","p_9_8","p_9_9","p_9_10","p_9_11","p_9_12","p_9_13","p_9_14","p_9_15"],"flag":"assets/flags/ar.png","emoji":"🇦🇷","bonus":{"ATAQUE":5},"style":"la_scaloneta"},
  {"id":"team_10","name":"Francia 1998","players":["p_10_0","p_10_1","p_10_2","p_10_3","p_10_4","p_10_5","p_10_6","p_10_7","p_10_8","p_10_9","p_10_10","p_10_11","p_10_12","p_10_13","p_10_14","p_10_15"],"flag":"assets/flags/fr.png","emoji":"🏳️","bonus":{"PASE":2},"style":"solidez_francesa"},
  {"id":"team_11","name":"Francia 2018","players":["p_11_0","p_11_1","p_11_2","p_11_3","p_11_4","p_11_5","p_11_6","p_11_7","p_11_8","p_11_9","p_11_10","p_11_11","p_11_12","p_11_13","p_11_14","p_11_15"],"flag":"assets/flags/fr.png","emoji":"🏳️","bonus":{"PASE":2},"style":"velocidad_punzante"},
  {"id":"team_13","name":"Italia 2006","players":["p_13_0","p_13_1","p_13_2","p_13_3","p_13_4","p_13_5","p_13_6","p_13_7","p_13_8","p_13_9","p_13_10","p_13_11","p_13_12","p_13_13","p_13_14","p_13_15"],"flag":"assets/flags/it.png","emoji":"🇮🇹","bonus":{"DEFENSA":5},"style":"catenaccio"},
  {"id":"team_17","name":"Portugal 2016","players":["p_17_0","p_17_1","p_17_2","p_17_3","p_17_4","p_17_5","p_17_6","p_17_7","p_17_8","p_17_9","p_17_10","p_17_11","p_17_12","p_17_13","p_17_14","p_17_15"],"flag":"assets/flags/pt.png","emoji":"🇵🇹","bonus":{"TÉCNICA":3},"style":"garra_lusa"},
  {"id":"team_18","name":"Croacia 2018","players":["p_18_0","p_18_1","p_18_2","p_18_3","p_18_4","p_18_5","p_18_6","p_18_7","p_18_8","p_18_9","p_18_10","p_18_11","p_18_12","p_18_13","p_18_14","p_18_15"],"emoji":"🇭🇷","bonus":{"PASE":3},"style":"muralla_balcanica"},
  {"id":"team_21","name":"Dinamarca 1992","players":["p_21_0","p_21_1","p_21_2","p_21_3","p_21_4","p_21_5","p_21_6","p_21_7","p_21_8","p_21_9","p_21_10","p_21_11","p_21_12","p_21_13","p_21_14","p_21_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"dinamita_danesa"},
  {"id":"team_22","name":"Bélgica 2018","players":["p_22_0","p_22_1","p_22_2","p_22_3","p_22_4","p_22_5","p_22_6","p_22_7","p_22_8","p_22_9","p_22_10","p_22_11","p_22_12","p_22_13","p_22_14","p_22_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"velocidad_punzante"},
  {"id":"team_23","name":"México 1986","players":["p_23_0","p_23_1","p_23_2","p_23_3","p_23_4","p_23_5","p_23_6","p_23_7","p_23_8","p_23_9","p_23_10","p_23_11","p_23_12","p_23_13","p_23_14","p_23_15"],"flag":"assets/flags/mx.png","emoji":"🏳️","bonus":{"PASE":2},"style":"tricolor_tecnico"},
  {"id":"team_24","name":"Estados Unidos 2002","players":["p_24_0","p_24_1","p_24_2","p_24_3","p_24_4","p_24_5","p_24_6","p_24_7","p_24_8","p_24_9","p_24_10","p_24_11","p_24_12","p_24_13","p_24_14","p_24_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"garra_yanqui"},
  {"id":"team_25","name":"Japón 2002","players":["p_25_0","p_25_1","p_25_2","p_25_3","p_25_4","p_25_5","p_25_6","p_25_7","p_25_8","p_25_9","p_25_10","p_25_11","p_25_12","p_25_13","p_25_14","p_25_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"disciplina_nipona"},
  {"id":"team_26","name":"Corea del Sur 2002","players":["p_26_0","p_26_1","p_26_2","p_26_3","p_26_4","p_26_5","p_26_6","p_26_7","p_26_8","p_26_9","p_26_10","p_26_11","p_26_12","p_26_13","p_26_14","p_26_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"futbol_directo"},
  {"id":"team_27","name":"Marruecos 2022","players":["p_27_0","p_27_1","p_27_2","p_27_3","p_27_4","p_27_5","p_27_6","p_27_7","p_27_8","p_27_9","p_27_10","p_27_11","p_27_12","p_27_13","p_27_14","p_27_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"muralla_atlas"},
  {"id":"team_28","name":"Nigeria 1994","players":["p_28_0","p_28_1","p_28_2","p_28_3","p_28_4","p_28_5","p_28_6","p_28_7","p_28_8","p_28_9","p_28_10","p_28_11","p_28_12","p_28_13","p_28_14","p_28_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"superaguilas"},
  {"id":"team_29","name":"Camerún 1990","players":["p_29_0","p_29_1","p_29_2","p_29_3","p_29_4","p_29_5","p_29_6","p_29_7","p_29_8","p_29_9","p_29_10","p_29_11","p_29_12","p_29_13","p_29_14","p_29_15"],"flag":"assets/flags/cm.png","emoji":"🏳️","bonus":{"PASE":2},"style":"leones_indomables"},
  {"id":"team_31","name":"Paraguay 2010","players":["p_31_0","p_31_1","p_31_2","p_31_3","p_31_4","p_31_5","p_31_6","p_31_7","p_31_8","p_31_9","p_31_10","p_31_11","p_31_12","p_31_13","p_31_14","p_31_15"],"flag":"assets/flags/py.png","emoji":"🏳️","bonus":{"PASE":2},"style":"muralla_guarani"},
  {"id":"team_32","name":"Colombia 2014","players":["p_32_0","p_32_1","p_32_2","p_32_3","p_32_4","p_32_5","p_32_6","p_32_7","p_32_8","p_32_9","p_32_10","p_32_11","p_32_12","p_32_13","p_32_14","p_32_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"fiesta_cafetera"},
  {"id":"team_40","name":"Turquía 2002","players":["p_40_0","p_40_1","p_40_2","p_40_3","p_40_4","p_40_5","p_40_6","p_40_7","p_40_8","p_40_9","p_40_10","p_40_11","p_40_12","p_40_13","p_40_14","p_40_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"furia_otomana"},
  {"id":"team_41","name":"Grecia 2004","players":["p_41_0","p_41_1","p_41_2","p_41_3","p_41_4","p_41_5","p_41_6","p_41_7","p_41_8","p_41_9","p_41_10","p_41_11","p_41_12","p_41_13","p_41_14","p_41_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"milagro_defensivo"},
  {"id":"team_42","name":"Rumanía 1994","players":["p_42_0","p_42_1","p_42_2","p_42_3","p_42_4","p_42_5","p_42_6","p_42_7","p_42_8","p_42_9","p_42_10","p_42_11","p_42_12","p_42_13","p_42_14","p_42_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"magia_carpatica"},
  {"id":"team_43","name":"Irlanda 1990","players":["p_43_0","p_43_1","p_43_2","p_43_3","p_43_4","p_43_5","p_43_6","p_43_7","p_43_8","p_43_9","p_43_10","p_43_11","p_43_12","p_43_13","p_43_14","p_43_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"muralla_celta"},
  {"id":"team_46","name":"Rusia 2018","players":["p_46_0","p_46_1","p_46_2","p_46_3","p_46_4","p_46_5","p_46_6","p_46_7","p_46_8","p_46_9","p_46_10","p_46_11","p_46_12","p_46_13","p_46_14","p_46_15"],"flag":"assets/flags/ru.png","emoji":"🏳️","bonus":{"PASE":2},"style":"punta_lanza"},
  {"id":"team_47","name":"Ucrania 2006","players":["p_47_0","p_47_1","p_47_2","p_47_3","p_47_4","p_47_5","p_47_6","p_47_7","p_47_8","p_47_9","p_47_10","p_47_11","p_47_12","p_47_13","p_47_14","p_47_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"tecnica_centroeuropea"},
  {"id":"team_48","name":"Serbia 2010","players":["p_48_0","p_48_1","p_48_2","p_48_3","p_48_4","p_48_5","p_48_6","p_48_7","p_48_8","p_48_9","p_48_10","p_48_11","p_48_12","p_48_13","p_48_14","p_48_15"],"emoji":"🇷🇸","bonus":{"PASE":2},"style":"tecnica_balcanica"},
  {"id":"team_49","name":"Noruega 1998","players":["p_49_0","p_49_1","p_49_2","p_49_3","p_49_4","p_49_5","p_49_6","p_49_7","p_49_8","p_49_9","p_49_10","p_49_11","p_49_12","p_49_13","p_49_14","p_49_15"],"emoji":"🏳️","bonus":{"PASE":2},"style":"vikingo_directo"},
  {"id":"team_brasil_1982","name":"Brasil 1982","style":"samba_total","players":["p_team_brasil_1982_0","p_team_brasil_1982_1","p_team_brasil_1982_2","p_team_brasil_1982_3","p_team_brasil_1982_4","p_team_brasil_1982_5","p_team_brasil_1982_6","p_team_brasil_1982_7","p_team_brasil_1982_8","p_team_brasil_1982_9","p_team_brasil_1982_10","p_team_brasil_1982_11","p_team_brasil_1982_12","p_team_brasil_1982_13","p_team_brasil_1982_14","p_team_brasil_1982_15"]},
  {"id":"team_argentina_1978","name":"Argentina 1978","style":"magia_individual","players":["p_team_argentina_1978_0","p_team_argentina_1978_1","p_team_argentina_1978_2","p_team_argentina_1978_3","p_team_argentina_1978_4","p_team_argentina_1978_5","p_team_argentina_1978_6","p_team_argentina_1978_7","p_team_argentina_1978_8","p_team_argentina_1978_9","p_team_argentina_1978_10","p_team_argentina_1978_11","p_team_argentina_1978_12","p_team_argentina_1978_13","p_team_argentina_1978_14","p_team_argentina_1978_15"]},
  {"id":"team_senegal_2002","name":"Senegal 2002","style":"superaguilas","players":["p_team_senegal_2002_0","p_team_senegal_2002_1","p_team_senegal_2002_2","p_team_senegal_2002_3","p_team_senegal_2002_4","p_team_senegal_2002_5","p_team_senegal_2002_6","p_team_senegal_2002_7","p_team_senegal_2002_8","p_team_senegal_2002_9","p_team_senegal_2002_10","p_team_senegal_2002_11","p_team_senegal_2002_12","p_team_senegal_2002_13","p_team_senegal_2002_14","p_team_senegal_2002_15"]},
  {"id":"team_costa_rica_2014","name":"Costa Rica 2014","style":"catenaccio","players":["p_team_costa_rica_2014_0","p_team_costa_rica_2014_1","p_team_costa_rica_2014_2","p_team_costa_rica_2014_3","p_team_costa_rica_2014_4","p_team_costa_rica_2014_5","p_team_costa_rica_2014_6","p_team_costa_rica_2014_7","p_team_costa_rica_2014_8","p_team_costa_rica_2014_9","p_team_costa_rica_2014_10","p_team_costa_rica_2014_11","p_team_costa_rica_2014_12","p_team_costa_rica_2014_13","p_team_costa_rica_2014_14","p_team_costa_rica_2014_15"]},
  {"id":"team_ghana_2010","name":"Ghana 2010","style":"superaguilas","players":["p_team_ghana_2010_0","p_team_ghana_2010_1","p_team_ghana_2010_2","p_team_ghana_2010_3","p_team_ghana_2010_4","p_team_ghana_2010_5","p_team_ghana_2010_6","p_team_ghana_2010_7","p_team_ghana_2010_8","p_team_ghana_2010_9","p_team_ghana_2010_10","p_team_ghana_2010_11","p_team_ghana_2010_12","p_team_ghana_2010_13","p_team_ghana_2010_14","p_team_ghana_2010_15"]},
  {"id":"team_uruguay_2010","name":"Uruguay 2010","style":"garra_charrua","players":["p_team_uruguay_2010_0","p_team_uruguay_2010_1","p_team_uruguay_2010_2","p_team_uruguay_2010_3","p_team_uruguay_2010_4","p_team_uruguay_2010_5","p_team_uruguay_2010_6","p_team_uruguay_2010_7","p_team_uruguay_2010_8","p_team_uruguay_2010_9","p_team_uruguay_2010_10","p_team_uruguay_2010_11","p_team_uruguay_2010_12","p_team_uruguay_2010_13","p_team_uruguay_2010_14","p_team_uruguay_2010_15"]},
  {"id":"team_suecia_1994","name":"Suecia 1994","style":"vikingo_directo","players":["p_team_suecia_1994_0","p_team_suecia_1994_1","p_team_suecia_1994_2","p_team_suecia_1994_3","p_team_suecia_1994_4","p_team_suecia_1994_5","p_team_suecia_1994_6","p_team_suecia_1994_7","p_team_suecia_1994_8","p_team_suecia_1994_9","p_team_suecia_1994_10","p_team_suecia_1994_11","p_team_suecia_1994_12","p_team_suecia_1994_13","p_team_suecia_1994_14","p_team_suecia_1994_15"]},
  {"id":"team_holanda_1988","name":"Holanda 1988","style":"total_football","players":["p_team_holanda_1988_0","p_team_holanda_1988_1","p_team_holanda_1988_2","p_team_holanda_1988_3","p_team_holanda_1988_4","p_team_holanda_1988_5","p_team_holanda_1988_6","p_team_holanda_1988_7","p_team_holanda_1988_8","p_team_holanda_1988_9","p_team_holanda_1988_10","p_team_holanda_1988_11","p_team_holanda_1988_12","p_team_holanda_1988_13","p_team_holanda_1988_14","p_team_holanda_1988_15"]},
  {"id":"team_50","name":"España 2026","players":["p_50_0","p_50_1","p_50_2","p_50_3","p_50_4","p_50_5","p_50_6","p_50_7","p_50_8","p_50_9","p_50_10","p_50_11","p_50_12","p_50_13","p_50_14","p_50_15"],"flag":"assets/flags/es.png","emoji":"🇪🇸","bonus":{"PASE":6},"style":"tiki_taka"},
  {"id":"team_51","name":"Argentina 2026","players":["p_51_0","p_51_1","p_51_2","p_51_3","p_51_4","p_51_5","p_51_6","p_51_7","p_51_8","p_51_9","p_51_10","p_51_11","p_51_12","p_51_13","p_51_14","p_51_15"],"flag":"assets/flags/ar.png","emoji":"🇦🇷","bonus":{"ATAQUE":6},"style":"la_scaloneta"},
  {"id":"team_52","name":"Brasil 2026","players":["p_52_0","p_52_1","p_52_2","p_52_3","p_52_4","p_52_5","p_52_6","p_52_7","p_52_8","p_52_9","p_52_10","p_52_11","p_52_12","p_52_13","p_52_14","p_52_15"],"flag":"assets/flags/br.png","emoji":"🇧🇷","bonus":{"TECNICA":6},"style":"jogo_bonito"},
  {"id":"team_53","name":"Portugal 2026","players":["p_53_0","p_53_1","p_53_2","p_53_3","p_53_4","p_53_5","p_53_6","p_53_7","p_53_8","p_53_9","p_53_10","p_53_11","p_53_12","p_53_13","p_53_14","p_53_15"],"flag":"assets/flags/pt.png","emoji":"🇵🇹","bonus":{"ATAQUE":5},"style":"garra_lusa"}
];
const STYLES = {
 get tiki_taka()            { return {get name(){ return window.t?window.t('style.name.tiki_taka'):'Tiki-Taka'; },bonuses:{passing:10,pace:5}}; },
 get samba_total()          { return {get name(){ return window.t?window.t('style.name.samba_total'):'Samba Total'; },bonuses:{attack:8,technique:7}}; },
 get ataque_letal()         { return {get name(){ return window.t?window.t('style.name.ataque_letal'):'Ataque Letal'; },bonuses:{attack:10,pace:5}}; },
 get maquinaria_alemana()   { return {get name(){ return window.t?window.t('style.name.maquinaria_alemana'):'Maquinaria Alemana'; },bonuses:{defense:8,technique:4,passing:3}}; },
 get gegenpressing()        { return {get name(){ return window.t?window.t('style.name.gegenpressing'):'Gegenpressing'; },bonuses:{pace:9,defense:6}}; },
 get magia_individual()     { return {get name(){ return window.t?window.t('style.name.magia_individual'):'Magia Albiceleste'; },bonuses:{attack:10,technique:5}}; },
 get la_scaloneta()         { return {get name(){ return window.t?window.t('style.name.la_scaloneta'):'La Scaloneta'; },bonuses:{defense:9,passing:6}}; },
 get solidez_francesa()     { return {get name(){ return window.t?window.t('style.name.solidez_francesa'):'Solidez Francesa'; },bonuses:{defense:8,passing:4,pace:3}}; },
 get velocidad_punzante()   { return {get name(){ return window.t?window.t('style.name.velocidad_punzante'):'Velocidad Punzante'; },bonuses:{pace:10,attack:5}}; },
 get catenaccio()           { return {get name(){ return window.t?window.t('style.name.catenaccio'):'Catenaccio'; },bonuses:{defense:12,passing:3}}; },
 get total_football()       { return {get name(){ return window.t?window.t('style.name.total_football'):'Fútbol Total'; },bonuses:{passing:6,technique:6,pace:3}}; },
 get naranja_mecanica()     { return {get name(){ return window.t?window.t('style.name.naranja_mecanica'):'Naranja Mecánica'; },bonuses:{technique:8,passing:5,pace:2}}; },
 get futbol_directo()       { return {get name(){ return window.t?window.t('style.name.futbol_directo'):'Fútbol Directo'; },bonuses:{pace:8,attack:4,defense:3}}; },
 get garra_lusa()           { return {get name(){ return window.t?window.t('style.name.garra_lusa'):'Garra Lusa'; },bonuses:{defense:7,technique:4,pace:4}}; },
 get muralla_balcanica()    { return {get name(){ return window.t?window.t('style.name.muralla_balcanica'):'Muralla Balcánica'; },bonuses:{defense:12,technique:3}}; },
 get garra_charrua()        { return {get name(){ return window.t?window.t('style.name.garra_charrua'):'Garra Charrúa'; },bonuses:{defense:8,attack:5,pace:2}}; },
 get once_oro_magiar()      { return {get name(){ return window.t?window.t('style.name.once_oro_magiar'):'Once de Oro Magiar'; },bonuses:{technique:10,passing:5}}; },
 get dinamita_danesa()      { return {get name(){ return window.t?window.t('style.name.dinamita_danesa'):'Dinamita Danesa'; },bonuses:{pace:8,attack:6}}; },
 get tricolor_tecnico()     { return {get name(){ return window.t?window.t('style.name.tricolor_tecnico'):'Tricolor Técnico'; },bonuses:{technique:8,passing:5}}; },
 get garra_yanqui()         { return {get name(){ return window.t?window.t('style.name.garra_yanqui'):'Garra Yanqui'; },bonuses:{defense:8,pace:5}}; },
 get disciplina_nipona()    { return {get name(){ return window.t?window.t('style.name.disciplina_nipona'):'Disciplina Nipona'; },bonuses:{passing:8,technique:5}}; },
 get muralla_atlas()        { return {get name(){ return window.t?window.t('style.name.muralla_atlas'):'Muralla del Atlas'; },bonuses:{defense:10,pace:4}}; },
 get superaguilas()         { return {get name(){ return window.t?window.t('style.name.superaguilas'):'Superáguilas'; },bonuses:{pace:8,attack:6}}; },
 get leones_indomables()    { return {get name(){ return window.t?window.t('style.name.leones_indomables'):'Leones Indomables'; },bonuses:{attack:8,defense:5}}; },
 get garra_chilena()        { return {get name(){ return window.t?window.t('style.name.garra_chilena'):'Garra Chilena'; },bonuses:{attack:7,technique:5}}; },
 get muralla_guarani()      { return {get name(){ return window.t?window.t('style.name.muralla_guarani'):'Muralla Guaraní'; },bonuses:{defense:11,passing:3}}; },
 get fiesta_cafetera()      { return {get name(){ return window.t?window.t('style.name.fiesta_cafetera'):'Fiesta Cafetera'; },bonuses:{attack:8,technique:5}}; },
 get vendaval_incaico()     { return {get name(){ return window.t?window.t('style.name.vendaval_incaico'):'Vendaval Incaico'; },bonuses:{attack:8,pace:5}}; },
 get disciplina_vikinga()   { return {get name(){ return window.t?window.t('style.name.disciplina_vikinga'):'Disciplina Vikinga'; },bonuses:{defense:7,pace:5}}; },
 get tecnica_centroeuropea(){ return {get name(){ return window.t?window.t('style.name.tecnica_centroeuropea'):'Técnica Centroeuropea'; },bonuses:{technique:8,passing:5}}; },
 get tecnica_balcanica()    { return {get name(){ return window.t?window.t('style.name.tecnica_balcanica'):'Técnica Balcánica'; },bonuses:{technique:9,passing:4}}; },
 get wunderteam()           { return {get name(){ return window.t?window.t('style.name.wunderteam'):'Wunderteam'; },bonuses:{attack:9,technique:4}}; },
 get sistema_cerrojo()      { return {get name(){ return window.t?window.t('style.name.sistema_cerrojo'):'Sistema del Cerrojo'; },bonuses:{defense:10,passing:4}}; },
 get furia_otomana()        { return {get name(){ return window.t?window.t('style.name.furia_otomana'):'Furia Otomana'; },bonuses:{pace:8,defense:5}}; },
 get milagro_defensivo()    { return {get name(){ return window.t?window.t('style.name.milagro_defensivo'):'Milagro Defensivo'; },bonuses:{defense:12,passing:2}}; },
 get magia_carpatica()      { return {get name(){ return window.t?window.t('style.name.magia_carpatica'):'Magia Cárpata'; },bonuses:{technique:9,attack:4}}; },
 get furia_tartan()         { return {get name(){ return window.t?window.t('style.name.furia_tartan'):'Furia Tartán'; },bonuses:{attack:7,pace:5}}; },
 get muralla_celta()        { return {get name(){ return window.t?window.t('style.name.muralla_celta'):'Muralla Celta'; },bonuses:{defense:8,technique:4}}; },
 get punta_lanza()          { return {get name(){ return window.t?window.t('style.name.punta_lanza'):'Punta de Lanza'; },bonuses:{attack:9,pace:4}}; },
 get vikingo_directo()      { return {get name(){ return window.t?window.t('style.name.vikingo_directo'):'Vikingo Directo'; },bonuses:{defense:8,pace:5}}; },
};
const STAT_LABELS={
  get attack()   { return window.t?window.t('info.attack')   :'ATAQUE'; },
  get defense()  { return window.t?window.t('info.defense')  :'DEFENSA'; },
  get pace()     { return window.t?window.t('info.pace')     :'RITMO'; },
  get passing()  { return window.t?window.t('info.passing')  :'PASE'; },
  get technique(){ return window.t?window.t('info.technique'):'TÉCNICA'; },
};

/* ========= MATCH STRATEGIES (chosen before each match) ========= */
// Each strategy can be played, and "counters" points to the strategy key it beats.
// Counter logic is based on real footballing logic:
//  - Tiki-Taka breaks Bloque Bajo (patience unlocks low blocks) and is broken by Presión Alta
//  - Catenaccio is broken by Ataque por Bandas (wide play opens compact centers)
//  - Gegenpressing is broken by Juego Directo (skip the press with long balls)
//  - etc.
/* ════════════════════════════════════════════════════════════
   GIRO TÁCTICO — habilidad de un jugador: pausa el partido en
   cualquier momento y elige una de 3 cartas al azar (de estas 20).
   Cada carta tiene un beneficio y una contrapartida negativa, ambos
   aplicados a TU equipo durante lo que resta de partido.
   ════════════════════════════════════════════════════════════ */
const GIRO_CARDS = [
  { id:'presion_alta', name:'PRESIÓN ALTA', icon:'ph-arrow-fat-lines-up',
    pos:'+12% ataque', neg:'−8% resistencia (persistente)',
    apply(ctx){ ctx.myLambda+=0.084; ctx.fatigue-=8; } },
  { id:'cierre_atras', name:'CIERRE ATRÁS', icon:'ph-shield-check',
    pos:'+15% defensa', neg:'−10% ataque',
    apply(ctx){ ctx.oppLambda-=0.105; ctx.myLambda-=0.07; } },
  { id:'hidratacion', name:'PAUSA DE HIDRATACIÓN', icon:'ph-drop',
    pos:'+18% resistencia (persistente)', neg:'−6% ritmo',
    apply(ctx){ ctx.fatigue+=18; ctx.myLambda-=0.027; } },
  { id:'golpe_pizarra', name:'GOLPE DE PIZARRA', icon:'ph-chalkboard-teacher',
    pos:'+8% ataque y +8% defensa', neg:'−14% resistencia (persistente)',
    apply(ctx){ ctx.myLambda+=0.056; ctx.oppLambda-=0.056; ctx.fatigue-=14; } },
  { id:'grito_capitan', name:'GRITO DEL CAPITÁN', icon:'ph-megaphone',
    pos:'+10% moral (persistente)', neg:'más riesgo de tarjeta propia',
    apply(ctx){ ctx.morale+=10; ctx.cardRiskDelta+=0.05; } },
  { id:'tiquitaca', name:'TIQUI-TACA FORZADO', icon:'ph-arrows-clockwise',
    pos:'+14% pase y +10% técnica', neg:'−8% ataque directo',
    apply(ctx){ ctx.myLambda+=0.054; ctx.myLambda-=0.056; } },
  { id:'contragolpe', name:'CONTRAGOLPE RELÁMPAGO', icon:'ph-lightning',
    pos:'+18% ritmo', neg:'−10% defensa',
    apply(ctx){ ctx.myLambda+=0.081; ctx.oppLambda+=0.07; } },
  { id:'muro', name:'MURO DEFENSIVO', icon:'ph-wall',
    pos:'+20% defensa', neg:'−12% pase',
    apply(ctx){ ctx.oppLambda-=0.14; ctx.myLambda-=0.054; } },
  { id:'orden_banquillo', name:'ORDEN DEL BANQUILLO', icon:'ph-clipboard-text',
    pos:'+15% resistencia (persistente)', neg:'−5% moral (persistente)',
    apply(ctx){ ctx.fatigue+=15; ctx.morale-=5; } },
  { id:'estrella', name:'ESTRELLA DEL PARTIDO', icon:'ph-star',
    pos:'+20 valoración al mejor jugador', neg:'más riesgo de lesión (ese jugador)',
    apply(ctx){ ctx.starBoost=20; ctx.injuryRiskDelta+=0.05; } },
  { id:'fuera_juego', name:'FUERA DE JUEGO PROVOCADO', icon:'ph-flag',
    pos:'+10% defensa', neg:'−8% técnica',
    apply(ctx){ ctx.oppLambda-=0.07; ctx.myLambda-=0.032; } },
  { id:'balon_parado', name:'BALÓN PARADO ENSAYADO', icon:'ph-target',
    pos:'+15% ataque', neg:'−10% pase en juego abierto',
    apply(ctx){ ctx.myLambda+=0.105; ctx.myLambda-=0.04; } },
  { id:'presion_asfixiante', name:'PRESIÓN ASFIXIANTE', icon:'ph-wind',
    pos:'+16% defensa y +8% ritmo', neg:'−14% resistencia (persistente)',
    apply(ctx){ ctx.oppLambda-=0.112; ctx.myLambda+=0.032; ctx.fatigue-=14; } },
  { id:'rondo', name:'RONDO DE VESTUARIO', icon:'ph-circle-dashed',
    pos:'+12% técnica', neg:'−6% defensa',
    apply(ctx){ ctx.myLambda+=0.048; ctx.oppLambda+=0.042; } },
  { id:'lectura_arbitro', name:'LECTURA DEL ÁRBITRO', icon:'ph-eye',
    pos:'menos riesgo de tarjeta propia', neg:'−8% ataque',
    apply(ctx){ ctx.cardRiskDelta-=0.05; ctx.myLambda-=0.056; } },
  { id:'viento_favor', name:'VIENTO A FAVOR', icon:'ph-wind',
    pos:'+10% ritmo y +10% pase', neg:'−8% técnica',
    apply(ctx){ ctx.myLambda+=0.072; ctx.myLambda-=0.032; } },
  { id:'grada_favor', name:'GRADA A FAVOR', icon:'ph-users-three',
    pos:'+12% moral (persistente)', neg:'−8% resistencia (persistente)',
    apply(ctx){ ctx.morale+=12; ctx.fatigue-=8; } },
  { id:'tiempo_controlado', name:'TIEMPO CONTROLADO', icon:'ph-hourglass-medium',
    pos:'apenas pierdes resistencia el resto del partido (persistente)', neg:'−8% ataque',
    apply(ctx){ ctx.fatigue+=10; ctx.myLambda-=0.056; } },
  { id:'prorroga_mental', name:'PRÓRROGA MENTAL', icon:'ph-brain',
    pos:'+5% en todas las estadísticas', neg:'−10% resistencia (persistente)',
    apply(ctx){ ctx.myLambda+=0.035; ctx.oppLambda-=0.035; ctx.fatigue-=10; } },
  { id:'ultima_bala', name:'ÚLTIMA BALA', icon:'ph-fire',
    pos:'+25% ataque', neg:'−20% defensa',
    apply(ctx){ ctx.myLambda+=0.175; ctx.oppLambda+=0.14; } },
];


const STRATEGIES = {
  tiki_taka:      { get name(){ return window.t?window.t('strategy.tiki_taka.name')     :'Tiki-Taka'; },         get desc(){ return window.t?window.t('strategy.tiki_taka.desc')     :'Prioriza los pases cortos y la posesión para desgastar al rival y crear espacios.'; },     counters:'bloque_bajo',    partialCounters:['gegenpressing','presion_alta'] },
  contraataque:   { get name(){ return window.t?window.t('strategy.contraataque.name')  :'Contraataque'; },      get desc(){ return window.t?window.t('strategy.contraataque.desc')  :'Defiende con orden y busca atacar rápidamente tras recuperar el balón.'; },              counters:'ataque_bandas',  partialCounters:['posesion','presion_alta'] },
  catenaccio:     { get name(){ return window.t?window.t('strategy.catenaccio.name')    :'Catenaccio'; },        get desc(){ return window.t?window.t('strategy.catenaccio.desc')    :'Centra sus esfuerzos en la defensa y aprovecha las pocas oportunidades de ataque.'; },  counters:'juego_directo',  partialCounters:['ataque_bandas','presion_alta'] },
  presion_alta:   { get name(){ return window.t?window.t('strategy.presion_alta.name')  :'Presión Alta'; },      get desc(){ return window.t?window.t('strategy.presion_alta.desc')  :'Presiona al rival en su campo para recuperar el balón cuanto antes.'; },                counters:'tiki_taka',      partialCounters:['juego_directo','catenaccio'] },
  gegenpressing:  { get name(){ return window.t?window.t('strategy.gegenpressing.name') :'Gegenpressing'; },     get desc(){ return window.t?window.t('strategy.gegenpressing.desc') :'Tras perder la posesión, todo el equipo intenta recuperarla inmediatamente.'; },         counters:'posesion',       partialCounters:['catenaccio','juego_directo'] },
  posesion:       { get name(){ return window.t?window.t('strategy.posesion.name')      :'Juego de Posesión'; }, get desc(){ return window.t?window.t('strategy.posesion.desc')      :'Mantiene el control del balón para dominar el ritmo del partido.'; },                  counters:'contraataque',   partialCounters:['presion_alta','gegenpressing'] },
  juego_directo:  { get name(){ return window.t?window.t('strategy.juego_directo.name') :'Juego Directo'; },     get desc(){ return window.t?window.t('strategy.juego_directo.desc') :'Busca llegar al área rival con rapidez y el menor número de pases posible.'; },         counters:'gegenpressing',  partialCounters:['catenaccio','bloque_bajo'] },
  futbol_total:   { get name(){ return window.t?window.t('strategy.futbol_total.name')  :'Fútbol Total'; },      get desc(){ return window.t?window.t('strategy.futbol_total.desc')  :'Los jugadores intercambian posiciones constantemente para generar superioridades.'; },   counters:'catenaccio',     partialCounters:['bloque_bajo','contraataque'] },
  bloque_bajo:    { get name(){ return window.t?window.t('strategy.bloque_bajo.name')   :'Bloque Bajo'; },       get desc(){ return window.t?window.t('strategy.bloque_bajo.desc')   :'Repliega al equipo cerca de su área para cerrar espacios y dificultar los ataques rivales.'; }, counters:'futbol_total', partialCounters:['posesion','catenaccio'] },
  ataque_bandas:  { get name(){ return window.t?window.t('strategy.ataque_bandas.name') :'Ataque por Bandas'; }, get desc(){ return window.t?window.t('strategy.ataque_bandas.desc') :'Utiliza las bandas para crear peligro mediante desbordes y centros al área.'; },        counters:'presion_alta',   partialCounters:['contraataque','gegenpressing'] },
};
const STRATEGY_ORDER=["tiki_taka","contraataque","catenaccio","presion_alta","gegenpressing","posesion","juego_directo","futbol_total","bloque_bajo","ataque_bandas"];

// Map each of the 38 narrative team styles to one of the 10 match strategies,
// based on which strategy best reflects that team's footballing identity.
const TEAM_STYLE_TO_STRATEGY={
  tiki_taka:"tiki_taka", samba_total:"futbol_total", ataque_letal:"juego_directo",
  maquinaria_alemana:"presion_alta", gegenpressing:"gegenpressing", magia_individual:"contraataque",
  la_scaloneta:"contraataque", solidez_francesa:"bloque_bajo", velocidad_punzante:"ataque_bandas",
  catenaccio:"catenaccio", total_football:"futbol_total", naranja_mecanica:"tiki_taka",
  futbol_directo:"juego_directo", garra_lusa:"contraataque", muralla_balcanica:"catenaccio",
  garra_charrua:"bloque_bajo", once_oro_magiar:"tiki_taka", dinamita_danesa:"ataque_bandas",
  tricolor_tecnico:"posesion", garra_yanqui:"bloque_bajo", disciplina_nipona:"posesion",
  muralla_atlas:"catenaccio", superaguilas:"ataque_bandas", leones_indomables:"contraataque",
  garra_chilena:"presion_alta", muralla_guarani:"catenaccio", fiesta_cafetera:"posesion",
  vendaval_incaico:"ataque_bandas", disciplina_vikinga:"bloque_bajo", tecnica_centroeuropea:"posesion",
  tecnica_balcanica:"tiki_taka", wunderteam:"juego_directo", sistema_cerrojo:"catenaccio",
  furia_otomana:"presion_alta", milagro_defensivo:"bloque_bajo", magia_carpatica:"posesion",
  furia_tartan:"presion_alta", muralla_celta:"bloque_bajo", punta_lanza:"juego_directo",
  vikingo_directo:"juego_directo",
};
let selectedMatchStrategy=null; // strategy key chosen by the player for the upcoming match

let teams = rawTeams.map(function(t){
 const styleInfo = STYLES[t.style];
 return {
  name:t.name,
  flag:"es",
  _styleKey:t.style||"",
  style:styleInfo?styleInfo.name:(t.style?"Clásico":"Clásico"),
  bonuses:styleInfo?styleInfo.bonuses:(t.bonus?{attack:(t.bonus.ATAQUE||0),defense:(t.bonus.DEFENSA||0),pace:(t.bonus.RITMO||0),passing:(t.bonus.PASE||0),technique:(t.bonus.TÉCNICA||0)}:{}),
  players:t.players.map(function(pid){var p=playersDB.find(x=>x.id===pid); return p?{name:p.name,positions:p.positions||["MC"],rating:p.overall||75}:null;}).filter(Boolean)
 };
});
let dataLoaded=true;
console.log("Loaded",teams.length,"teams locally");

/* ========================================================
   GOAL2GOAT — GAME LOGIC
   ======================================================== */

/* ---------- AUDIO SYSTEM (synthesized, no files needed) ---------- */
let audioEnabled=true;
try{
  const savedAudio=localStorage.getItem('g2g_audioEnabled');
  if(savedAudio!==null) audioEnabled=(savedAudio==='true');
}catch(e){}
let audioCtx=null;
function getAudioCtx(){
  if(!audioCtx){
    try{ audioCtx=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){ audioCtx=null; }
  }
  if(audioCtx&&audioCtx.state==='suspended') audioCtx.resume();
  return audioCtx;
}
function tone(ctx, freq, start, dur, type, gainPeak, gainEnd){
  const osc=ctx.createOscillator();
  const gain=ctx.createGain();
  osc.type=type||'sine';
  osc.frequency.setValueAtTime(freq, ctx.currentTime+start);
  gain.gain.setValueAtTime(0.0001, ctx.currentTime+start);
  gain.gain.exponentialRampToValueAtTime(gainPeak||0.2, ctx.currentTime+start+0.01);
  gain.gain.exponentialRampToValueAtTime(gainEnd||0.0001, ctx.currentTime+start+dur);
  osc.connect(gain); gain.connect(ctx.destination);
  osc.start(ctx.currentTime+start);
  osc.stop(ctx.currentTime+start+dur+0.02);
}
/* Aviso sonoro para cualquier cuenta atrás del juego: suena una vez por
   segundo en los últimos 5 segundos, agudizándose cada vez; se resetea
   solo (vía el propio parámetro de segundos) en cuanto el contador
   vuelve a arrancar. 'key' evita que un timer que actualiza más rápido
   de 1 vez por segundo dispare el aviso varias veces en el mismo segundo. */
window._countdownBeepLast={};
function checkCountdownBeep(secondsLeft, key){
  const k=key||'default';
  if(secondsLeft>=1 && secondsLeft<=5){
    if(window._countdownBeepLast[k]!==secondsLeft){
      window._countdownBeepLast[k]=secondsLeft;
      playSound('countdown_tick', secondsLeft);
    }
  }else{
    window._countdownBeepLast[k]=null; // fuera del rango de aviso: listo para la próxima cuenta atrás
  }
}

/* Mantiene una barra fija pegada justo debajo del header mientras este
   es visible, y la sube a top:0 en cuanto el header sale de la vista al
   hacer scroll. Reutilizable por cualquier barra del duelo (draft,
   gestión entre partidos...) — mismo comportamiento en todas. */
window._mpStickyBarHandlers=window._mpStickyBarHandlers||{};
function mpAttachStickyBarScroll(barId){
  const headerEl=document.getElementById('appHeader');
  const update=()=>{
    const b=document.getElementById(barId);
    if(!b) return;
    if(!headerEl){ b.style.top='0px'; return; }
    const rect=headerEl.getBoundingClientRect();
    b.style.top=Math.max(0, rect.bottom)+'px';
  };
  if(window._mpStickyBarHandlers[barId]){
    window.removeEventListener('scroll', window._mpStickyBarHandlers[barId]);
  }
  window._mpStickyBarHandlers[barId]=update;
  window.addEventListener('scroll', update, {passive:true});
  update();
}
function mpDetachStickyBarScroll(barId){
  if(window._mpStickyBarHandlers[barId]){
    window.removeEventListener('scroll', window._mpStickyBarHandlers[barId]);
    window._mpStickyBarHandlers[barId]=null;
  }
}

function playSound(name, data){
  if(!audioEnabled) return;
  const ctx=getAudioCtx();
  if(!ctx) return;
  switch(name){
    case 'countdown_tick': { // aviso de cuenta atrás — más agudo cada segundo (5..1)
      const secLeft=(typeof data==='number')?data:1;
      const step=Math.max(0, 5-secLeft); // 0 en el aviso de 5s, 4 en el de 1s
      const freq=700+step*90;
      tone(ctx, freq, 0, 0.09, 'square', 0.11, 0.0001);
      break;
    }
    case 'select': // simple menu click
      tone(ctx, 880, 0, 0.07, 'square', 0.08, 0.0001);
      break;
    case 'spin': // slot-machine tick (called repeatedly while reels spin)
      tone(ctx, 520+Math.random()*120, 0, 0.045, 'square', 0.05, 0.0001);
      break;
    case 'reveal': // result of the spin lands
      tone(ctx, 660, 0, 0.09, 'triangle', 0.12, 0.0001);
      tone(ctx, 990, 0.05, 0.12, 'triangle', 0.10, 0.0001);
      break;
    case 'goal': // football-style rising "goooal" sting
      tone(ctx, 440, 0, 0.12, 'sawtooth', 0.10, 0.0001);
      tone(ctx, 660, 0.1, 0.12, 'sawtooth', 0.10, 0.0001);
      tone(ctx, 880, 0.2, 0.18, 'sawtooth', 0.12, 0.0001);
      break;
    case 'victory': // upbeat fanfare arpeggio
      [523,659,784,1046,1318].forEach((f,i)=>tone(ctx, f, i*0.11, 0.28, 'triangle', 0.14, 0.0001));
      break;
    case 'defeat': // descending sad tone + low thud
      [392,349,294,196].forEach((f,i)=>tone(ctx, f, i*0.16, 0.35, 'sawtooth', 0.10, 0.0001));
      tone(ctx, 80, 0.5, 0.4, 'sine', 0.18, 0.0001);
      break;
    case 'whistle': // referee whistle for match start/end accents
      tone(ctx, 1800, 0, 0.18, 'square', 0.06, 0.0001);
      tone(ctx, 2000, 0.16, 0.16, 'square', 0.06, 0.0001);
      break;
    case 'scratch_good': // casilla buena al rascar — pitch pasado como data
      tone(ctx, 520, 0, 0.06, 'sine', 0.10, 0.0001);
      tone(ctx, 780, 0.04, 0.09, 'sine', 0.08, 0.0001);
      break;
    case 'scratch_star': // casilla cabra — más dramático
      [520,660,880,1100].forEach((f,i)=>tone(ctx, f, i*0.06, 0.10, 'triangle', 0.12, 0.0001));
      break;
    case 'scratch_bomb': // casilla bomba — sonido de derrumbe
      [300,240,180,120].forEach((f,i)=>tone(ctx, f, i*0.07, 0.15, 'sawtooth', 0.12, 0.0001));
      tone(ctx, 80, 0.28, 0.4, 'sine', 0.18, 0.0001);
      break;
  }
}

/* ---------- STYLE HINTS for rivals ---------- */
const STYLE_HINTS = {
  get jogo_bonito()          { return window.t?window.t('style.jogo_bonito')          :'El fútbol más bonito y creativo. Sus jugadores pueden resolver el partido en cualquier momento.'; },
  get gegenpress()           { return window.t?window.t('style.gegenpress')           :'Presión tras pérdida y transiciones rápidas. No dan descanso al rival.'; },
  get defensivo()            { return window.t?window.t('style.defensivo')            :'Bloque compacto y salida rápida. Peligrosos en el contragolpe.'; },
  get directo()              { return window.t?window.t('style.directo')              :'Juego vertical y ritmo alto. No dan tiempo a pensar.'; },
  get contraataque()         { return window.t?window.t('style.contraataque')         :'Espera y golpea. Letales cuando tienen espacios.'; },
  get tiki_taka()            { return window.t?window.t('style.tiki_taka')            :'Dominan el balón y presionan en campo rival desde el primer minuto, pero un bloque bajo y bien plantado les incomoda, y la velocidad a la espalda les genera muchos problemas.'; },
  get samba_total()          { return window.t?window.t('style.samba_total')          :'Su ataque desborda con calidad individual, pero a cambio dejan huecos enormes en defensa que cualquier transición rápida puede aprovechar.'; },
  get catenaccio()           { return window.t?window.t('style.catenaccio')           :'Apenas conceden ocasiones claras, un bloque bajo y compacto que sostiene el resultado durante los noventa minutos sin apenas despeinarse.'; },
  get gegenpressing()        { return window.t?window.t('style.gegenpressing')        :'Presionan sin descanso y recuperan el balón muy arriba, agotando físicamente al rival que intenta jugar con calma desde atrás.'; },
  get total_football()       { return window.t?window.t('style.total_football')       :'Rotan posiciones constantemente y atacan desde cualquier zona del campo, lo que exige mantener el orden colectivo en todo momento.'; },
  get maquinaria_alemana()   { return window.t?window.t('style.maquinaria_alemana')   :'Eficientes y disciplinados, sin apenas fisuras durante el partido, un rival que no perdona los errores propios.'; },
  get magia_individual()     { return window.t?window.t('style.magia_individual')     :'Casi todo su peligro pasa por un par de jugadores desequilibrantes; el resto del equipo pasa bastante desapercibido.'; },
  get garra_charrua()        { return window.t?window.t('style.garra_charrua')        :'Entrega física y mentalidad guerrera por encima de todo, aunque a veces les falta algo de calidad con el balón en los pies.'; },
  get ataque_letal()         { return window.t?window.t('style.ataque_letal')         :'Tienen una delantera que castiga cualquier error, aunque su defensa concede más ocasiones de las que debería.'; },
  get solidez_francesa()     { return window.t?window.t('style.solidez_francesa')     :'Defensa muy sólida y poco vistosa, pero les cuesta generar peligro real cuando tienen el balón.'; },
  get velocidad_punzante()   { return window.t?window.t('style.velocidad_punzante')   :'Transiciones rapidísimas que castigan cualquier espacio dejado a la espalda de la defensa.'; },
  get garra_lusa()           { return window.t?window.t('style.garra_lusa')           :'Intensidad física y calidad individual en los duelos uno contra uno por todo el campo.'; },
  get futbol_directo()       { return window.t?window.t('style.futbol_directo')       :'Apuestan por el juego directo y los balones largos, con pocas florituras pero mucha insistencia en los duelos aéreos.'; },
  get naranja_mecanica()     { return window.t?window.t('style.naranja_mecanica')     :'Creativos y técnicos, capaces de generar peligro desde cualquier posición del campo.'; },
  get muralla_balcanica()    { return window.t?window.t('style.muralla_balcanica')    :'Una defensa paciente y muy difícil de superar, que espera su momento sin precipitarse.'; },
  get muralla_atlas()        { return window.t?window.t('style.muralla_atlas')        :'Su organización defensiva ha sorprendido a selecciones mucho más reputadas en los últimos torneos.'; },
  get once_oro_magiar()      { return window.t?window.t('style.once_oro_magiar')      :'Uno de los ataques más prolíficos de la historia, capaz de anotar con facilidad ante cualquier rival.'; },
  get dinamita_danesa()      { return window.t?window.t('style.dinamita_danesa')      :'Un equipo impredecible que, en su mejor versión, puede complicarle la vida a cualquiera.'; },
  get garra_española()       { return window.t?window.t('style.garra_española')       :'Energía y lucha constante, aunque a veces la pasión les pesa más que la calidad técnica.'; },
  get disciplina_nipona()    { return window.t?window.t('style.disciplina_nipona')    :'Muy organizados y trabajadores, aunque con poco peligro real cuando llegan al área rival.'; },
  get disciplina_vikinga()   { return window.t?window.t('style.disciplina_vikinga')   :'Un bloque ordenado y físico, sin demasiadas individualidades que desequilibren el partido.'; },
  get fiesta_cafetera()      { return window.t?window.t('style.fiesta_cafetera')      :'Mucho talento técnico y ofensivo, aunque su defensa muestra dudas de vez en cuando.'; },
  get furia_otomana()        { return window.t?window.t('style.furia_otomana')        :'Juegan con mucha intensidad y pasión, al límite en cada disputa del partido.'; },
  get furia_tartan()         { return window.t?window.t('style.furia_tartan')         :'Carácter combativo y fuertes en el choque, aunque algo limitados con el balón en los pies.'; },
  get garra_chilena()        { return window.t?window.t('style.garra_chilena')        :'Compensan con actitud y lucha lo que les pueda faltar en calidad técnica.'; },
  get garra_yanqui()         { return window.t?window.t('style.garra_yanqui')         :'Físicos, disciplinados y muy difíciles de batir por la mínima diferencia.'; },
  get la_scaloneta()         { return window.t?window.t('style.la_scaloneta')         :'Un bloque sólido con un líder de clase mundial arriba, muy completos en todas las líneas.'; },
  get leones_indomables()    { return window.t?window.t('style.leones_indomables')    :'Explosivos físicamente y muy peligrosos cuando encuentran espacios para correr al contraataque.'; },
  get magia_carpatica()      { return window.t?window.t('style.magia_carpatica')      :'Jugadores con mucho talento individual, aunque algo inconsistentes como conjunto.'; },
  get milagro_defensivo()    { return window.t?window.t('style.milagro_defensivo')    :'Un bloque muy disciplinado que ya ha frenado a algunos de los mejores ataques del mundo.'; },
  get muralla_celta()        { return window.t?window.t('style.muralla_celta')        :'Defensa férrea y muy compacta, conceden muy pocas ocasiones claras durante el partido.'; },
  get muralla_guarani()      { return window.t?window.t('style.muralla_guarani')      :'Defensa sacrificada y muy ordenada, suben pocos jugadores cuando atacan.'; },
  get punta_lanza()          { return window.t?window.t('style.punta_lanza')          :'Su peligro ofensivo depende en gran medida de un delantero de referencia que marca la diferencia.'; },
  get sistema_cerrojo()      { return window.t?window.t('style.sistema_cerrojo')      :'Un bloque ultra defensivo cuya prioridad absoluta es no encajar goles, cueste lo que cueste.'; },
  get tecnica_balcanica()    { return window.t?window.t('style.tecnica_balcanica')    :'Buen toque de balón y jugadores con clase, aunque defensivamente pueden mostrar algunas dudas.'; },
  get tecnica_centroeuropea(){ return window.t?window.t('style.tecnica_centroeuropea'):'Técnica depurada y buen juego colectivo, con un ritmo de partido más bien pausado.'; },
  get tricolor_tecnico()     { return window.t?window.t('style.tricolor_tecnico')     :'Habilidosos y vistosos con el balón, aunque pueden verse superados ante la intensidad.'; },
  get vendaval_incaico()     { return window.t?window.t('style.vendaval_incaico')     :'Buen toque de balón y jugadores desequilibrantes cuando llegan a campo rival.'; },
  get vikingo_directo()      { return window.t?window.t('style.vikingo_directo')      :'Físicos y directos, especialmente peligrosos en el juego aéreo.'; },
  get superaguilas()         { return window.t?window.t('style.superaguilas')         :'Explosivos físicamente, con jugadores desequilibrantes que aprovechan los espacios a la carrera.'; },
  get wunderteam()           { return window.t?window.t('style.wunderteam')           :'Un equipo técnico y ofensivo con una gran tradición histórica a sus espaldas.'; },
};

/* ---------- TEAM SCOUT HINTS ---------- */
function getScoutHint(team){
  const s = team._styleKey || '';
  // Purely descriptive — never names the strategy or tells the player what to pick.
  // The player must read between the lines and deduce the right counter themselves.
  return STYLE_HINTS[s] || "Información de scouting no disponible. Prepárate para cualquier escenario.";
}

/* ---------- STATE ---------- */
const teamStats = { attack:0, defense:0, pace:0, passing:0, technique:0 };
let selectedPlayer = null;
let phase = "draft"; // draft | bench | ready
// Variables del monitor de inactividad de duelo — declaradas aquí,
// pronto, porque initDuelModeFromSession() se llama muy al principio
// del script y las necesita disponibles desde ese momento.
let _duelLastInteraction=Date.now();
let _duelInactivityInterval=null;
let _duelInteractionListenersAttached=false;
const DUEL_DRAFT_SECONDS=90; // duración del draft sincronizado en duelos multijugador
let usedPlayers = [];
let bench = [];
let draftedCount = 0;
/* Torneo en curso: mismo criterio que ya usa el juego para bloquear el
   cambio de formación una vez empezado el draft. Se usa para impedir
   comprar/vender mejoras y habilidades a mitad de un torneo (anti-trampas). */
function isTournamentInProgress(){ return phase!=="draft" || draftedCount>0; }
let baseTeamOVR = null;
let benchCount = 0;
let nextOpponent = null;
let swapsUsedThisMatch = 0;

/* ========= ROGUELIKE SYSTEMS STATE ========= */
// Morale: -50 to +50, starts at 0, affects match lambda
let teamMorale = 0;
window.CHEATS_ACTIVE = false;
const CHEAT_USERS = ['jesuslor85@gmail.com', 'silviaenfoque@gmail.com'];
// Scorer streaks: map playerName -> consecutive matches scored
let scorerStreaks = {};
// Current match weather
let currentWeather = null;
// Inherited players from previous run (names)
let inheritedPlayers = [];
// Best knockout round reached in current run (for chain run reward)
let bestRoundReached = -1; // -1=none, 0=groups, 1=octavos, 2=cuartos, 3=semis, 4=final
const WEATHER_TYPES = [
  { id:'sunny',  get label(){ return window.t?window.t('weather.sunny.label') :'☀ Soleado'; },       get desc(){ return window.t?window.t('weather.sunny.desc') :'Calor intenso · RITMO -15% ambos equipos'; },    effect:{pace:-0.10} },
  { id:'cloudy', get label(){ return window.t?window.t('weather.cloudy.label'):'⛅ Nublado'; },        get desc(){ return window.t?window.t('weather.cloudy.desc'):'Condiciones neutras'; },                         effect:{} },
  { id:'rain',   get label(){ return window.t?window.t('weather.rain.label')  :'🌧 Lluvia'; },         get desc(){ return window.t?window.t('weather.rain.desc')  :'Campo pesado · RITMO -20%, TÉCNICA -10%'; },    effect:{pace:-0.15,technique:-0.08} },
  { id:'wind',   get label(){ return window.t?window.t('weather.wind.label')  :'💨 Viento fuerte'; },  get desc(){ return window.t?window.t('weather.wind.desc')  :'Juego directo · PASE -15%'; },                  effect:{passing:-0.12} },
  { id:'hot',    get label(){ return window.t?window.t('weather.hot.label')   :'🌡 Calor extremo'; },  get desc(){ return window.t?window.t('weather.hot.desc')   :'Fatiga máxima · RITMO -25%, DEFENSA -10%'; },  effect:{pace:-0.20,defense:-0.08} },
];
/* Predictive pre-match press questions: shown when the rival is revealed,
   BEFORE the match is played. Each answer is a prediction (positive/neutral/
   negative). After the match, the prediction is checked against the real
   result: correct guess -> moral up, wrong guess -> moral down, neutral
   answer -> moral stays the same regardless of outcome. */
function getPressEvents(){
  const t=k=>window.t?window.t(k):k;
  return [
    { get q(){ return t('press.q0'); }, answers: [
      { get text(){ return t('press.q0a0.text'); }, stance:"positive", get label(){ return t('press.q0a0.label'); }, check:(r)=>r.oppGoals===0 },
      { get text(){ return t('press.q0a1.text'); }, stance:"neutral",  get label(){ return t('press.q0a1.label'); }, check:()=>null },
      { get text(){ return t('press.q0a2.text'); }, stance:"negative", get label(){ return t('press.q0a2.label'); }, check:(r)=>r.oppGoals>0 },
    ]},
    { get q(){ return t('press.q1'); }, answers: [
      { get text(){ return t('press.q1a0.text'); }, stance:"positive", get label(){ return t('press.q1a0.label'); }, check:(r)=>(r.myGoals-r.oppGoals)>=3 },
      { get text(){ return t('press.q1a1.text'); }, stance:"neutral",  get label(){ return t('press.q1a1.label'); }, check:()=>null },
      { get text(){ return t('press.q1a2.text'); }, stance:"negative", get label(){ return t('press.q1a2.label'); }, check:(r)=>(r.myGoals-r.oppGoals)<3 },
    ]},
    { get q(){ return t('press.q2'); }, answers: [
      { get text(){ return t('press.q2a0.text'); }, stance:"positive", get label(){ return t('press.q2a0.label'); }, check:(r)=>r.cardsCount===0 },
      { get text(){ return t('press.q2a1.text'); }, stance:"neutral",  get label(){ return t('press.q2a1.label'); }, check:()=>null },
      { get text(){ return t('press.q2a2.text'); }, stance:"negative", get label(){ return t('press.q2a2.label'); }, check:(r)=>r.cardsCount>0 },
    ]},
    { get q(){ return t('press.q3'); }, answers: [
      { get text(){ return t('press.q3a0.text'); }, stance:"positive", get label(){ return t('press.q3a0.label'); }, check:(r)=>r.myGoals>0 },
      { get text(){ return t('press.q3a1.text'); }, stance:"neutral",  get label(){ return t('press.q3a1.label'); }, check:()=>null },
      { get text(){ return t('press.q3a2.text'); }, stance:"negative", get label(){ return t('press.q3a2.label'); }, check:(r)=>r.myGoals===0 },
    ]},
    { get q(){ return t('press.q4'); }, answers: [
      { get text(){ return t('press.q4a0.text'); }, stance:"positive", get label(){ return t('press.q4a0.label'); }, check:(r)=>r.myGoals>=r.oppGoals },
      { get text(){ return t('press.q4a1.text'); }, stance:"neutral",  get label(){ return t('press.q4a1.label'); }, check:()=>null },
      { get text(){ return t('press.q4a2.text'); }, stance:"negative", get label(){ return t('press.q4a2.label'); }, check:(r)=>r.oppGoals>r.myGoals },
    ]},
    { get q(){ return t('press.q5'); }, answers: [
      { get text(){ return t('press.q5a0.text'); }, stance:"positive", get label(){ return t('press.q5a0.label'); }, check:(r)=>!r.penalties },
      { get text(){ return t('press.q5a1.text'); }, stance:"neutral",  get label(){ return t('press.q5a1.label'); }, check:()=>null },
      { get text(){ return t('press.q5a2.text'); }, stance:"negative", get label(){ return t('press.q5a2.label'); }, check:(r)=>r.penalties },
    ]},
    { get q(){ return t('press.q6'); }, answers: [
      { get text(){ return t('press.q6a0.text'); }, stance:"positive", get label(){ return t('press.q6a0.label'); }, check:(r)=>r.myGoals>1 },
      { get text(){ return t('press.q6a1.text'); }, stance:"neutral",  get label(){ return t('press.q6a1.label'); }, check:()=>null },
      { get text(){ return t('press.q6a2.text'); }, stance:"negative", get label(){ return t('press.q6a2.label'); }, check:(r)=>r.myGoals<=1 },
    ]},
    { get q(){ return t('press.q7'); }, answers: [
      { get text(){ return t('press.q7a0.text'); }, stance:"positive", get label(){ return t('press.q7a0.label'); }, check:(r)=>r.oppGoals<2 },
      { get text(){ return t('press.q7a1.text'); }, stance:"neutral",  get label(){ return t('press.q7a1.label'); }, check:()=>null },
      { get text(){ return t('press.q7a2.text'); }, stance:"negative", get label(){ return t('press.q7a2.label'); }, check:(r)=>r.oppGoals>=2 },
    ]},
    { get q(){ return t('press.q8'); }, answers: [
      { get text(){ return t('press.q8a0.text'); }, stance:"positive", get label(){ return t('press.q8a0.label'); }, check:(r)=>!r.draw },
      { get text(){ return t('press.q8a1.text'); }, stance:"neutral",  get label(){ return t('press.q8a1.label'); }, check:()=>null },
      { get text(){ return t('press.q8a2.text'); }, stance:"negative", get label(){ return t('press.q8a2.label'); }, check:(r)=>r.draw },
    ]},
    { get q(){ return t('press.q9'); }, answers: [
      { get text(){ return t('press.q9a0.text'); }, stance:"positive", get label(){ return t('press.q9a0.label'); }, check:(r)=>r.myGoals>0 },
      { get text(){ return t('press.q9a1.text'); }, stance:"neutral",  get label(){ return t('press.q9a1.label'); }, check:()=>null },
      { get text(){ return t('press.q9a2.text'); }, stance:"negative", get label(){ return t('press.q9a2.label'); }, check:(r)=>r.myGoals===0 },
    ]},
    { get q(){ return t('press.q10'); }, answers: [
      { get text(){ return t('press.q10a0.text'); }, stance:"positive", get label(){ return t('press.q10a0.label'); }, check:(r)=>r.cardsCount===0 },
      { get text(){ return t('press.q10a1.text'); }, stance:"neutral",  get label(){ return t('press.q10a1.label'); }, check:()=>null },
      { get text(){ return t('press.q10a2.text'); }, stance:"negative", get label(){ return t('press.q10a2.label'); }, check:(r)=>r.cardsCount>0 },
    ]},
    { get q(){ return t('press.q11'); }, answers: [
      { get text(){ return t('press.q11a0.text'); }, stance:"positive", get label(){ return t('press.q11a0.label'); }, check:(r)=>(r.myGoals+r.oppGoals)>=3 },
      { get text(){ return t('press.q11a1.text'); }, stance:"neutral",  get label(){ return t('press.q11a1.label'); }, check:()=>null },
      { get text(){ return t('press.q11a2.text'); }, stance:"negative", get label(){ return t('press.q11a2.label'); }, check:(r)=>(r.myGoals+r.oppGoals)<3 },
    ]},
  ];
}
const PRESS_PREDICTIONS = getPressEvents(); // backward compat — will be replaced by call below
// getMaxSubs() reemplazado por getMaxSubs() dinámico

/* ========= COMPETITION STATE (World Cup format) ========= */
const ROUND_NAMES = ["Octavos de Final","Cuartos de Final","Semifinal","Final"];
function getRoundName(idx){ try{ return [t("comp.r16"),t("comp.qf"),t("comp.sf"),t("comp.final")][idx]||ROUND_NAMES[idx]||""; }catch(e){ return ROUND_NAMES[idx]||""; } }
let stage = "group";        // "group" | "knockout" | "done"
let groupOpponents = [];    // 3 team objects for this group
let groupMatchIdx = 0;       // 0,1,2 — which group match is next
let groupTable = [];         // standings rows: {name, team|null, played, won, drawn, lost, gf, ga, pts}
let knockoutRound = 0;       // 0=Octavos,1=Cuartos,2=Semis,3=Final
let knockoutPool = [];       // remaining pool of teams for future knockout rounds
let matchResults = [];       // flat history of all matches played, for display

/* ---------- FORMATIONS ---------- */
// Formations are now PURELY visual/layout — they define where the 11 pitch
// slots are placed, but give NO stat bonus. The stat bonus now comes from
// the per-match STRATEGY chosen against each rival (see STRATEGIES above).
const FORMATIONS = {
  ofensiva:[
    {code:"3-4-3",   get label(){ return window.t?window.t('formation.label.3-4-3.ofensiva')  :'Ataque total'; },        bonus:{attack:13,defense:3,passing:7,pace:11,technique:6}},
    {code:"3-4-1-2", get label(){ return window.t?window.t('formation.label.3-4-1-2.ofensiva'):'Mediapunta creativo'; },  bonus:{attack:9,defense:4,passing:12,pace:7,technique:8}},
    {code:"4-2-4",   get label(){ return window.t?window.t('formation.label.4-2-4.ofensiva')  :'Brasil clásico'; },       bonus:{attack:16,defense:6,passing:4,pace:10,technique:4}},
    {code:"4-3-3",   get label(){ return window.t?window.t('formation.label.4-3-3.ofensiva')  :'Tridente Ofensivo'; },    bonus:{attack:11,defense:5,passing:8,pace:7,technique:9}},
    {code:"4-2-3-1", get label(){ return window.t?window.t('formation.label.4-2-3-1.ofensiva'):'Extremos al ataque'; },   bonus:{attack:8,defense:6,passing:11,pace:9,technique:6}},
    {code:"3-5-2",   get label(){ return window.t?window.t('formation.label.3-5-2.ofensiva')  :'Superioridad central'; }, bonus:{attack:7,defense:4,passing:13,pace:8,technique:8}},
    {code:"2-3-5",   get label(){ return window.t?window.t('formation.label.2-3-5.ofensiva')  :'Vintage ofensivo'; },     bonus:{attack:15,defense:2,passing:6,pace:13,technique:4}},
  ],
  equilibrada:[
    {code:"4-4-2",   get label(){ return window.t?window.t('formation.label.4-4-2.equilibrada')  :'El clásico'; },          bonus:{attack:8,defense:8,passing:8,pace:8,technique:8}},
    {code:"4-3-3",   get label(){ return window.t?window.t('formation.label.4-3-3.equilibrada')  :'Posesión y ataque'; },    bonus:{attack:12,defense:5,passing:9,pace:8,technique:6}},
    {code:"4-1-4-1", get label(){ return window.t?window.t('formation.label.4-1-4-1.equilibrada'):'Sólido en todo'; },       bonus:{attack:6,defense:10,passing:12,pace:5,technique:7}},
    {code:"4-2-3-1", get label(){ return window.t?window.t('formation.label.4-2-3-1.equilibrada'):'Fútbol moderno'; },       bonus:{attack:7,defense:7,passing:13,pace:6,technique:7}},
    {code:"4-3-1-2", get label(){ return window.t?window.t('formation.label.4-3-1-2.equilibrada'):'Control + 2 puntas'; },   bonus:{attack:10,defense:6,passing:10,pace:7,technique:7}},
    {code:"3-5-2",   get label(){ return window.t?window.t('formation.label.3-5-2.equilibrada')  :'Carrileros activos'; },   bonus:{attack:8,defense:5,passing:11,pace:9,technique:7}},
    {code:"4-5-1",   get label(){ return window.t?window.t('formation.label.4-5-1.equilibrada')  :'Defensivo+contragol'; },  bonus:{attack:5,defense:11,passing:10,pace:6,technique:8}},
  ],
  defensiva:[
    {code:"5-4-1",   get label(){ return window.t?window.t('formation.label.5-4-1.defensiva')  :'Fortaleza'; },           bonus:{attack:4,defense:16,passing:8,pace:5,technique:7}},
    {code:"5-3-2",   get label(){ return window.t?window.t('formation.label.5-3-2.defensiva')  :'5 atrás + 2 arriba'; }, bonus:{attack:7,defense:18,passing:6,pace:5,technique:4}},
    {code:"4-5-1",   get label(){ return window.t?window.t('formation.label.4-5-1.defensiva')  :'Bloque compacto'; },     bonus:{attack:4,defense:12,passing:11,pace:4,technique:9}},
    {code:"4-1-4-1", get label(){ return window.t?window.t('formation.label.4-1-4-1.defensiva'):'Pivote protector'; },    bonus:{attack:5,defense:14,passing:9,pace:4,technique:8}},
    {code:"3-6-1",   get label(){ return window.t?window.t('formation.label.3-6-1.defensiva')  :'Muro defensivo'; },      bonus:{attack:3,defense:9,passing:15,pace:3,technique:10}},
    {code:"5-2-2-1", get label(){ return window.t?window.t('formation.label.5-2-2-1.defensiva'):'Contragolpe'; },         bonus:{attack:6,defense:17,passing:5,pace:8,technique:4}},
    {code:"6-3-1",   get label(){ return window.t?window.t('formation.label.6-3-1.defensiva')  :'Ultra defensivo'; },     bonus:{attack:3,defense:22,passing:6,pace:4,technique:5}},
  ]
};
const CAT_NAMES={
  get ofensiva(){ return window.t?window.t('formation.offensive'):'Ofensiva'; },
  get equilibrada(){ return window.t?window.t('formation.balanced'):'Equilibrada'; },
  get defensiva(){ return window.t?window.t('formation.defensive'):'Defensiva'; },
};
// Short, neutral one-line description per formation code (shown after the squad is locked)
const FORMATION_DESC={
  get "3-4-3"()   { return window.t?window.t('formation.desc.3-4-3')  :'Tres centrales y tres delanteros: máxima presencia ofensiva.'; },
  get "3-4-1-2"() { return window.t?window.t('formation.desc.3-4-1-2'):'Línea de 3 con un mediapunta libre entre líneas.'; },
  get "4-2-4"()   { return window.t?window.t('formation.desc.4-2-4')  :'Cuatro atacantes apoyados por solo dos centrocampistas.'; },
  get "4-3-3"()   { return window.t?window.t('formation.desc.4-3-3')  :'Equilibrio clásico entre posesión y ancho ofensivo.'; },
  get "4-2-3-1"() { return window.t?window.t('formation.desc.4-2-3-1'):'Doble pivote y un enganche que conecta con la punta.'; },
  get "3-5-2"()   { return window.t?window.t('formation.desc.3-5-2')  :'Carrileros que suben por banda y dos puntas arriba.'; },
  get "2-3-5"()   { return window.t?window.t('formation.desc.2-3-5')  :'Formación vintage con cinco hombres en ataque.'; },
  get "4-4-2"()   { return window.t?window.t('formation.desc.4-4-2')  :'El dibujo más clásico: simetría y bloques compactos.'; },
  get "4-1-4-1"() { return window.t?window.t('formation.desc.4-1-4-1'):'Pivote defensivo que protege la línea de cuatro.'; },
  get "4-3-1-2"() { return window.t?window.t('formation.desc.4-3-1-2'):'Mediocentro creativo entre la medular y la delantera.'; },
  get "4-5-1"()   { return window.t?window.t('formation.desc.4-5-1')  :'Línea de cinco en el centro, un único punta de referencia.'; },
  get "5-4-1"()   { return window.t?window.t('formation.desc.5-4-1')  :'Cinco defensas para cerrar todos los espacios.'; },
  get "5-3-2"()   { return window.t?window.t('formation.desc.5-3-2')  :'Bloque de cinco atrás con doble delantero al contragolpe.'; },
  get "3-6-1"()   { return window.t?window.t('formation.desc.3-6-1')  :'Seis hombres en el medio, máxima cautela ofensiva.'; },
  get "5-2-2-1"() { return window.t?window.t('formation.desc.5-2-2-1'):'Defensa numerosa pensada para salir rápido a la contra.'; },
  get "6-3-1"()   { return window.t?window.t('formation.desc.6-3-1')  :'El mayor número de defensas posible en el campo.'; },
};
let currentFormation={category:"equilibrada",code:"4-4-2"};
let currentFormationBonus={};
let formationIsLocked=false; // set true the moment SELECCIONAR JUGADOR/EQUIPO RÁPIDO is pressed

/* ---------- DOM REFS ---------- */
const rollBtn = document.getElementById("rollBtn");
// Use the correct card container based on viewport
function getPlayerCardEl(){
  return window.innerWidth<=1050
    ? document.getElementById("playerCard")
    : document.getElementById("playerCardDesktop");
}
const playerCardEl = document.getElementById("playerCardDesktop"); // desktop: right panel
const pitchEl = document.getElementById("pitch");

/* Scroll the relevant area into view on mobile/tablet, so the user always
   sees what just happened (slot machine, roster, pitch placement...). */
function scrollToEl(id, delay, block){
  if(window.innerWidth>1050) return;
  setTimeout(()=>{
    const el=document.getElementById(id);
    if(el) el.scrollIntoView({behavior:"smooth", block: block||"start"});
  }, delay||30);
}
function scrollToCenter(id, delay){
  scrollToEl(id, delay, "center");
}

/* Explicit, tactically-correct layout per formation code. Each entry lists
   the line-by-line position labels exactly as a real formation would be
   drawn — e.g. a 4-3-3's midfield trio is three central midfielders (MC),
   not a winger-mediocentro-winger line (that would be a 4-3-3 with wide
   forwards instead, which is already represented by the EI/DC/ED attack
   line). This replaces the old generic n-based heuristic that mislabeled
   several formations (e.g. 4-3-3 showed EI/MC/ED instead of MC/MC/MC).
   Only the 8 position codes that exist in the player database are used
   (POR, DFC, LI, LD, MC, EI, ED, DC) — no MCD/MP, since no player owns
   those labels and it would make those slots impossible to fill with a★. */
const FORMATION_LAYOUTS = {
  "2-3-5":    [["POR"],["DFC","DFC"],["MC","MC","MC"],["EI","DC","DC","DC","ED"]],
  "3-4-3":    [["POR"],["DFC","DFC","DFC"],["LI","MC","MC","LD"],["EI","DC","ED"]],
  "3-4-1-2":  [["POR"],["DFC","DFC","DFC"],["LI","MC","MC","LD"],["MC"],["DC","DC"]],
  "3-5-2":    [["POR"],["DFC","DFC","DFC"],["LI","MC","MC","MC","LD"],["DC","DC"]],
  "3-6-1":    [["POR"],["DFC","DFC","DFC"],["LI","MC","MC","MC","MC","LD"],["DC"]],
  "4-1-4-1":  [["POR"],["LI","DFC","DFC","LD"],["MC"],["EI","MC","MC","ED"],["DC"]],
  "4-2-3-1":  [["POR"],["LI","DFC","DFC","LD"],["MC","MC"],["EI","MC","ED"],["DC"]],
  "4-2-4":    [["POR"],["LI","DFC","DFC","LD"],["MC","MC"],["EI","DC","DC","ED"]],
  "4-3-1-2":  [["POR"],["LI","DFC","DFC","LD"],["MC","MC","MC"],["MC"],["DC","DC"]],
  "4-3-3":    [["POR"],["LI","DFC","DFC","LD"],["MC","MC","MC"],["EI","DC","ED"]],
  "4-4-2":    [["POR"],["LI","DFC","DFC","LD"],["EI","MC","MC","ED"],["DC","DC"]],
  "4-5-1":    [["POR"],["LI","DFC","DFC","LD"],["LI","MC","MC","MC","LD"],["DC"]],
  "5-2-2-1":  [["POR"],["LI","DFC","DFC","DFC","LD"],["MC","MC"],["EI","ED"],["DC"]],
  "5-3-2":    [["POR"],["LI","DFC","DFC","DFC","LD"],["MC","MC","MC"],["DC","DC"]],
  "5-4-1":    [["POR"],["LI","DFC","DFC","DFC","LD"],["LI","MC","MC","LD"],["DC"]],
  "6-3-1":    [["POR"],["LI","DFC","DFC","DFC","DFC","LD"],["MC","MC","MC"],["DC"]],
};


/* ---------- INIT ---------- */
// Sync the profile's "NOTAS DE LA VERSIÓN" tab label with the actual
// version tag in the header, so they never go out of sync.
(function(){
  const versionTagEl=document.querySelector(".version-tag");
  const profileVersionEl=document.getElementById("profileVersionLabel");
  if(versionTagEl && profileVersionEl) profileVersionEl.textContent=versionTagEl.textContent;
})();
const inheritedBonus=restoreInheritedFormation();
applyFormationBonus(inheritedBonus || FORMATIONS.equilibrada.find(f=>f.code==="4-4-2").bonus);
renderPitch(currentFormation.code);
renderFormationList(currentFormation.category);
// Sync the category tab buttons (Ofensiva/Equilibrada/Defensiva) with
// whichever category the restored (or default) formation belongs to.
document.querySelectorAll(".formation-tab").forEach(tab=>{
  tab.classList.toggle("active", tab.dataset.cat===currentFormation.category);
});
updateStats();
updateDraftCounter();
renderMobileFormationInfo();
relocateFormationPickerForViewport();
window.addEventListener("resize", relocateFormationPickerForViewport);
// Apply translations after DOM relocation so data-i18n-html elements are in final position
if(window.applyTranslations) window.applyTranslations();

/* On mobile, the formation picker must be reachable from the FORMACIÓN tab
   (center-panel, which is always visible) — not buried inside the EQUIPO
   tab's left-panel (hidden by default). We physically move the DOM node. */
/* On desktop, CÓMO JUGAR and PARA QUÉ SIRVE are collapsible accordions —
   open by default, collapse to a compact title bar on click. Mobile shows
   the same content inside the INFORMACIÓN tab instead (always expanded). */
function toggleCollapsible(boxId){
  const box=document.getElementById(boxId);
  if(!box) return;
  playSound('select');
  box.classList.toggle("collapsed");
}

/* ========= ¿SABÍAS QUÉ...? TIPS ========= */
function getGameTips(){
  return [
    window.t ? window.t('tips.0') : '💡 Regístrate para guardar tu progreso y acceder a contenido exclusivo.',
    window.t ? window.t('tips.1') : '💡 Un jugador cansado rendirá peor en el campo, controla su resistencia.',
    window.t ? window.t('tips.2') : '💡 Conoce a tu rival. Elegir una buena estrategia puede marcar la diferencia.',
  ];
}
let currentTipIndex=0;
let tipRotationTimer=null;
function renderCurrentTip(){
  const el=document.getElementById("tipText");
  if(!el) return;
  // Update immediately so the correct text shows at once
  el.textContent=getGameTips()[currentTipIndex];
  // Then do the fade animation
  el.classList.add("tip-fading");
  setTimeout(()=>{
    el.textContent=getGameTips()[currentTipIndex];
    el.classList.remove("tip-fading");
  },200);
}
function showNextTip(){
  currentTipIndex=(currentTipIndex+1)%getGameTips().length;
  renderCurrentTip();
  // Clicking manually resets the 15s auto-rotation timer, so it doesn't
  // immediately jump again right after a manual click.
  restartTipRotation();
}
function restartTipRotation(){
  if(tipRotationTimer) clearInterval(tipRotationTimer);
  tipRotationTimer=setInterval(()=>{
    currentTipIndex=(currentTipIndex+1)%getGameTips().length;
    renderCurrentTip();
  },15000);
}
window.showNextTip=showNextTip;
// Start the rotation now that the whole tip system is defined.
renderCurrentTip();
restartTipRotation();

function relocateFormationPickerForViewport(){
  const picker=document.getElementById("formationPickerBox");
  const teamProfile=document.getElementById("teamProfileBox");
  const convocadosBox=document.getElementById("convocadosBox");
  const isMobile=window.innerWidth<=1050;
  const centerPanel=document.querySelector(".center-panel");
  const leftPanel=document.querySelector(".left-panel");
  // Formation is locked once SELECCIONAR JUGADOR / EQUIPO RÁPIDO was pressed
  const formationLocked = formationIsLocked;

  if(picker){
    if(isMobile && centerPanel && picker.parentElement!==centerPanel){
      // Append at the END of center-panel — keeps pitch, LED scoreboard
      // and SELECCIONAR JUGADOR/JUGAR right after the pitch, with the
      // formation picker below all of that.
      centerPanel.appendChild(picker);
    } else if(!isMobile && leftPanel && picker.parentElement!==leftPanel){
      if(teamProfile) teamProfile.insertAdjacentElement("beforebegin", picker);
      else leftPanel.appendChild(picker);
    }
  }

  // PERFIL DEL EQUIPO: while the formation is still being chosen (pre-draft),
  // it sits in the CAMPO tab right below the picker. Once the formation
  // locks (drafting started), it moves to the EQUIPO tab, right after
  // CONVOCADOS — same place it always has on desktop.
  if(teamProfile){
    if(isMobile && !formationLocked && picker && teamProfile.parentElement!==picker.parentElement){
      picker.insertAdjacentElement("afterend", teamProfile);
    } else if(isMobile && formationLocked && convocadosBox && teamProfile.parentElement!==convocadosBox.parentElement){
      convocadosBox.insertAdjacentElement("afterend", teamProfile);
    } else if(!isMobile && leftPanel && teamProfile.parentElement!==leftPanel){
      leftPanel.appendChild(teamProfile);
    }
  }

  // ¿SABÍAS QUÉ...? + CÓMO JUGAR + PARA QUÉ SIRVE: live in the right panel
  // on desktop (as collapsible accordions), but move into the dedicated
  // INFORMACIÓN tab panel on mobile, always expanded there. The tip box
  // goes in FIRST, so it sits above the other two tutorials.
  const tipsBox=document.getElementById("tipsBox");
  const howTo=document.getElementById("howToPlayBox");
  const statsGuide=document.getElementById("statsGuideBox");
  const infoPanel=document.getElementById("infoPanel");
  const rightPanel=document.querySelector(".right-panel");
  if(isMobile && infoPanel){
    if(tipsBox && tipsBox.parentElement!==infoPanel){ tipsBox.classList.remove("collapsed"); infoPanel.appendChild(tipsBox); }
    if(howTo && howTo.parentElement!==infoPanel){ howTo.classList.remove("collapsed"); infoPanel.appendChild(howTo); }
    if(statsGuide && statsGuide.parentElement!==infoPanel){ statsGuide.classList.remove("collapsed"); infoPanel.appendChild(statsGuide); }
  } else if(!isMobile && rightPanel){
    if(tipsBox && tipsBox.parentElement!==rightPanel) rightPanel.appendChild(tipsBox);
    if(howTo && howTo.parentElement!==rightPanel) rightPanel.appendChild(howTo);
    if(statsGuide && statsGuide.parentElement!==rightPanel) rightPanel.appendChild(statsGuide);
  }
}

/* ---------- ROLL BUTTON ---------- */
rollBtn.addEventListener("click",()=>{
  if(rollBtn.disabled) return;
  if(maybeShowMobileFormationGate(()=>rollBtn.click())) return; // pauses for confirmation on mobile, first time only
  // Hide quick-build option once player starts manual draft
  const qbw=document.getElementById("quickBuildWrap");
  if(qbw) qbw.style.display="none";
  // Ocultar multijugador al empezar a jugar — solo visible en pantalla inicial
  const mpw=document.getElementById("multiplayerWrap");
  if(mpw) mpw.style.display="none";
  // Lock the formation choice the moment drafting actually begins —
  // not just once the squad is fully built. The player should see
  // immediately that they can no longer change it.
  if(phase==="draft"&&draftedCount===0) lockFormationDisplay();
  if(phase==="draft") rollTeams();
  else if(phase==="bench") rollBench();
});

/* Mobile-only safeguard: before the FIRST draft action (manual or quick-build),
   make sure the player has consciously seen/confirmed their formation choice.
   Shown only once per session — never interrupts again afterwards. */
let _formationGateShown=false;
function maybeShowMobileFormationGate(retryFn){
  if(window.innerWidth>1050) return false;       // desktop: never show
  if(_formationGateShown) return false;           // already shown this session
  if(phase!=="draft"||draftedCount>0) return false; // only before drafting starts
  _formationGateShown=true;
  playSound('select');
  document.getElementById("matchOverlay").innerHTML=`
  <div class="match-modal">
    <h3>Confirma tu formación</h3>
    <div class="match-summary">
      Vas a jugar con <strong>${currentFormation.code} · ${CAT_NAMES[currentFormation.category]}</strong>.
      ${FORMATION_DESC[currentFormation.code]?`<br>${FORMATION_DESC[currentFormation.code]}`:''}
      <br><br>Recuerda: la formación <strong>solo puede elegirse ahora</strong>, antes de empezar a fichar jugadores. Después quedará fija para todo el torneo.
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
      <button class="modal-btn" id="gateContinueBtn">CONTINUAR CON ESTA FORMACIÓN</button>
      <button class="modal-btn danger" id="gateChangeBtn">CAMBIAR FORMACIÓN</button>
    </div>
  </div>`;
  document.getElementById("gateContinueBtn").addEventListener("click",()=>{
    playSound('select');
    document.getElementById("matchOverlay").innerHTML="";
    retryFn();
  });
  document.getElementById("gateChangeBtn").addEventListener("click",()=>{
    playSound('select');
    document.getElementById("matchOverlay").innerHTML="";
    switchMobileTab('campo');
    setTimeout(()=>{
      const fb=document.getElementById('formationPickerBox');
      if(fb) fb.scrollIntoView({behavior:'smooth',block:'start'});
    },80);
  });
  return true;
}

/* ---------- FORMATION TABS ---------- */
document.querySelectorAll(".formation-tab").forEach(tab=>{
  tab.addEventListener("click",()=>{
    if(phase!=="draft"||draftedCount>0) return; // locked once drafting starts
    playSound('select');
    document.querySelectorAll(".formation-tab").forEach(t=>t.classList.remove("active"));
    tab.classList.add("active");
    renderFormationList(tab.dataset.cat);
  });
});

/* ========= ROLL TEAMS (show 2 random teams, 8 random players each) ========= */
function revealPreDraftBoxes(){
  // CONVOCADOS and PERFIL DEL EQUIPO are visible from the start now —
  // kept as a no-op so existing call sites don't need to change.
}
function rollTeams(){
  rollBtn.disabled=true;
  revealPreDraftBoxes();
  const pool=teams.slice();
  shuffle(pool);
  const t1=pool[0], t2=pool[1];
  // Asegurar que el cache está cargado antes de usarlo
  refreshUpgradeCache().then(()=>{
    const _ppt=getPlayersPerTeam();
    const p1=randomPick(t1.players,_ppt), p2=randomPick(t2.players,_ppt);
    window._lastTeamChoice={t1,p1,t2,p2,isBench:false};
    showTeamChoice(t1,p1,t2,p2);
  });
}

function rollBench(){
  rollBtn.disabled=true;
  const pool=teams.slice();
  shuffle(pool);
  const t1=pool[0], t2=pool[1];
  const already=new Set([...usedPlayers.map(p=>p.name),...bench.map(p=>p.name)]);
  refreshUpgradeCache().then(()=>{
    const _ppt=getPlayersPerTeam();
    const p1=randomPick(t1.players.filter(p=>!already.has(p.name)),_ppt);
    const p2=randomPick(t2.players.filter(p=>!already.has(p.name)),_ppt);
    window._lastTeamChoice={t1,p1,t2,p2,isBench:true};
    showTeamChoice(t1,p1,t2,p2,true);
  });
}

function randomPick(arr,n){
  const a=[...arr]; shuffle(a); return a.slice(0,Math.min(n,a.length));
}
function shuffle(a){ for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]; } }

function showTeamChoice(t1,p1,t2,p2,isBench=false){
  const title=isBench?(window.t?window.t('draft.choose_bench'):'ELIGE JUGADOR DE BANQUILLO'):(window.t?window.t('draft.choose_team'):'ELIGE UNA SELECCIÓN');
  const isMobile=window.innerWidth<=1050;
  const targetEl=isMobile?document.getElementById("playerCard"):playerCardEl;

  // Slot-machine reveal: shuffle random flags for ~1s before showing the real choices
  targetEl.innerHTML=`
  <div class="box" style="margin-bottom:0">
    <div class="selection-title">${title}</div>
    <div class="team-choice slot-spin">
      <div class="team-option slot-reel"><div class="flag-wrap"><div class="slot-strip" id="reel1"></div></div></div>
      <div class="team-option slot-reel"><div class="flag-wrap"><div class="slot-strip" id="reel2"></div></div></div>
    </div>
  </div>`;

  if(isMobile){
    // Active tab = RIVAL during shuffling (center panel with the card is always visible regardless)
    switchMobileTab('rival');
    setTimeout(()=>{ if(targetEl) targetEl.scrollIntoView({behavior:'smooth',block:'start'}); }, 80);
    setTimeout(()=>{ if(targetEl) targetEl.scrollIntoView({behavior:'smooth',block:'start'}); }, 1000);
  } else {
    scrollToEl("playerCardDesktop", 30);
    scrollToEl("playerCardDesktop", 950);
  }
  const pool=teams.slice();
  const reel1=document.getElementById("reel1");
  const reel2=document.getElementById("reel2");
  let i=0;
  const spin=setInterval(()=>{
    const r1=pool[Math.floor(Math.random()*pool.length)];
    const r2=pool[Math.floor(Math.random()*pool.length)];
    reel1.innerHTML=flagEmoji(r1.name,56);
    reel2.innerHTML=flagEmoji(r2.name,56);
    playSound('spin');
    i++;
  },80);
  setTimeout(()=>{
    clearInterval(spin);
    playSound('reveal');
    targetEl.innerHTML=`
    <div class="box" style="margin-bottom:0">
      <div class="selection-title">${title}</div>
      <div class="team-choice">
        ${teamOptionHTML(t1,p1)}
        ${teamOptionHTML(t2,p2)}
      </div>
    </div>`;
  },900);
}

function getTeamName(name){
  const entry=window.TRANSLATIONS&&window.TRANSLATIONS['team.'+name];
  return entry?(entry[window.LANG]||entry['es']||name):name;
}

function teamOptionHTML(team,players){
  const styleKey=team._styleKey||'';
  let styleName='';
  if(styleKey){
    // Intentar traducción directa desde TRANSLATIONS (más fiable que window.t en este contexto)
    const entry=window.TRANSLATIONS&&window.TRANSLATIONS['style.name.'+styleKey];
    if(entry){
      styleName=entry[window.LANG]||entry['es']||styleKey;
    } else if(STYLES[styleKey]){
      styleName=STYLES[styleKey].name||styleKey;
    } else {
      styleName=styleKey;
    }
  }
  return `<div class="team-option" onclick="selectTeam('${esc(team.name)}')">
    <div class="flag-wrap">${flagEmoji(team.name)}</div>
    <h3>${getTeamName(team.name)}</h3>
    ${renderBonuses(team)}
    <div class="style-label">${window.t?window.t('rival.style_label'):'Estilo de juego'}</div>
    <p class="style-text">${styleName}</p>
  </div>`;
}
function esc(s){ return s.replace(/'/g,"&#39;"); }
function renderBonuses(team){
  let h="";
  for(let k in team.bonuses){
    const v=team.bonuses[k];
    if(!v) continue;
    h+=`<div class="bonus-line">${STAT_LABELS[k]||k.toUpperCase()} ${v>0?'+':''}${v}</div>`;
  }
  return h;
}

/* ========= SELECT TEAM → show players según mejora CONVOCADOS ========= */
function selectTeam(teamName){
  const team=teams.find(t=>t.name===teamName);
  if(!team) return;
  playSound('select');
  applyBonuses(team);
  const already=new Set([...usedPlayers.map(p=>p.name),...bench.map(p=>p.name)]);
  const available=team.players.filter(p=>!already.has(p.name));
  const show=randomPick(available, getPlayersPerTeam());
  window._lastRoster={team, players:show}; // store for VOLVER
  showRosterModal(team,show);
}

function showRosterModal(team,players){
  let rows="";
  const emptySlotLabels = phase==="draft"
    ? new Set(getPitchSlots().filter(s=>!s.classList.contains("locked")).map(s=>s.dataset.label))
    : null;
  players.forEach((p,i)=>{
    const safeP=JSON.stringify(p).replace(/"/g,"&quot;");
    const safePos=JSON.stringify(p.positions||[]).replace(/"/g,"&quot;");
    const dorsal=p.dorsal||(i+1);
    const noFreeSpot = emptySlotLabels && (p.positions||[]).every(pos=>!emptySlotLabels.has(pos));
    const pickBtnClass = noFreeSpot ? "pick-btn pick-btn-warn" : "pick-btn";
    rows+=`<tr>
      <td class="dorsal-cell">${dorsal}</td>
      <td>${p.name}</td>
      <td>${(p.positions||[]).join(' / ')}</td>
      <td>${p.rating||0}</td>
      <td><button class="${pickBtnClass}" 
        onmouseover="highlightPos(${safePos})"
        onmouseout="clearHighlights()"
        onclick="pickPlayer(${safeP})">Elegir</button></td>
    </tr>`;
  });
  const rosterTarget=window.innerWidth<=1050?document.getElementById("playerCard"):playerCardEl;
  rosterTarget.innerHTML=`
  <div class="box roster-modal" style="margin-bottom:0">
    <div class="roster-header">
      ${flagEmoji(team.name,40)}
      <div class="selection-title" style="margin:0">${getTeamName(team.name)}</div>
    </div>
    <table class="roster-table">
      <thead><tr><th>#</th><th>${window.t?window.t('draft.th_player'):'Jugador'}</th><th>${window.t?window.t('draft.th_pos'):'Pos'}.</th><th>★</th><th></th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>`;
  if(window.innerWidth<=1050){
    setTimeout(()=>{ if(rosterTarget) rosterTarget.scrollIntoView({behavior:'smooth',block:'start'}); },60);
  }
}

/* ========= PICK PLAYER ========= */
function pickPlayer(player){
  playSound('select');
  const rosterTarget=window.innerWidth<=1050?document.getElementById("playerCard"):playerCardEl;
  if(phase==="bench"){
    bench.push({...player});
    benchCount++;
    if(rosterTarget) rosterTarget.innerHTML="";
    updateBenchTable();
    if(benchCount>=getMaxBench()){
      phase="ready";
      rollBtn.style.display="none";
      const tipsBox=document.getElementById("tipsBox");
      const howTo=document.getElementById("howToPlayBox");
      const statsGuide=document.getElementById("statsGuideBox");
      lockFormationDisplay();
      // Collapse (don't hide) the tutorial boxes — still consultable on
      // desktop once the squad is built, just compact at the bottom.
      if(tipsBox) tipsBox.classList.add("collapsed");
      if(howTo) howTo.classList.add("collapsed");
      if(statsGuide) statsGuide.classList.add("collapsed");
      updateConvocadosTable();
      updateBenchTable();
      startMatchPhase();
      startLedLoop();
    } else {
      rollBtn.disabled=false;
      rollBtn.textContent=`${window.t?window.t('draft.bench'):'BANQUILLO'} ${benchCount}/${getMaxBench()}`;
      scrollToCenter("rollBtn");
    }
    return;
  }
  // Draft phase: select for pitch — hide the roster (whichever container
  // it's currently shown in) and show the "JUGADOR SELECCIONADO" banner
  // in its place.
  selectedPlayer={...player};
  if(rosterTarget) rosterTarget.innerHTML="";
  highlightPos(selectedPlayer.positions||[]);
  showSelectedPlayerBanner(selectedPlayer);
  scrollToEl("pitch");
  // On mobile: switch to campo tab so pitch is visible for placement
  if(typeof switchMobileTab==='function') switchMobileTab('campo');
}

function showSelectedPlayerBanner(p){
  const html=`
  <div class="box selected-player-banner">
    <div class="selection-title">${window.t?window.t('draft.selected_title'):'JUGADOR SELECCIONADO'}</div>
    <div class="spb-row">
      <span class="spb-name">${p.name}</span>
      <span class="spb-rating">★${p.rating||0}</span>
    </div>
    <div class="spb-positions">${window.t?window.t('draft.positions'):'Posiciones'}: ${(p.positions||[]).join(' / ')}</div>
    <div class="hint-line">${window.t?window.t('draft.place_hint'):'Colócalo en una posición resaltada del campo.'}</div>
    <button class="spb-back-btn" onclick="volverASeleccion()">${window.t?window.t('draft.back'):'↩ VOLVER'}</button>
  </div>`;
  const el=document.getElementById("selectedPlayerBanner");
  if(el){ el.style.display="block"; el.innerHTML=html; }
  const eld=document.getElementById("selectedPlayerBannerDesktop");
  if(eld){ eld.style.display="block"; eld.innerHTML=html; }
}
function hideSelectedPlayerBanner(){
  const el=document.getElementById("selectedPlayerBanner");
  if(el){ el.style.display="none"; el.innerHTML=""; }
  const eld=document.getElementById("selectedPlayerBannerDesktop");
  if(eld){ eld.style.display="none"; eld.innerHTML=""; }
}

function volverASeleccion(){
  playSound('select');
  selectedPlayer=null;
  clearHighlights();
  hideSelectedPlayerBanner();
  // Restore the same 5 players from the last selected team
  if(window._lastRoster){
    const {team, players}=window._lastRoster;
    showRosterModal(team, players);
  }
  // Same as when teams are first shuffled: the active tab becomes RIVAL,
  // since that's where the team/player selection card is shown on mobile.
  if(window.innerWidth<=1050 && typeof switchMobileTab==='function'){
    switchMobileTab('rival');
  }
}

/* ========= POSITION SLOTS ========= */
function renderSlotContent(slot, player, label, rating, starHTML){
  const statusIcons=getSlotStatusIconsHTML(player);
  slot.innerHTML=`${statusIcons}<span class="pos-rating">${rating}</span><div class="player-info">${player.name}${starHTML}<div class="player-pos-label">${label}</div></div>`;
}
/* Small status icon row shown ABOVE the pitch circle — injury, card, and
   scorer streak, so the player's situation is visible at a glance without
   having to check the convocados table. */
function getSlotStatusIconsHTML(p){
  const icons=[];
  if(p.injury) icons.push(`<span class="pitch-status-icon pitch-status-injury" title="Lesionado">✚</span>`);
  if(p.suspended) icons.push(`<span class="pitch-status-icon" title="Sancionado">🚫</span>`);
  else if((p.yellowCount||0)>=1) icons.push(`<span class="pitch-status-icon" title="Tarjeta amarilla acumulada">🟨</span>`);
  const streak=scorerStreaks[p.name]||0;
  if(streak>0) icons.push(`<span class="pitch-status-icon" title="Racha goleadora">🔥</span>`);
  if(!icons.length) return "";
  return `<div class="pitch-status-row">${icons.join("")}</div>`;
}

/* Refresh the on-pitch rating/star display for every starter based on their
   current effRating (e.g. after an injury is sustained or recovered from). */
function refreshPitchRatings(){
  getPitchSlots().forEach(slot=>{
    const p=slot._player;
    if(!p) return;
    const label=slot.dataset.label;
    const inPos=p.positions&&p.positions.includes(label);
    const star=inPos&&p.positions[0]===label?' <span class="star">★</span>':'';
    renderSlotContent(slot, p, label, effRating(p), star);
  });
}

function lineLabels(n,isDef,isAtt){
  if(isDef){
    if(n===2)return["DFC","DFC"];if(n===3)return["DFC","DFC","DFC"];
    if(n===4)return["LI","DFC","DFC","LD"];if(n===5)return["LI","DFC","DFC","DFC","LD"];
    if(n===6)return["LI","DFC","DFC","DFC","DFC","LD"];
  }
  if(isAtt){
    if(n===1)return["DC"];if(n===2)return["DC","DC"];if(n===3)return["EI","DC","ED"];
    if(n===4)return["EI","DC","DC","ED"];if(n===5)return["EI","DC","DC","DC","ED"];
  }
  if(n===1)return["MC"];if(n===2)return["MC","MC"];if(n===3)return["EI","MC","ED"];
  if(n===4)return["EI","MC","MC","ED"];if(n===5)return["EI","MC","MC","MC","ED"];
  if(n===6)return["EI","MC","MC","MC","MC","ED"];
  return Array(n).fill("MC");
}
function buildFormationSlots(code){
  const layout=FORMATION_LAYOUTS[code];
  const GK_TOP=88;
  if(!layout){
    // Fallback for any unmapped code: keep the old generic behaviour so
    // nothing crashes, though every formation actually used in the game
    // is covered above.
    const lines=code.split("-").map(Number);
    const slots=[{label:"POR",left:50,top:GK_TOP}];
    const T=lines.length;
    lines.forEach((n,i)=>{
      const isDef=i===0,isAtt=i===T-1;
      const labels=lineLabels(n,isDef,isAtt);
      const top=T===1?45:78-i*(78-14)/(T-1);
      addArcedLine(slots,labels,top,i===0,isAtt);
    });
    return slots;
  }
  const slots=[];
  const fieldLines=layout.length-1; // excludes goalkeeper
  // Explicit zone tops per line count — every formation in this game has
  // either 3 field lines (def/mid/att) or 4 (def/mid/mid-or-AMC/att).
  // The midfield line sits right at the halfway line (50%) when there's
  // only one midfield line, straddling it when there are two.
  let zoneTops;
  if(fieldLines===3)      zoneTops=[74, 50, 22];
  else if(fieldLines===4) zoneTops=[74, 58, 42, 22];
  else {
    // Safety fallback for any unexpected line count: spread evenly.
    zoneTops=[];
    for(let i=0;i<fieldLines;i++) zoneTops.push(74-(i*(74-22))/(fieldLines-1||1));
  }
  layout.forEach((labels,i)=>{
    if(i===0){ slots.push({label:"POR",left:50,top:GK_TOP}); return; }
    const top=zoneTops[i-1];
    const isAttackLine=(i===layout.length-1);
    addArcedLine(slots,labels,top,false,isAttackLine);
  });
  return slots;
}
/* Adds a line of players with a natural arc instead of a flat row. The
   curve is based on each player's horizontal distance from the pitch's
   absolute center (50% width) — NOT from the line's own midpoint — so the
   whole line forms one smooth, continuous arc regardless of player count
   (odd or even).

   Defense and midfield lines curve CONCAVE toward their own goal: the
   wide players (touchline side) push forward, the central players stay
   back — like a smile opening toward the opponent's goal.

   The ATTACK line curves the OPPOSITE way (CONVEX): the central striker(s)
   push forward toward goal, the wide forwards stay back — forming a spear
   point toward the opponent's goal, matching real tactical board visuals. */
function addArcedLine(slots,labels,baseTop,isGoalkeeperLine,isAttackLine){
  const n=labels.length;
  // The opponent's penalty box top edge sits at 16.4% of pitch height —
  // no attacking player should be pushed further forward than that, or
  // they'd visually sit on top of / past the box line.
  const ATTACK_MIN_TOP=17;
  labels.forEach((label,j)=>{
    const left=(j+1)/(n+1)*100;
    let top=baseTop;
    if(!isGoalkeeperLine && n>1){
      // Distance from the pitch's horizontal center (50%), normalized 0..1
      const distFromPitchCenter=Math.abs(left-50)/50;
      // Stronger, more visible curvature than before.
      const arcDepth=Math.min(11, 5+n*0.9);
      // Concave (defense/midfield): wide players forward -> -depth*dist
      // Convex (attack): central players forward -> -depth*(1-dist)
      if(isAttackLine){
        top=baseTop - (1-distFromPitchCenter)*arcDepth;
        top=Math.max(ATTACK_MIN_TOP, top); // never push past the box edge
      } else {
        top=baseTop - distFromPitchCenter*arcDepth;
      }
    }
    slots.push({label,left:Math.max(5,Math.min(95,left)),top});
  });
}
function renderPitch(code){
  pitchEl.querySelectorAll(".position").forEach(el=>el.remove());
  buildFormationSlots(code).forEach(s=>{
    const div=document.createElement("div");
    div.className="position";
    div.dataset.label=s.label;
    div.style.left=s.left+"%";
    div.style.top=s.top+"%";
    div.innerHTML=`<span class="pos-label-inside">${s.label}</span>`;
    div.addEventListener("click",()=>onSlotClick(div));
    pitchEl.appendChild(div);
  });
}

function onSlotClick(slot){
  // Any player can go anywhere — penalty if out of position
  if(!selectedPlayer) return;
  if(slot.classList.contains("locked")) return;
  playSound('select');
  const label=slot.dataset.label;
  const p=selectedPlayer;
  p.placedPos=label;
  const inPos=p.positions&&p.positions.includes(label);
  const r=inPos ? (p.rating||70) : Math.round((p.rating||70)*0.85);
  const starHTML=inPos&&p.positions[0]===label?' <span class="star">★</span>':'';
  renderSlotContent(slot, p, label, r, starHTML);
  hideSelectedPlayerBanner();
  slot.classList.add("locked");
  slot.classList.remove("highlight-pos");
  slot._player=p;
  usedPlayers.push(p);
  draftedCount++;
  selectedPlayer=null;
  clearHighlights();
  updateDraftCounter();
  updateConvocadosTable();
  updateStats();
  if(draftedCount>=11){
    baseTeamOVR=computeTeamOVR();
    phase="bench";
    rollBtn.textContent=`${window.t?window.t('draft.bench'):'BANQUILLO'} 0/${getMaxBench()}`;
    rollBtn.disabled=false;
    document.getElementById("benchSection").style.display="block";
    playerCardEl.innerHTML="";
  } else {
    rollBtn.disabled=false;
  }
}

/* ========= HIGHLIGHTS ========= */
function highlightPos(positions){
  document.querySelectorAll("#pitch .position:not(.locked)").forEach(s=>{
    if(positions.includes(s.dataset.label)){
      s.classList.add("highlight-pos");
    } else {
      s.classList.remove("highlight-pos");
      s.style.borderColor="";s.style.boxShadow="";
    }
  });
}
function clearHighlights(){
  document.querySelectorAll("#pitch .position").forEach(s=>{
    s.classList.remove("highlight-pos");
    if(!s.classList.contains("locked")){
      s.style.borderColor="";s.style.boxShadow="";
    }
  });
}

/* ========= DRAFT COUNTER & TABLES ========= */
function updateDraftCounter(){
  const title=document.getElementById("convocadosTitle");
  if(!title) return;
  if(draftedCount===11){
    const teamName=(window._currentTeamName||myTeamName||'EQUIPO').toUpperCase();
    // Mostrar nombre del equipo en lugar de "CONVOCADOS 11/11"
    title.innerHTML=`<span style="color:var(--gold);font-size:inherit">${teamName}</span>`;
  } else {
    title.innerHTML=`${window.t?window.t('draft.convocados'):'CONVOCADOS'} <span id="draftCounter" class="counter-badge">${draftedCount}/11</span>`;
  }
}
function effRating(p){
  const r=p.rating||70;
  if(!p.placedPos) return r;
  const inPos=p.positions&&p.positions.includes(p.placedPos);
  const positionFactor=inPos?1:0.85; // 15% penalty when out of position
  const injuryFactor=p.injury?0.6:1;
  const fatigueFactor=getFatigueFactor(p);
  return Math.round(r*positionFactor*injuryFactor*fatigueFactor);
}

/* ========= FATIGUE SYSTEM ========= */
// Each player has a 0-100 "freshness" bar. 100 = fully rested (green).
// Above 75: no penalty at all. Below that, rating decays gradually down
// to a maximum -30% penalty once fatigue is fully in the red (≤25).
function getFatigueFactor(p){
  const f=(p.fatigue===undefined)?100:p.fatigue;
  if(f>=75) return 1;
  // Linear decay from 1.0 at f=75 down to 0.70 at f=0
  const factor=0.70+(f/75)*0.30;
  return Math.max(0.70, Math.min(1, factor));
}
function getFatigueColor(p){
  const f=(p.fatigue===undefined)?100:p.fatigue;
  if(f>=75) return 'green';
  if(f>=40) return 'yellow';
  return 'red';
}
// Positions more involved in attacking strategies tire faster when those
// strategies are actually used — wingers/forwards covering more ground
// in an offensive setup, defenders working harder under defensive ones.
function applyMatchFatigue(){
  const myKey=selectedMatchStrategy;
  const attackingStrategies=['tiki_taka','presion_alta','gegenpressing','futbol_total','ataque_bandas','juego_directo'];
  const isAttackingStrategy=myKey&&attackingStrategies.includes(myKey);

  // Track which player(s) scored this match — they tire a bit more from
  // the extra effort (sprints, pressing to get the goal), a nod to the
  // "tired goalscorer" pattern without overdoing it.
  const scorers=new Set(generateMatchSummary._scorers||[]);

  usedPlayers.forEach(p=>{
    if(!p.placedPos) return;

    // Goalkeepers barely tire — minimal running involved in a real match.
    if(p.placedPos==='POR'){
      p.fatigue=Math.max(0, Math.round((p.fatigue===undefined?100:p.fatigue)-(2+Math.random()*4)));
      return;
    }

    // Base fatigue loss: 12-20 points per match — enough to feel it after 2-3 games.
    // RECUPERACIÓN upgrade reduces this loss.
    const recoveryBonus = getRecoveryBonus(); // 0-10% reduction per level
    let loss=(8+Math.random()*6)*(1-recoveryBonus);

    // Central defenders cover the least ground — lightest loss.
    if(p.placedPos==='DFC'){
      loss*=0.65;
    }
    // Full-backs/wingers/forwards/midfielders run more, especially when
    // the active strategy demands it.
    const runningPositions=['EI','ED','DC','MC','LI','LD'];
    if(isAttackingStrategy&&runningPositions.includes(p.placedPos)){
      loss+=Math.random()*6;
    }
    // A player who scored works a bit harder than average that match.
    if(scorers.has(p.name)){
      loss+=Math.random()*4;
    }
    p.fatigue=Math.max(0, Math.round((p.fatigue===undefined?100:p.fatigue)-loss));
  });
  // Bench players who DIDN'T play fully recover
  bench.forEach(p=>{ p.fatigue=100; });
}
function computeTeamOVR(){
  if(!usedPlayers.length) return null;
  const base=Math.round(usedPlayers.reduce((s,p)=>s+effRating(p),0)/usedPlayers.length);
  return base; // stars give a hidden match bonus, not inflating the displayed OVR
}
// Returns a 0..1 bonus factor from star players, used internally in match calc
function starMatchBonus(){
  const stars=usedPlayers.filter(p=>p.positions&&p.placedPos&&p.positions[0]===p.placedPos).length;
  return stars*0.012; // each ★ = +1.2% lambda boost, up to +13.2% with 11 stars
}
let swapSelection=null;

function renderCenterSummary(){
  const el=document.getElementById("centerSummary");
  if(!el) return;
  if(!el) return;
  if(baseTeamOVR===null) { el.innerHTML=""; return; }
  const stars=usedPlayers.filter(p=>p.positions&&p.placedPos&&p.positions[0]===p.placedPos).length;
  el.innerHTML=`
  <div class="box center-summary-box">
    <div class="center-summary-row">
      <span class="center-summary-name">${myTeamName}</span>
      <span class="center-summary-ovr">${baseTeamOVR}</span>
    </div>
    <div class="hint-line">${stars} jugador${stars===1?'':'es'} en su posición ★ · ${stageLabel()}</div>
  </div>`;
}
function stageLabel(){
  if(stage==="group") return `${t("comp.groups")} · ${t("match.match")||"partido"} ${groupMatchIdx+1}/3`;
  if(stage==="knockout") return getRoundName(knockoutRound);
  return t("comp.champion")||"Torneo completado";
}

function getFatigueBarHTML(p){
  const f=(p.fatigue===undefined)?100:p.fatigue;
  const color=getFatigueColor(p);
  return `<div class="fatigue-bar-wrap" title="${window.t?window.t('draft.th_stamina'):'Resistencia'}: ${f}%"><div class="fatigue-bar fatigue-${color}" style="width:${f}%"></div></div>`;
}
// Ordenación de convocados: 'arrival' | 'position' | 'rating'
let convSortMode = 'position';
const CONV_SORT_LABELS = {arrival:'LLEGADA', position:'POSICIÓN', rating:'PUNTOS'};
const CONV_SORT_NEXT = {arrival:'position', position:'rating', rating:'arrival'};
window.toggleConvSort = function(){
  convSortMode = CONV_SORT_NEXT[convSortMode];
  const lbl = document.getElementById('convSortLabel');
  const CONV_SORT_KEYS={arrival:'draft.sort_arrival',position:'draft.sort_position',rating:'draft.sort_rating'};
  if(lbl) lbl.textContent = window.t?window.t(CONV_SORT_KEYS[convSortMode]):CONV_SORT_LABELS[convSortMode];
  updateConvocadosTable();
};

function updateConvocadosTable(){
  const el=document.getElementById("convocadosTable");
  if(!el) return;

  // Siempre limpiar resaltado amarillo primero
  getPitchSlots().forEach(s=>s.classList.remove('slot-conv-selected'));
  // Volver a aplicar solo si hay selección activa
  if(swapSelection&&swapSelection.source==='conv'){
    const selPlayer=usedPlayers[swapSelection.index];
    if(selPlayer) getPitchSlots().forEach(s=>{
      if(s._player===selPlayer) s.classList.add('slot-conv-selected');
    });
  }
  const swapsLeft=getMaxSubs()-swapsUsedThisMatch;
  const canSwap=(phase==='ready')&&swapsLeft>0;
  // Mostrar/ocultar el botón de ordenación
  const sortBtn = document.getElementById('convSortBtn');
  if(sortBtn) sortBtn.style.display = usedPlayers.length >= 2 ? 'flex' : 'none';

  // Ordenar según el modo activo
  let displayPlayers;
  if(convSortMode === 'position'){
    const posOrder = ['POR','DFC','LI','LD','MC','EI','ED','DC'];
    displayPlayers = [...usedPlayers].sort((a,b)=>{
      const ai = posOrder.indexOf(a.placedPos||'');
      const bi = posOrder.indexOf(b.placedPos||'');
      return (ai===-1?99:ai) - (bi===-1?99:bi);
    });
  } else if(convSortMode === 'rating'){
    displayPlayers = [...usedPlayers].sort((a,b)=> effRating(b) - effRating(a));
  } else {
    displayPlayers = usedPlayers; // orden de llegada = orden del array
  }

  let rows="",stars=0;
  displayPlayers.forEach((p,i)=>{
    const inPrimary=p.positions&&p.placedPos&&p.positions[0]===p.placedPos;
    if(inPrimary) stars++;
    const injuryTag=p.injury?` <span class="cross" title="Lesionado">✚(-${p.injury.remaining})</span> `:'';
    const cross=p.injury?injuryTag:'';
    const cardBadge=getCardBadge(p);
    const star=inPrimary?'<span class="star" title="Posición principal ★">★</span>':'';
    const r=effRating(p);
    const streak=getStreakBadge(p.name);
    const fatigueBar=getFatigueBarHTML(p);
    const realIdx=usedPlayers.indexOf(p);
    const sel=(swapSelection&&swapSelection.source==='conv'&&swapSelection.index===realIdx)?' class="row-selected"':'';
    // Siempre clicable para seleccionar y ver posición en campo
    const clickable=` onclick="onConvocadoClick(${realIdx})" style="cursor:pointer"`;
    const realPos=(p.positions||[]).join('/');
    const posLabel=p.placedPos||'?';
    const realLabel=(realPos&&realPos!==posLabel)?`<br><span style="font-size:9px;color:var(--text-muted)">${realPos}</span>`:'';
    rows+=`<tr${sel}${clickable}><td>${i+1}</td><td>${p.name}${cross}${cardBadge}${streak}</td><td>${fatigueBar}</td><td><span style="font-weight:700">${posLabel}</span>${star}${realLabel}</td><td>${r}</td></tr>`;
  });
  el.innerHTML=rows?`<table><thead><tr><th>#</th><th>${window.t?window.t('draft.th_player'):'Jugador'}</th><th title="${window.t?window.t('draft.th_stamina'):'Resistencia'}">${window.t?window.t('draft.th_stamina'):'Resistencia'}</th><th>${window.t?window.t('draft.th_pos'):'Pos'}</th><th>★</th></tr></thead><tbody>${rows}</tbody></table>`:"";
  // Update star bonus display
  const sbEl=document.getElementById("starBonus");
  const sbVal=document.getElementById("starBonusVal");
  if(sbEl&&sbVal){ sbEl.style.display=stars>0?"block":"none"; sbVal.textContent=stars; }
  // Update OVR (total already includes +1 per star)
  if(usedPlayers.length){
    const avg=(baseTeamOVR!==null)?baseTeamOVR:computeTeamOVR();
    const el2=document.getElementById("teamOVR");
    if(el2) el2.textContent=avg;
  }
  // Swap counter hint
  const swapHint=document.getElementById("swapHint");
  if(swapHint){
    if(phase==='ready'){
      swapHint.style.display="block";
      swapHint.textContent=swapsLeft>0
        ? `${window.t?window.t('draft.swap_available'):'Cambios disponibles antes del próximo partido'}: ${swapsLeft}/${getMaxSubs()}`
        : (window.t?window.t('draft.swap_used'):'Ya has usado tu cambio para este partido.');
    } else {
      swapHint.style.display="none";
    }
  }
}
function updateBenchTable(){
  const el=document.getElementById("benchTable");
  const cnt=document.getElementById("benchCounter");
  if(cnt) cnt.textContent=bench.length+`/${getMaxBench()}`;
  if(!el) return;
  const swapsLeft=getMaxSubs()-swapsUsedThisMatch;
  const canSwap=(phase==='ready')&&swapsLeft>0;
  let rows="";
  bench.forEach((p,i)=>{
    const injuryTag=p.injury?` <span class="cross">✚(-${p.injury.remaining})</span> `:'';
    const cross=p.injury?injuryTag:'';
    const cardBadge=getCardBadge(p);
    const fatigueBar=getFatigueBarHTML(p);
    const sel=(swapSelection&&swapSelection.source==='bench'&&swapSelection.index===i)?' class="row-selected"':'';
    const isBlocked=p.suspended;
    const clickable=(canSwap&&!isBlocked)?` onclick="onBenchClick(${i})" style="cursor:pointer"`:(isBlocked?` style="opacity:.55;cursor:not-allowed"`:'');
    rows+=`<tr${sel}${clickable}><td>${p.name}${cross}${cardBadge}</td><td>${fatigueBar}</td><td>${(p.positions||[]).join('/')}</td><td>${p.rating||0}</td></tr>`;
  });
  el.innerHTML=rows?`<table><thead><tr><th>${window.t?window.t('draft.th_player'):'Jugador'}</th><th title="${window.t?window.t('draft.th_stamina'):'Resistencia'}">${window.t?window.t('draft.th_stamina'):'Resistencia'}</th><th>${window.t?window.t('draft.th_pos'):'Pos'}</th><th>★</th></tr></thead><tbody>${rows}</tbody></table>`:"";
}

/* ========= PRE-MATCH SWAPS (convocados <-> bench) ========= */
function onConvocadoClick(i){
  if(phase!=='ready') return;

  // Si hay un jugador del banquillo seleccionado y quedan cambios, hacer swap
  if(swapSelection&&swapSelection.source==='bench'){
    if(swapsUsedThisMatch>=getMaxSubs()) return;
    const benchIdx=swapSelection.index;
    swapSelection=null;
    highlightPos([]);
  getPitchSlots().forEach(s=>s.classList.remove('slot-conv-selected'));
    performSwap(benchIdx, i);
    return;
  }

  // Si hay un convocado ya seleccionado
  if(swapSelection&&swapSelection.source==='conv'){
    if(swapSelection.index===i){
      // Deseleccionar
      swapSelection=null;
      highlightPos([]);
      updateConvocadosTable();
      updateBenchTable();
      return;
    }
    // Intercambiar posición EN LA LISTA (no solo en el campo)
    if(swapsUsedThisMatch<getMaxSubs()){
      const idxA=swapSelection.index, idxB=i;
      swapSelection=null;
      highlightPos([]);
      // Intercambiar en el array usedPlayers (posición en la lista)
      [usedPlayers[idxA], usedPlayers[idxB]] = [usedPlayers[idxB], usedPlayers[idxA]];
      // Y también intercambiar sus posiciones en el campo
      performConvConvSwap(idxA, idxB);
      return;
    } else {
      // Sin cambios disponibles — cambiar selección al nuevo jugador
      swapSelection={source:'conv',index:i};
      highlightPos((usedPlayers[i]||{}).positions||[]);
      updateConvocadosTable();
      updateBenchTable();
      return;
    }
  }

  // Seleccionar el jugador (siempre permitido para ver su posición)
  swapSelection={source:'conv',index:i};
  highlightPos((usedPlayers[i]||{}).positions||[]);
  // Resaltar el círculo del jugador en el campo en amarillo
  getPitchSlots().forEach(s=>{
    if(s._player===usedPlayers[i]) s.classList.add('slot-conv-selected');
    else s.classList.remove('slot-conv-selected');
  });
  updateConvocadosTable();
  updateBenchTable();
}
function onBenchClick(i){
  if(phase!=='ready'||swapsUsedThisMatch>=getMaxSubs()) return;
  // A suspended player cannot be brought onto the pitch — they must serve
  // their sanction. Clicking them does nothing until the suspension lifts.
  if(bench[i]&&bench[i].suspended) return;
  if(swapSelection&&swapSelection.source==='conv'){
    const convIdx=swapSelection.index;
    swapSelection=null;
    performSwap(i, convIdx);
    return;
  }
  if(swapSelection&&swapSelection.source==='bench'&&swapSelection.index===i){
    swapSelection=null;
  } else {
    swapSelection={source:'bench',index:i};
  }
  updateConvocadosTable();
  updateBenchTable();
}
function performSwap(benchIdx, convIdx){
  const benchPlayer=bench[benchIdx];
  const convPlayer=usedPlayers[convIdx];
  if(!benchPlayer||!convPlayer) return;
  const slot=getPitchSlots().find(s=>s._player===convPlayer);
  if(!slot) return;
  const label=slot.dataset.label;
  benchPlayer.placedPos=label;
  delete convPlayer.placedPos;
  // Swap arrays
  bench[benchIdx]=convPlayer;
  usedPlayers[convIdx]=benchPlayer;
  slot._player=benchPlayer;
  const inPos=benchPlayer.positions&&benchPlayer.positions.includes(label);
  const _penPct=window._skillCache&&window._skillCache.cazatalentos?0.95:0.85;
  const r=inPos?(benchPlayer.rating||70):Math.round((benchPlayer.rating||70)*_penPct);
  const star=inPos&&benchPlayer.positions[0]===label?' <span class="star">★</span>':'';
  renderSlotContent(slot, benchPlayer, label, r, star);
  baseTeamOVR=computeTeamOVR();
  swapsUsedThisMatch++;
  playSound('select');
  updateConvocadosTable();
  updateBenchTable();
  renderCenterSummary();
  updateLed();
}

function performConvConvSwap(idxA, idxB){
  // Swap two titulars' pitch positions with each other
  const pA=usedPlayers[idxA], pB=usedPlayers[idxB];
  if(!pA||!pB) return;
  const slots=getPitchSlots();
  const slotA=slots.find(s=>s._player===pA);
  const slotB=slots.find(s=>s._player===pB);
  if(!slotA||!slotB) return;
  const labelA=slotA.dataset.label, labelB=slotB.dataset.label;
  // Swap placed positions
  pA.placedPos=labelB; pB.placedPos=labelA;
  slotA._player=pB;    slotB._player=pA;
  // Re-render both slots
  [{ slot:slotA, p:pB, label:labelB }, { slot:slotB, p:pA, label:labelA }].forEach(({slot,p,label})=>{
    const inPos=p.positions&&p.positions.includes(label);
    const r=inPos?(p.rating||70):Math.round((p.rating||70)*0.85);
    const star=inPos&&p.positions[0]===label?' <span class="star">★</span>':'';
    renderSlotContent(slot, p, label, r, star);
  });
  baseTeamOVR=computeTeamOVR();
  swapsUsedThisMatch++;
  playSound('select');
  updateConvocadosTable();
  updateBenchTable();
  renderCenterSummary();
  updateLed();
}
function applyBonuses(team){
  for(let k in team.bonuses) teamStats[k]=(teamStats[k]||0)+team.bonuses[k];
  updateStats();
}
function applyFormationBonus(bonus){
  for(let k in currentFormationBonus) teamStats[k]=(teamStats[k]||0)-currentFormationBonus[k];
  for(let k in bonus) teamStats[k]=(teamStats[k]||0)+bonus[k];
  currentFormationBonus=bonus;
  updateStats();
}
function updateStats(){
  // Formation (and later, drafted players) shape ATAQUE/DEFENSA/etc. directly.
  // The NUMBER shown is always the real value (can be negative — e.g. a very
  // defensive formation before any player is drafted). Only the BAR's width
  // is clamped to 0-100%, since a bar can't visually go negative.
  ["attack","defense","pace","passing","technique"].forEach(k=>{
    const real=Math.round(teamStats[k]||0);
    const barPct=Math.max(0,Math.min(100,real));
    const v=document.getElementById(k+"Value");
    const b=document.getElementById(k+"Bar");
    if(v){
      v.textContent=real;
      v.classList.toggle("stat-negative", real<0);
    }
    if(b) b.style.width=barPct+"%";
  });
}

/* ========= FORMATIONS ========= */
function renderFormationList(cat){
  const list=document.getElementById("formationList");
  if(!list) return;
  list.innerHTML="";
  FORMATIONS[cat].forEach(f=>{
    const sel=currentFormation.category===cat&&currentFormation.code===f.code;
    const d=document.createElement("div");
    d.className="formation-option"+(sel?" selected":"");
    d.innerHTML=`<span class="f-code">${f.code}</span><span class="f-badge">${f.label}</span>`;
    d.addEventListener("click",()=>selectFormation(cat,f.code));
    list.appendChild(d);
  });
}
function selectFormation(cat,code){
  // Formation can ONLY be changed during initial setup, before SELECCIONAR
  // JUGADOR / EQUIPO RÁPIDO has been pressed. Once the draft has started
  // (draftedCount>0) or finished (phase==="ready"/"bench"), it's locked.
  if(phase!=="draft"||draftedCount>0) return;
  const f=FORMATIONS[cat].find(x=>x.code===code);
  if(!f) return;
  playSound('select');
  const badge=document.getElementById("formationBadge");
  if(badge) badge.style.display="none";
  currentFormation={category:cat,code};
  applyFormationBonus(f.bonus);
  renderPitch(code);
  resetDraft();
  renderFormationList(cat);
  const el=document.getElementById("currentFormation");
  if(el) el.textContent=`${code} · ${CAT_NAMES[cat]}`;
  renderMobileFormationInfo();
}
function lockFormationDisplay(){
  // Called as soon as drafting starts (SELECCIONAR JUGADOR / EQUIPO RÁPIDO
  // pressed for the first time) — formation can no longer change from here.
  // Hide the picker box (left panel), show the read-only info card instead
  // (center panel, below the LED board).
  formationIsLocked=true;
  const picker=document.getElementById("formationPickerBox");
  const infoCard=document.getElementById("formationInfoCard");
  if(picker)   picker.style.display="none";
  if(infoCard) infoCard.style.display="block";
  const el=document.getElementById("currentFormation");
  if(el) el.textContent=`${currentFormation.code} · ${CAT_NAMES[currentFormation.category]}`;
  const descEl=document.getElementById("formationDesc");
  if(descEl) descEl.textContent=FORMATION_DESC[currentFormation.code]||"";
  const badge=document.getElementById("formationBadge");
  if(badge) badge.style.display="none";
  renderMobileFormationInfo();
  // Now that the formation is locked, PERFIL DEL EQUIPO moves from the
  // CAMPO tab (next to the picker) to the EQUIPO tab (after CONVOCADOS).
  if(typeof relocateFormationPickerForViewport==="function") relocateFormationPickerForViewport();
}

function renderMobileFormationInfo(){
  // Mobile-only compact card shown under the pitch, in the FORMACIÓN tab
  const el=document.getElementById("mobileFormationInfo");
  if(!el) return;
  if(phase==="draft" && draftedCount===0){
    el.classList.add("empty");
    el.innerHTML=``;
  } else {
    el.classList.remove("empty");
    const desc=FORMATION_DESC[currentFormation.code]||"";
    el.innerHTML=`<strong>${currentFormation.code} · ${CAT_NAMES[currentFormation.category]}</strong><br>${desc}`;
  }
}

function resetDraft(){
  usedPlayers=[]; draftedCount=0;
  updateDraftCounter();
  updateConvocadosTable();
  rollBtn.disabled=false;
  rollBtn.textContent=t("draft.select_player");
  selectedPlayer=null;
  playerCardEl.innerHTML="";
}
function getPitchSlots(){ return Array.from(document.querySelectorAll("#pitch .position")); }

// Forzar redibujado del campo al cambiar tamaño/orientación
(function(){
  const pitchEl=document.getElementById('pitch');
  if(!pitchEl||!window.ResizeObserver) return;
  let _debounce;
  new ResizeObserver(()=>{
    clearTimeout(_debounce);
    _debounce=setTimeout(()=>{
      // Forzar reflow de los slots
      getPitchSlots().forEach(s=>{ s.style.display='none'; void s.offsetHeight; s.style.display=''; });
    },100);
  }).observe(pitchEl);
  // También en cambio de orientación
  window.addEventListener('orientationchange',()=>{
    setTimeout(()=>{ getPitchSlots().forEach(s=>{ s.style.display='none'; void s.offsetHeight; s.style.display=''; }); },300);
  });
})();
function reassignSquad(code){
  const pool=[...getPitchSlots().map(s=>s._player).filter(Boolean),...bench];
  renderPitch(code);
  const slots=getPitchSlots();
  const remaining=[...pool];
  slots.forEach(slot=>{
    const label=slot.dataset.label;
    let idx=remaining.findIndex(p=>p.positions&&p.positions[0]===label);
    if(idx<0) idx=remaining.findIndex(p=>p.positions&&p.positions.includes(label));
    if(idx<0) idx=remaining.findIndex(p=>!p.injury);
    if(idx<0) idx=0;
    if(idx>=0){
      const p=remaining.splice(idx,1)[0];
      p.placedPos=label;
      slot._player=p;
      const inPos=p.positions&&p.positions.includes(label);
      const r=inPos?(p.rating||70):Math.round((p.rating||70)*0.85);
      const star=inPos&&p.positions[0]===label?' <span class="star">★</span>':'';
      renderSlotContent(slot, p, label, r, star);
      slot.classList.add("locked");
    }
  });
  bench=remaining;
  usedPlayers=[];
  slots.forEach(slot=>{ if(slot._player) usedPlayers.push(slot._player); });
  updateConvocadosTable();
  updateBenchTable();
}

/* ========= MATCH PHASE ========= */
let myTeamName = "TU EQUIPO";

function startMatchPhase(){
  // Modo duelo multijugador: la plantilla se guarda en Firestore y se
  // espera al rival, en vez de seguir el flujo normal de torneo IA.
  if(window._duelId){ showTeamNameModal(); return; }
  document.getElementById("benchSection").style.display="block";
  document.getElementById("rivalBox").style.display="block";
  document.getElementById("matchHistoryBox").style.display="block";
  document.getElementById("playMatchBtn").style.display="block";
  document.getElementById("moraleSection").style.display="block";
  renderMorale();
  const qb=document.getElementById("quickBuildWrap");
  if(qb) qb.style.display="none";
  playerCardEl.innerHTML="";
  showTeamNameModal();
}
function showTeamNameModal(){
  // If the logged-in user has chosen to always use a fixed team name,
  // skip the popup entirely and use that name directly.
  if(window.useFixedTeamName && window.preferredTeamName){
    myTeamName=window.preferredTeamName;
    window._currentTeamName=myTeamName;
    if(typeof updateDraftCounter==='function') updateDraftCounter();
    if(typeof firebase!=='undefined'){
      try{
        const user=firebase.auth().currentUser;
        if(user) firebase.firestore().collection("users").doc(user.uid)
          .set({lastTeamName:myTeamName},{merge:true});
      }catch(e){}
    }
    if(window._duelId){
      mpOnDraftComplete();
    }else{
      setupGroupStage();
      renderCenterSummary();
      pickNextOpponent();
    }
    return;
  }
  document.getElementById("matchOverlay").innerHTML=`
  <div class="match-modal">
    <h3 style="text-align:center">${t('team_modal.title')||'¡EQUIPO COMPLETO!'}</h3>
    <div class="match-summary" data-i18n-html="team_modal.body">${t('team_modal.body')||'Tu plantilla GOAT está lista. ¡Dale un nombre a tu equipo antes de empezar el torneo! Empezarás en la <strong>Fase de Grupos</strong>: 3 partidos, los 2 primeros del grupo avanzan a octavos de final.'}</div>
    <input type="text" id="teamNameInput" maxlength="24" placeholder="${t('team_modal.placeholder')||'Ej: Dream Team FC'}" class="team-name-input" value="${esc(myTeamName==='TU EQUIPO'?'':myTeamName)}">
    <span id="teamNameErr" style="display:none;color:#e74c3c;font-size:11px;margin-top:4px">${t('team_modal.error')||'El nombre del equipo no puede estar vacío.'}</span>
    <button class="modal-btn" id="teamNameConfirmBtn">${t('team_modal.confirm')||'CONFIRMAR'}</button>
  </div>`;
  const inp=document.getElementById("teamNameInput");
  inp.focus();
  const confirmFn=()=>{
    const val=inp.value.trim();
    if(!val){
      document.getElementById("teamNameErr").style.display="block";
      inp.focus();
      return;
    }
    myTeamName=val.toUpperCase();
    window._currentTeamName=myTeamName;
    // La tabla de convocados solo repinta el título al cambiar draftedCount;
    // hay que forzarlo aquí para que refleje el nombre recién confirmado.
    if(typeof updateDraftCounter==='function') updateDraftCounter();
    document.getElementById("matchOverlay").innerHTML="";
    // Save team name to Firebase profile if logged in
    if(typeof firebase!=='undefined'){
      try{
        const user=firebase.auth().currentUser;
        if(user) firebase.firestore().collection("users").doc(user.uid)
          .set({lastTeamName:myTeamName},{merge:true});
      }catch(e){}
    }
    if(window._duelId){
      mpOnDraftComplete();
    }else{
      setupGroupStage();
      renderCenterSummary();
      pickNextOpponent();
    }
  };
  document.getElementById("teamNameConfirmBtn").addEventListener("click",confirmFn);
  inp.addEventListener("keydown",e=>{ if(e.key==="Enter") confirmFn(); });
}

/* ---------- GROUP STAGE SETUP ---------- */
function setupGroupStage(){
  // Giro Táctico: 1 uso disponible por torneo (modo un jugador)
  window._giroCharges=getMaxGiroCharges();
  const pool=teams.slice();
  shuffle(pool);
  groupOpponents=pool.slice(0,3);
  groupMatchIdx=0;
  groupTable=[
    {name:myTeamName, isMe:true, team:null, played:0, won:0, drawn:0, lost:0, gf:0, ga:0, pts:0},
    ...groupOpponents.map(t=>({name:t.name, isMe:false, team:t, played:0, won:0, drawn:0, lost:0, gf:0, ga:0, pts:0}))
  ];
  // Reserve a pool of further teams for the knockout bracket (16 slots, excluding group teams)
  const used=new Set([myTeamName, ...groupOpponents.map(t=>t.name)]);
  knockoutPool=teams.filter(t=>!used.has(t.name));
  shuffle(knockoutPool);
}

/* ---------- OPPONENT SELECTION ---------- */
function pickNextOpponent(){
  selectedMatchStrategy=null; // fresh strategy choice for each new match
  applyPendingSuspensions(); // activate/lift card suspensions for the upcoming match
  updateConvocadosTable();
  updateBenchTable();
  if(typeof startCampoGuideTimer==='function') startCampoGuideTimer();
  if(stage==="group"){
    nextOpponent=groupOpponents[groupMatchIdx];
  } else if(stage==="knockout"){
    nextOpponent=knockoutPool[knockoutRound] || teams[Math.floor(Math.random()*teams.length)];
  } else {
    return;
  }
  renderCenterSummary();
  if(window.innerWidth<=1050 && typeof switchMobileTab==='function'){
    switchMobileTab('rival');
  }
  spinRivalReveal();
  scrollToEl("rivalBox", 30);
  scrollToEl("rivalBox", 950); // re-anchor after the reveal settles and content height changes
}
function spinRivalReveal(){
  const rivalInfo=document.getElementById("rivalInfo");
  const rivalHint=document.getElementById("rivalHint");
  rivalHint.textContent="";
  rivalInfo.innerHTML=`<div class="rival-card"><div class="team-option slot-reel rival-slot-reel"><div class="flag-wrap"><div class="slot-strip" id="rivalReel"></div></div></div></div>`;
  const reel=document.getElementById("rivalReel");
  const pool=teams;
  const spin=setInterval(()=>{
    const r=pool[Math.floor(Math.random()*pool.length)];
    reel.innerHTML=flagEmoji(r.name,56);
    playSound('spin');
  },80);
  setTimeout(()=>{
    clearInterval(spin);
    playSound('reveal');
    renderRivalBox();
    rollWeather();
    renderWeather();
    updateLed();
    if(typeof notifyMobileRivalTab==='function') notifyMobileRivalTab();
    updateLed();
    // Predictive press conference: shown right as the rival appears,
    // BEFORE the match is played — the prediction is resolved against
    // the real result once this match finishes.
    setTimeout(()=>{ maybeShowPressConference(()=>{}); }, 600);
  },900);
}
function renderRivalBox(){
  if(!nextOpponent) return;
  const power=computeOppPower(nextOpponent);
  const hint=getScoutHint(nextOpponent);
  document.getElementById("rivalInfo").innerHTML=`
    <div class="rival-card">
      <div class="rival-stage-tag">${stageLabel()}</div>
      <div class="rival-flag">${flagEmoji(nextOpponent.name,48)}</div>
      <h4>${getTeamName(nextOpponent.name)}</h4>
      <div class="rival-power-bar">
        <div class="rival-power-label">${window.t?window.t('rival.power_label'):'PODER RIVAL'}</div>
        <div class="rival-power-value">${Math.round(power)}</div>
        <div class="rival-power-track"><div class="rival-power-fill" style="width:${Math.min(100,power)}%"></div></div>
      </div>
      <div class="style-label" style="margin-top:10px">${window.t?window.t('rival.style_label'):'Estilo de juego'}</div>
      <div class="rival-style-tag">${(()=>{const sk=nextOpponent._styleKey||'';if(!sk)return nextOpponent.style||'';const e=window.TRANSLATIONS&&window.TRANSLATIONS['style.name.'+sk];return e?(e[window.LANG]||e['es']||sk):(STYLES[sk]?STYLES[sk].name:sk);})()}</div>
    </div>`;
  document.getElementById("rivalHint").textContent=hint;
  renderStrategySelector();
}

/* ========= MATCH STRATEGY SELECTOR ========= */
function renderStrategySelector(){
  const el=document.getElementById("strategySelector");
  if(!el) return;
  // Hint de ESTRATEGA si está activo
  const estrategaHint = window.getEstrategaHint?window.getEstrategaHint():null;
  const hintHTML = estrategaHint
    ? `<div style="background:rgba(201,162,39,.12);border:1px solid var(--gold);padding:8px 12px;margin-bottom:10px;font-size:12px;color:var(--gold);display:flex;align-items:center;gap:8px">
        <span style="font-size:16px">⚡</span>
        <span><strong>ESTRATEGA:</strong> La mejor contra-táctica es <strong>${estrategaHint.name}</strong></span>
       </div>`
    : '';
  el.innerHTML=`
    ${hintHTML}
    <div class="style-label" style="margin-top:12px">${t("strategy.choose")}</div>
    <div class="strategy-grid">
      ${STRATEGY_ORDER.map(key=>{
        const s=STRATEGIES[key];
        const sel=selectedMatchStrategy===key?' selected':'';
        const isOptimal=estrategaHint&&estrategaHint.key===key?' style="outline:2px solid var(--gold)"':'';
        return `<button class="strategy-btn${sel}" data-key="${key}" onclick="chooseMatchStrategy('${key}')" title="${esc(s.desc)}"${isOptimal}>${s.name}</button>`;
      }).join('')}
    </div>
    ${selectedMatchStrategy?`<div class="strategy-desc">${STRATEGIES[selectedMatchStrategy].desc}</div>`:`<div class="strategy-desc strategy-desc-empty">${window.t?window.t('strategy.none'):'Sin estrategia elegida: sin bonus ni penalización.'}</div>`}
  `;
}
function chooseMatchStrategy(key){
  if(!STRATEGIES[key]) return;
  playSound('select');
  selectedMatchStrategy = (selectedMatchStrategy===key) ? null : key; // click again to deselect
  renderStrategySelector();
}
window.chooseMatchStrategy=chooseMatchStrategy;

/* ---------- HISTORY / GROUP TABLE / BRACKET DISPLAY ---------- */
function renderMatchHistory(){
  const el=document.getElementById("matchHistoryTable");
  const prog=document.getElementById("matchProgress");
  if(!el) return;
  if(prog) prog.textContent=stage==="group"?(t('result.match_progress_groups')||'FASE DE GRUPOS'):(getRoundName(knockoutRound)||t('hud.knockout')||'ELIMINATORIAS');
  let html="";
  // Always show group table once there are group matches
  if(groupTable.length && matchResults.some(r=>r.stage==="group")){
    html+=renderGroupTableHTML();
  }
  // Show knockout results below the group table
  const knockoutMatches=matchResults.filter(r=>r.stage==="knockout");
  if(knockoutMatches.length){
    html+=renderBracketHTML(knockoutMatches);
  }
  if(!html) html="";
  el.innerHTML=html;
}
function sortedGroupTable(){
  return [...groupTable].sort((a,b)=>{
    if(b.pts!==a.pts) return b.pts-a.pts;
    const gdA=a.gf-a.ga, gdB=b.gf-b.ga;
    if(gdB!==gdA) return gdB-gdA;
    return b.gf-a.gf;
  });
}
function renderGroupTableHTML(){
  if(!groupTable.length) return "";
  const sorted=sortedGroupTable();
  let rows="";
  sorted.forEach((r,i)=>{
    const qualified=i<2;
    const cls=r.isMe?"group-row-me":"";
    const displayName=getTeamName(r.name);
    rows+=`<tr class="${cls}${qualified?' group-row-qualified':''}">
      <td>${i+1}</td>
      <td>${r.isMe?('<span class="flag-emoji goat-emoji">🐐</span> '+displayName):(flagEmoji(r.name,18)+' '+displayName)}</td>
      <td>${r.played}</td>
      <td>${r.won}</td>
      <td>${r.drawn}</td>
      <td>${r.lost}</td>
      <td>${r.gf}-${r.ga}</td>
      <td><strong>${r.pts}</strong></td>
    </tr>`;
  });
  return `<table class="group-table"><thead><tr><th>#</th><th>${t('result.group_th_team')||'Equipo'}</th><th>${t('result.group_th_pld')||'PJ'}</th><th>${t('result.group_th_w')||'G'}</th><th>${t('result.group_th_d')||'E'}</th><th>${t('result.group_th_l')||'P'}</th><th>GF-GC</th><th>${t('result.group_th_pts')||'Pts'}</th></tr></thead><tbody>${rows}</tbody></table>
  <div class="hint-line">${t("comp.r16_advance")}</div>`;
}
function renderBracketHTML(knockoutMatches){
  let rows="";
  knockoutMatches.forEach(r=>{
    const cls=r.won?"res-win":"res-lose";
    const tag=r.won?"V":"D";
    rows+=`<tr><td>${r.roundName}</td><td>${flagEmoji(r.rival,16)} ${getTeamName(r.rival)}</td><td>${r.score}</td><td class="${cls}">${tag}</td></tr>`;
  });
  const nextRound=getRoundName(knockoutRound);
  return `<div class="hint-line" style="margin-top:10px;font-weight:700">ELIMINATORIAS</div>
  <table><thead><tr><th>${t('bracket.round')||'Ronda'}</th><th>${t('bracket.rival')||'Rival'}</th><th>${t('bracket.result')||'Resultado'}</th><th>${t('bracket.res')||'Res'}</th></tr></thead><tbody>${rows}</tbody></table>
  <div class="hint-line">${nextRound&&stage==="knockout"?(t('comp.next_round')+nextRound):'¡Final completada!'}</div>`;
}

/* ========= MATCH SIMULATION ========= */
const STAT_BASELINE=50;
function computeMyPower(){
  if(!usedPlayers.length) return 60;
  const baseAvg=usedPlayers.reduce((s,p)=>s+effRating(p),0)/usedPlayers.length;
  const statsAvg=Object.values(teamStats).reduce((a,b)=>a+(b||0),0)/5;
  return baseAvg + statsAvg*0.04;
}
function myStatProfile(){
  // teamStats already holds absolute 0-100 values (clamped)
  const out={};
  ["attack","defense","pace","passing","technique"].forEach(k=>{
    out[k]=Math.max(0,Math.min(100,teamStats[k]||0));
  });
  return out;
}
function oppStatProfile(team){
  const out={};
  ["attack","defense","pace","passing","technique"].forEach(k=>{
    out[k]=Math.max(0,Math.min(100,STAT_BASELINE+(team.bonuses&&team.bonuses[k]||0)));
  });
  return out;
}
function computeOppPower(team){
  const pl=team.players.slice(0,11);
  const avg=pl.length?pl.reduce((s,p)=>s+(p.rating||75),0)/pl.length:75;
  const bonusBoost=Object.values(team.bonuses||{}).reduce((a,b)=>a+(Math.abs(b)||0),0)*0.12;
  // Rival fatigue: mirrors player fatigue accumulation across the tournament.
  // Group stage: slight fatigue by match 2-3. Knockout: accumulates each round.
  // This balances the fact that the player manages fatigue but the AI doesn't.
  let fatiguePenalty=0;
  if(stage==='group'){
    // Match 1: fresh (0), Match 2: minor (-0.4), Match 3: noticeable (-0.9)
    fatiguePenalty=[0,0.4,0.9][groupMatchIdx]||0;
  } else {
    // Octavos(0):-1.2, Cuartos(1):-2.0, Semis(2):-2.8, Final(3):-3.5
    fatiguePenalty=[1.2,2.0,2.8,3.5][knockoutRound]||1.2;
  }
  return avg + bonusBoost - fatiguePenalty;
}
/* Tactical matchup: returns a small lambda modifier for each side based on
   attack-vs-defense and supporting stats. Capped so it nudges, not dominates. */
function tacticalModifier(myStats,oppStats){
  // Positive = favors "me" scoring more / conceding less
  const atkVsDef=(myStats.attack - oppStats.defense)/100;       // my attack vs their defense
  const theirAtkVsMyDef=(oppStats.attack - myStats.defense)/100; // their attack vs my defense
  const supportMine=(myStats.passing+myStats.technique+myStats.pace - (oppStats.passing+oppStats.technique+oppStats.pace))/300;
  // My scoring boost: my attack beating their defense, plus a bit of support
  const myScoreMod = atkVsDef*0.35 + supportMine*0.15;
  // Their scoring boost: their attack beating my defense, minus my support edge
  const oppScoreMod = theirAtkVsMyDef*0.35 - supportMine*0.15;
  return {
    myScoreMod: Math.max(-0.4, Math.min(0.4, myScoreMod)),
    oppScoreMod: Math.max(-0.4, Math.min(0.4, oppScoreMod)),
  };
}
/* Counter-strategy: compares the MATCH STRATEGY chosen by the player
   (Tiki-Taka, Catenaccio, etc., picked fresh before each match) against
   the rival's narrative style mapped to one of the 10 strategies. Picking
   the correct counter gives a meaningful lambda bonus; mirroring the
   rival's own strategy gives a small penalty. */
function getRivalStrategyKey(team){
  // Map the rival's narrative style to one of the 10 match strategies
  return TEAM_STYLE_TO_STRATEGY[team._styleKey] || "posesion";
}
function counterStrategyModifier(){
  // Bonus if the player picked the strategy that counters the rival's strategy.
  // Picking the SAME strategy as the rival (mirroring) gives a small penalty —
  // mirroring an opponent's approach rarely creates an advantage.
  if(!nextOpponent) return {myScoreMod:0, oppScoreMod:0};
  const rivalKey=getRivalStrategyKey(nextOpponent);
  const myKey=selectedMatchStrategy;
  if(!myKey) return {myScoreMod:0, oppScoreMod:0}; // no strategy chosen = neutral
  const rivalStrat=STRATEGIES[rivalKey];
  const myStrat=STRATEGIES[myKey];
  const rivalCountersMe = rivalStrat && rivalStrat.counters===myKey;
  const iCounterRival    = myStrat && myStrat.counters===rivalKey;
  const iPartiallyCounterRival = myStrat && myStrat.partialCounters && myStrat.partialCounters.includes(rivalKey);
  let mod=0;
  if(iCounterRival)             mod=+0.16;  // perfect read of the opponent
  else if(iPartiallyCounterRival) mod=+0.08; // good read, but not the ideal answer
  else if(rivalCountersMe)      mod=-0.10; // picked the strategy the rival naturally beats
  else if(myKey===rivalKey)     mod=-0.04; // mirroring rarely pays off
  return { myScoreMod:mod, oppScoreMod:-mod*0.5, level: iCounterRival?'perfect':iPartiallyCounterRival?'partial':(rivalCountersMe?'countered':(myKey===rivalKey?'mirror':'neutral')) };
}
function poissonSample(lambda){
  const L=Math.exp(-lambda); let k=0,p=1;
  do{ k++; p*=Math.random(); }while(p>L);
  return k-1;
}
function playMatch(){
  if(!nextOpponent) return;
  swapsUsedThisMatch=0;
  convSortMode='position'; // siempre ordenar por posición al empezar partido
  swapSelection=null;
  // Tick injury timers
  const recovered=[];
  [...usedPlayers,...bench].forEach(p=>{
    if(p.injury){ p.injury.remaining--;
      if(p.injury.remaining<=0){ p.injury=null; p.forcedInjured=false; recovered.push(p.name); }
    }
  });
  refreshPitchRatings();
  baseTeamOVR=computeTeamOVR();
  updateConvocadosTable();
  updateBenchTable();
  const myPower=computeMyPower();
  const oppPower=computeOppPower(nextOpponent);
  // Base difference from overall player quality — dampened so matches stay close
  const diff=(myPower-oppPower)*0.03;
  // Tactical matchup from stats (attack vs defense, etc.) — meaningful but not dominant
  const tactical=tacticalModifier(myStatProfile(), oppStatProfile(nextOpponent));
  const counter=counterStrategyModifier();
  // Early-game cushion: the first 2 matches of EACH stage (group stage and
  // knockout stage) are a bit gentler, so a run of bad luck right at the
  // start of a new stage doesn't end the run instantly.
  const stageMatchIdx = stage==="group" ? groupMatchIdx : knockoutRound;
  // Early cushion per stage: the first 2 matches of groups AND knockout
  // are gentler so bad luck doesn't end the run immediately.
  const earlyBoost = stageMatchIdx===0 ? 0.18 : (stageMatchIdx===1 ? 0.10 : 0);
  // Small persistent nudge: groups favour qualification, knockout gives
  // a modest ongoing advantage so reaching the semis/final feels achievable.
  const groupNudge = stage==="group" ? 0.05 : 0.03;
  const starBonus=starMatchBonus();
  const moraleBonus=moraleLambdaBonus();
  const streakBonus=getStreakLambdaBonus();
  const weatherDelta=weatherLambdaEffect(); // weather was rolled when rival was revealed
  const captainBonus=(window._skillCache&&window._skillCache.capitan&&teamMorale<0)?0.10:0;
  const myLambda=Math.max(0.25, 1.15+diff+tactical.myScoreMod+counter.myScoreMod+earlyBoost+groupNudge+starBonus+moraleBonus+streakBonus+weatherDelta+captainBonus);
  const oppLambda=Math.max(0.25, 1.15-diff+tactical.oppScoreMod+counter.oppScoreMod-earlyBoost*0.6-groupNudge*0.6+weatherDelta);
  // Giro Táctico (modo un jugador): guarda los ritmos base del partido
  // para poder recalcular lo que resta si el jugador usa la habilidad.
  window._giroLambdaCtx={myLambda, oppLambda};
  let myGoals=window.CHEATS_ACTIVE ? (3+Math.floor(Math.random()*3)) : poissonSample(myLambda);
  // REMONTADA: si el rival marcara 2+ más, relanzar con +35%
  if(!window.CHEATS_ACTIVE && window._skillCache&&window._skillCache.remontada){
    const tempOpp=poissonSample(oppLambda);
    if(tempOpp>=myGoals+2) myGoals=poissonSample(myLambda*1.35);
  }
  let oppGoals=window.CHEATS_ACTIVE ? 0 : poissonSample(oppLambda);
  // Injuries y tarjetas propias
  const newInjuries=rollInjuries(myPower,oppPower);
  const newCards=rollCards();
  // Eventos del rival (lesiones y tarjetas)
  const oppEvents=rollOppEvents(oppPower,myPower);
  // Si el rival tiene una expulsión, su lambda se reduce proporcionalmente
  let adjOppLambda=oppLambda;
  if(oppEvents.redMinute!==null){
    const fracWith10=Math.max(0,(90-oppEvents.redMinute)/90);
    adjOppLambda=oppLambda*(1-fracWith10*0.11);
  }
  if(!window.CHEATS_ACTIVE && oppEvents.redMinute!==null){
    oppGoals=poissonSample(adjOppLambda);
  }
  // Procesar tarjetas por faltas que causaron lesiones
  if(newInjuries&&newInjuries.length){
    newInjuries.forEach(inj=>{
      if(!inj.injury||!inj.injury.foulCard) return;
      const card=inj.injury.foulCard;
      if(!oppEvents.cards) oppEvents.cards=[];
      const oppPool=nextOpponent?nextOpponent.players:[];
      if(oppPool.length){
        const fouler=oppPool[Math.floor(Math.random()*oppPool.length)];
        oppEvents.cards.push({player:fouler, type:card, isFoul:true});
        if(card==='red'&&!oppEvents.redMinute){
          oppEvents.redMinute=Math.floor(20+Math.random()*60);
          const fracWith10=Math.max(0,(90-oppEvents.redMinute)/90);
          adjOppLambda=adjOppLambda*(1-fracWith10*0.11);
          if(!window.CHEATS_ACTIVE) oppGoals=poissonSample(adjOppLambda);
        }
      }
    });
  }

  // Generar summary DESPUÉS de todos los recálculos de goles
  let summary=generateMatchSummary(myGoals,oppGoals,getTeamName(nextOpponent.name));
  updateScorerStreaks(generateMatchSummary._scorers||[]);

  // Procesar expulsiones durante el partido:
  // Jugadores con roja/doble amarilla se retiran si hay hueco en banquillo.
  // Si el banquillo está lleno, se quedan en el campo con rating 0.
  applyInMatchRedCards(newCards);

  // Fatigue y tabla se actualizan al TERMINAR el partido (en showPostMatch)
  // para que la tabla de convocados no cambie mientras se simula

  let won, draw=false, penaltyInfo=null, scoreLabel;
  if(stage==="group"){
    // Group stage: draws are allowed, no penalty shootout.
    if(myGoals===oppGoals){ draw=true; won=false; }
    else won=myGoals>oppGoals;
    scoreLabel=`${myGoals}-${oppGoals}`;
  } else {
    // Knockout: a draw must be resolved via penalties.
    won=myGoals>oppGoals;
    if(myGoals===oppGoals){
      penaltyInfo=simulatePenalties(myPower,oppPower);
      won=penaltyInfo.myWon;
      const myShotsHTML=penaltyInfo.myShots.map(s=>`<li>${s.scored?'✅':'❌'} ${s.name}</li>`).join('');
      const oppShotsHTML=penaltyInfo.oppShots.map(s=>`<li>${s.scored?'✅':'❌'} ${s.name}</li>`).join('');
      summary+=`<br><br><strong>⚽ TANDA DE PENALTIS: ${myTeamName} ${penaltyInfo.myScore} – ${penaltyInfo.oppScore} ${getTeamName(nextOpponent.name)}</strong>
      <div class="goals-columns">
        <div class="goals-col">
          <div class="goals-col-header"><span class="flag-emoji goat-emoji">🐐</span> ${myTeamName}</div>
          <ul class="goals-list pen-shots">${myShotsHTML}</ul>
        </div>
        <div class="goals-col">
          <div class="goals-col-header">${flagEmoji(nextOpponent.name,20)} ${getTeamName(nextOpponent.name)}</div>
          <ul class="goals-list pen-shots">${oppShotsHTML}</ul>
        </div>
      </div>`;
    }
    scoreLabel = penaltyInfo ? `${myGoals}-${oppGoals} (pen. ${penaltyInfo.myScore}-${penaltyInfo.oppScore})` : `${myGoals}-${oppGoals}`;
  }

  if(stage==="group"){
    updateGroupTable(myGoals,oppGoals,won,draw);
    matchResults.push({stage:"group", roundName:"Fase de Grupos", rival:nextOpponent.name, score:scoreLabel, won, draw});
    groupMatchIdx++;
    if(groupMatchIdx>=3) simulateRivalMatches();
  } else {
    matchResults.push({stage:"knockout", roundName:getRoundName(knockoutRound), rival:nextOpponent.name, score:scoreLabel, won, draw:false});
  }

  // Update morale based on result
  // Morale: goals scored/conceded affect it directly
  const moralGoals   = myGoals  * 3;   // +3 per goal scored
  const moralConceded= oppGoals * (-4); // -4 per goal conceded
  // Result bonus (reduced — goals already carry most of the swing)
  const moralResult  = won ? 6 : draw ? 1 : -8;
  changeMorale(moralGoals + moralConceded + moralResult);

  // Save match stats to Firebase if logged in
  if(typeof window.saveMatchStat==="function"){
    window.saveMatchStat(won, draw, myGoals, oppGoals);
  }

  // Track best round for chain run rewards
  if(stage==="group") bestRoundReached=Math.max(bestRoundReached,0);
  else bestRoundReached=Math.max(bestRoundReached, knockoutRound+1);

  // Resolve any pending press prediction against the real match result
  const predictionResult=resolvePendingPrediction({
    myGoals, oppGoals, won, draw,
    penalties: !!penaltyInfo,
    cardsCount: newCards.length,
  });

  renderMatchHistory();
  updateLed();
  showLiveMatch(myGoals,oppGoals,summary,recovered,newInjuries,won,draw,penaltyInfo,newCards,predictionResult,oppEvents);
}
document.getElementById("playMatchBtn").addEventListener("click",playMatch);

/* Update the group table after a group-stage match for both "me" and the
   specific opponent faced. */
function updateGroupTable(myGoals,oppGoals,won,draw){
  const meRow=groupTable.find(r=>r.isMe);
  const oppRow=groupTable.find(r=>r.team===nextOpponent);
  meRow.played++; oppRow.played++;
  meRow.gf+=myGoals; meRow.ga+=oppGoals;
  oppRow.gf+=oppGoals; oppRow.ga+=myGoals;
  if(draw){
    meRow.drawn++; oppRow.drawn++;
    meRow.pts+=1; oppRow.pts+=1;
  } else if(won){
    meRow.won++; meRow.pts+=3;
    oppRow.lost++;
  } else {
    meRow.lost++;
    oppRow.won++; oppRow.pts+=3;
  }
}

/* Simulate the 3 inter-rival matches that don't involve the player
   (A vs B, A vs C, B vs C), so the group table is fully populated.
   Called once after the player finishes their 3rd group match. */
function simulateRivalMatches(){
  const rivals=[groupOpponents[0], groupOpponents[1], groupOpponents[2]];
  const pairs=[[0,1],[0,2],[1,2]];
  pairs.forEach(([ai,bi])=>{
    const a=rivals[ai], b=rivals[bi];
    const pa=computeOppPower(a), pb=computeOppPower(b);
    const diff=(pa-pb)*0.03;
    const la=Math.max(0.25, 1.1+diff);
    const lb=Math.max(0.25, 1.1-diff);
    const ga=poissonSample(la), gb=poissonSample(lb);
    const rowA=groupTable.find(r=>r.team===a);
    const rowB=groupTable.find(r=>r.team===b);
    rowA.played++; rowB.played++;
    rowA.gf+=ga; rowA.ga+=gb;
    rowB.gf+=gb; rowB.ga+=ga;
    if(ga>gb){
      rowA.won++; rowA.pts+=3; rowB.lost++;
    } else if(gb>ga){
      rowB.won++; rowB.pts+=3; rowA.lost++;
    } else {
      rowA.drawn++; rowA.pts+=1;
      rowB.drawn++; rowB.pts+=1;
    }
  });
}

function simulatePenalties(myPower,oppPower){
  // Probability of scoring a penalty, slightly influenced by overall power
  const _penSkill=(window._skillCache&&window._skillCache.penaltis)?0.15:0;
  const myProb=Math.min(0.92,Math.max(0.65,0.78+(myPower-oppPower)*0.01+_penSkill));
  const oppProb=Math.min(0.92,Math.max(0.65,0.78+(oppPower-myPower)*0.01));
  let myScore=0,oppScore=0;
  // Pick takers from my squad (prioritize attackers/midfielders)
  const priority=usedPlayers.filter(p=>p.placedPos&&["DC","EI","ED","MC"].includes(p.placedPos));
  const rest=usedPlayers.filter(p=>!priority.includes(p));
  const order=[...priority,...rest].slice(0,Math.max(5,0));
  // Pick takers from rival squad (prioritize attackers/midfielders)
  const oppPriority=nextOpponent.players.filter(p=>p.positions&&p.positions.some(pos=>["DC","EI","ED","MC"].includes(pos)));
  const oppRest=nextOpponent.players.filter(p=>!oppPriority.includes(p));
  const oppOrder=[...oppPriority,...oppRest];
  const myShots=[]; const oppShots=[];
  // Best-of-5 rounds, then sudden death
  for(let i=0;i<5;i++){
    const taker=order[i%order.length]||{name:myTeamName};
    const scored=Math.random()<myProb;
    if(scored) myScore++;
    myShots.push({name:taker.name,scored});
    const oppTaker=oppOrder[i%oppOrder.length]||{name:nextOpponent.name};
    const oppScored=Math.random()<oppProb;
    if(oppScored) oppScore++;
    oppShots.push({name:oppTaker.name,scored:oppScored});
  }
  let rounds=0;
  while(myScore===oppScore && rounds<10){
    const taker=order[(5+rounds)%order.length]||{name:myTeamName};
    const scored=Math.random()<myProb;
    if(scored) myScore++;
    myShots.push({name:taker.name,scored});
    const oppTaker=oppOrder[(5+rounds)%oppOrder.length]||{name:nextOpponent.name};
    const oppScored=Math.random()<oppProb;
    if(oppScored) oppScore++;
    oppShots.push({name:oppTaker.name,scored:oppScored});
    rounds++;
  }
  if(myScore===oppScore){ // extremely unlikely fallback
    if(Math.random()<0.5) myScore++; else oppScore++;
  }
  return {myScore,oppScore,myWon:myScore>oppScore,myShots,oppShots};
}

function generateMatchSummary(myGoals,oppGoals,rivalName){
  const possession=Math.round(45+Math.random()*20);
  const oppPoss=100-possession;
  const shots=myGoals*2+Math.floor(Math.random()*5)+3;
  const oppShots=oppGoals*2+Math.floor(Math.random()*4)+2;
  // Distribute goals across 90 min
  const myMinutes=[]; const oppMinutes=[];
  for(let i=0;i<myGoals;i++) myMinutes.push(Math.floor(5+Math.random()*85));
  for(let i=0;i<oppGoals;i++) oppMinutes.push(Math.floor(5+Math.random()*85));
  myMinutes.sort((a,b)=>a-b); oppMinutes.sort((a,b)=>a-b);
  // Pick random scorers from usedPlayers (mine) and the rival's squad
  const attackers=usedPlayers.filter(p=>p.placedPos&&["DC","EI","ED","MC"].includes(p.placedPos));
  const oppAttackers=nextOpponent.players.filter(p=>p.positions&&p.positions.some(pos=>["DC","EI","ED","MC"].includes(pos)));
  const oppPool=oppAttackers.length?oppAttackers:nextOpponent.players;
  const lastMatchScorers=[]; // store scorer names for streak tracking
  const myGoalLines=myMinutes.map(min=>{
    const scorer=attackers[Math.floor(Math.random()*attackers.length)]||usedPlayers[0];
    if(scorer) lastMatchScorers.push(scorer.name);
    // Buscar el emoji del equipo del goleador usando su id
    const scorerTeamEmoji=(()=>{
      if(!scorer||!scorer.id) return '';
      const parts=scorer.id.split('_');
      // id format: p_TEAMID_N o p_team_NAME_N
      let teamId;
      if(parts[1]==='team') teamId=null; // equipos especiales
      else teamId='team_'+parts[1];
      if(teamId){
        const t=teams.find(x=>x.id===teamId);
        return t?t.emoji||'':'';
      }
      return '';
    })();
    return `<li>⚽ ${scorerTeamEmoji} ${scorer?scorer.name:'Desconocido'} <span class="goal-min">(${min}')</span></li>`;
  });
  generateMatchSummary._scorers=lastMatchScorers;
  const oppGoalLines=oppMinutes.map(min=>{
    const scorer=oppPool[Math.floor(Math.random()*oppPool.length)];
    const oppEmoji=nextOpponent?nextOpponent.emoji||'':'';
    return `<li>⚽ ${oppEmoji} ${scorer?scorer.name:rivalName} <span class="goal-min">(${min}')</span></li>`;
  });

  const goalsHTML=`
  <div class="goals-columns">
    <div class="goals-col">
      <div class="goals-col-header"><span class="flag-emoji goat-emoji">🐐</span> ${myTeamName}</div>
      <ul class="goals-list">${myGoalLines.length?myGoalLines.join(''):'<li class="no-goal">Sin goles</li>'}</ul>
    </div>
    <div class="goals-col">
      <div class="goals-col-header">${flagEmoji(rivalName,20)} ${rivalName}</div>
      <ul class="goals-list">${oppGoalLines.length?oppGoalLines.join(''):'<li class="no-goal">Sin goles</li>'}</ul>
    </div>
  </div>`;

  return `<strong>${t("match.possession")}:</strong> ${myTeamName} ${possession}% · ${rivalName} ${oppPoss}%<br>
<strong>${t("match.shots")}:</strong> ${shots} – ${oppShots}
${goalsHTML}`;
}

function rollInjuries(myPower,oppPower){
  const fb=currentFormationBonus||{};
  const extreme=Math.abs((fb.attack||0)-(fb.defense||0));
  let risk=0.06;
  if(extreme>=16) risk=0.08;
  if((fb.defense||0)<(fb.attack||0)&&oppPower>myPower) risk+=0.015;
  const injured=[];
  usedPlayers.forEach(p=>{
    if(injured.length>=1||p.injury) return;
    if(Math.random()<risk){
      const r=Math.random();
      let type,remaining;
      if(r<0.5){type="leve";remaining=1;}
      else if(r<0.85){type="básica";remaining=2;}
      else{type="grave";remaining=3;}
      p.injury={type,remaining};
      // Tarjeta al rival por la falta que causó la lesión:
      // lesión leve → amarilla (80%) o nada (20%)
      // lesión básica → amarilla (60%) o roja (40%)
      // lesión grave → roja directa siempre
      const rCard=Math.random();
      let foulCard=null;
      if(type==='leve'){
        if(rCard<0.8) foulCard='yellow';
      } else if(type==='básica'){
        foulCard=rCard<0.6?'yellow':'red';
      } else {
        foulCard='red';
      }
      p.injury.foulCard=foulCard; // guardamos para el feed
      injured.push(p);
    }
  });
  return injured;
}

/* ========= CARD SYSTEM (yellow/red, real World Cup rules) ========= */
// Per-player risk calibrated to real World Cup averages: ~1.8 yellow cards
// and ~0.1 red cards per TEAM per match (11 players), based on historical
// editions (1990: 3.71 yellows/match total both teams; 2006: ~5.4 — we use
// a middle-ground average, split evenly between both teams).
// Calibración basada en estadísticas históricas del Mundial:
// Media real: ~1.3-1.8 amarillas por equipo por partido (histórico 1990-2022)
// Con 11 jugadores: 0.12 por jugador → ~1.32 amarillas esperadas por partido
// Rojas directas reales: ~0.1 por partido → 0.009 por jugador correcto
const YELLOW_RISK_PER_PLAYER = 0.055; // ~0.6 amarillas/equipo/partido base
const RED_RISK_PER_PLAYER    = 0.009;

function rollCards(){
  const cardedThisMatch=[]; // {player, type: 'yellow'|'second_yellow_match'|'yellow2'|'red'}
  const yellowedThisMatch=new Set();
  usedPlayers.forEach(p=>{
    if(p.suspended) return; // already suspended this match, can't play/get carded (shouldn't be on pitch anyway)
    const r=Math.random();
    if(r<RED_RISK_PER_PLAYER){
      // Straight red — automatic suspension for the NEXT match
      p.suspendedNextMatch=true;
      p.cardStatus='red';
      cardedThisMatch.push({player:p, type:'red'});
    } else if(r<RED_RISK_PER_PLAYER+YELLOW_RISK_PER_PLAYER){
      yellowedThisMatch.add(p);
      p.yellowCount=(p.yellowCount||0)+1;
      if(p.yellowCount>=2){
        // Second yellow in DIFFERENT matches = accumulation suspension
        p.suspendedNextMatch=true;
        p.cardStatus='yellow2';
        cardedThisMatch.push({player:p, type:'yellow2'});
        p.yellowCount=0; // reset after serving the suspension trigger
      } else {
        p.cardStatus='yellow1';
        cardedThisMatch.push({player:p, type:'yellow'});
      }
    }
  });
  // Rare second pass: a player already booked this match has a small chance
  // of picking up a SECOND yellow in the SAME match (real "doble amarilla"
  // rule) — straight expulsion + suspension for the next match, regardless
  // of their accumulation count.
  const SAME_MATCH_SECOND_YELLOW_RISK=0.05; // 5% of those already booked this match
  yellowedThisMatch.forEach(p=>{
    if(p.suspendedNextMatch) return; // already sent off via accumulation or red
    if(Math.random()<SAME_MATCH_SECOND_YELLOW_RISK){
      p.suspendedNextMatch=true;
      p.cardStatus='double_yellow';
      cardedThisMatch.push({player:p, type:'double_yellow'});
    }
  });
  return cardedThisMatch;
}

/* ── Expulsiones durante el partido actual ──────────────────────────────
   Jugadores con roja o doble amarilla se mueven al banquillo si hay hueco.
   Si el banquillo está lleno, permanecen en el campo con rating=0. ── */
function applyInMatchRedCards(newCards){
  if(!newCards||!newCards.length) return;
  const reds=newCards.filter(c=>c.type==='red'||c.type==='double_yellow');
  if(!reds.length) return;
  const slots=getPitchSlots();
  reds.forEach(({player:p})=>{
    // Marcar como expulsado en este partido
    p._redThisMatch=true;
    // ¿Hay hueco en el banquillo?
    const benchFull=bench.filter(b=>b).length>=getMaxBench();
    if(!benchFull){
      // Mover al banquillo — encontrar su slot
      const slot=slots.find(s=>s._player===p);
      if(slot){
        bench.push({...p, fatigue:p.fatigue||100});
        // Liberar el slot del campo (quedará vacío hasta que el usuario actúe)
        slot._player=null;
        slot.querySelector&&slot.querySelector('.pitch-player-label')&&
          (slot.querySelector('.pitch-player-label').textContent='');
      }
    } else {
      // Banquillo lleno: se queda en el campo con rating 0
      p._redThisMatchOnPitch=true;
      p._originalRating=p.rating;
      p.rating=0;
    }
  });
}

/* ========= EVENTOS DEL RIVAL (lesiones y tarjetas) ========= */
function rollOppEvents(oppPower, myPower){
  const opp=nextOpponent;
  if(!opp||!opp.players||!opp.players.length) return {injuries:[], cards:[], redMinute:null};

  const pool=opp.players.filter(p=>p.positions&&!p.positions.includes('POR'));
  const allPool=opp.players;

  // Lesiones del rival — probabilidad similar a la del jugador
  const injRisk=0.06;
  const oppInjuries=[];
  const injPlayer=allPool[Math.floor(Math.random()*allPool.length)];
  if(injPlayer && Math.random()<injRisk){
    // Determinar gravedad y tarjeta correspondiente a mi jugador
    const r=Math.random();
    let injType;
    if(r<0.5) injType='leve';
    else if(r<0.85) injType='básica';
    else injType='grave';

    const rCard=Math.random();
    let foulCard=null;
    if(injType==='leve'){ if(rCard<0.8) foulCard='yellow'; }
    else if(injType==='básica'){ foulCard=rCard<0.6?'yellow':'red'; }
    else { foulCard='red'; }

    injPlayer._injType=injType;
    injPlayer._foulCard=foulCard; // tarjeta que recibirá mi jugador
    oppInjuries.push(injPlayer);
  }

  // Tarjetas del rival
  const oppCards=[];
  let redMinute=null; // minuto de expulsión si hay roja
  const yellowRisk=0.017;
  const redRisk=0.010;
  const yellowed=[];

  pool.forEach(p=>{
    const r=Math.random();
    if(r<redRisk){
      oppCards.push({player:p, type:'red'});
      // El minuto de expulsión: entre 10' y 80'
      if(!redMinute) redMinute=Math.floor(10+Math.random()*70);
    } else if(r<redRisk+yellowRisk){
      yellowed.push(p);
      oppCards.push({player:p, type:'yellow'});
    }
  });
  // Doble amarilla rara
  yellowed.forEach(p=>{
    if(Math.random()<0.05 && !oppCards.find(c=>c.player===p&&c.type==='red')){
      oppCards.push({player:p, type:'double_yellow'});
      if(!redMinute) redMinute=Math.floor(10+Math.random()*70);
    }
  });

  return {injuries:oppInjuries, cards:oppCards, redMinute};
}

function clearYellowCardsAfterQuarterfinals(){
  // FIFA rule: accumulated yellow cards are wiped after the quarterfinals,
  // so nobody misses a final purely from earlier accumulation.
  usedPlayers.forEach(p=>{ p.yellowCount=0; if(p.cardStatus==='yellow1') p.cardStatus=null; });
  bench.forEach(p=>{ p.yellowCount=0; if(p.cardStatus==='yellow1') p.cardStatus=null; });
}

function applyPendingSuspensions(){
  // Called right before a new match starts — converts "suspended for next
  // match" flags into an active suspension that blocks that player from
  // being fielded, then clears the flag once served.
  [...usedPlayers, ...bench].forEach(p=>{
    if(p.suspendedNextMatch){
      p.suspended=true;
      p.suspendedNextMatch=false;
    } else if(p.suspended){
      // Suspension already served last match — lift it now
      p.suspended=false;
      p.cardStatus=null;
    }
  });
  // Any starting player who is now suspended must be moved to the bench
  // automatically — this does NOT consume one of the player's swaps, since
  // it's outside their control. If no bench player is free to swap in,
  // the slot is simply left empty until the user manually resolves it.
  forceSwapSuspendedStarters();
}

function forceSwapSuspendedStarters(){
  const slots=getPitchSlots();
  usedPlayers.forEach((convPlayer,convIdx)=>{
    if(!convPlayer || !convPlayer.suspended) return;
    // Find a bench player who is NOT suspended/injured to bring on
    const benchIdx=bench.findIndex(b=>b && !b.suspended);
    const slot=slots.find(s=>s._player===convPlayer);
    if(!slot) return;
    const label=slot.dataset.label;
    if(benchIdx===-1){
      // No eligible bench replacement — leave the slot, but it stays
      // visibly flagged as suspended in the table so the user notices.
      return;
    }
    const benchPlayer=bench[benchIdx];
    benchPlayer.placedPos=label;
    delete convPlayer.placedPos;
    bench[benchIdx]=convPlayer;
    usedPlayers[convIdx]=benchPlayer;
    slot._player=benchPlayer;
    const inPos=benchPlayer.positions&&benchPlayer.positions.includes(label);
    const r=inPos?(benchPlayer.rating||70):Math.round((benchPlayer.rating||70)*0.85);
    const star=inPos&&benchPlayer.positions[0]===label?' <span class="star">★</span>':'';
    renderSlotContent(slot, benchPlayer, label, r, star);
  });
  baseTeamOVR=computeTeamOVR();
}

/* ========= LIVE MATCH SIMULATION — diseño match-modal + animación secuencial =========
   Usa el diseño visual de match-modal pero muestra todo de forma secuencial.
   Los eventos ocurren en sus minutos reales, incluyendo tiempo de descuento. */
function showLiveMatch(myGoals,oppGoals,summary,recovered,newInjuries,won,draw,penaltyInfo,newCards,predictionResult,oppEvents){
  const overlay=document.getElementById("matchOverlay");
  const oppName=window._duelId?(window._duelOpponentUsername||'Rival'):(nextOpponent?getTeamName(nextOpponent.name):'Rival');

  // ── Parsear eventos del resumen HTML ──
  const tempDiv=document.createElement('div');
  tempDiv.innerHTML=summary;
  const goalCols=tempDiv.querySelectorAll('.goals-col');
  const allEvents=[];
  if(goalCols.length>=2){
    goalCols[0].querySelectorAll('li').forEach(li=>{
      const txt=li.textContent;
      const m=txt.match(/(\d+)'\)/);
      if(m) allEvents.push({minute:parseInt(m[1]),type:'mygoal',icon:'⚽',
        text:`<strong>${txt.replace(/⚽/,'').replace(/\(\d+'\)/,'').trim()}</strong>`});
    });
    goalCols[1].querySelectorAll('li').forEach(li=>{
      const txt=li.textContent;
      const m=txt.match(/(\d+)'\)/);
      if(m) allEvents.push({minute:parseInt(m[1]),type:'oppgoal',icon:'⚽',
        text:`<strong>${txt.replace(/⚽/,'').replace(/\(\d+'\)/,'').trim()}</strong> <span style="color:var(--red);font-size:10px">(${oppName})</span>`});
    });
  }
  // Tarjetas e lesiones con minutos realistas (pueden caer en descuento)
  const CICONS={yellow:'🟨',yellow2:'🟨🟨',double_yellow:'🟨🟥',red:'🟥'};
  if(newCards&&newCards.length){
    newCards.forEach(c=>allEvents.push({
      minute:c.minute!==undefined?c.minute:Math.floor(5+Math.random()*90),
      type:'card',icon:CICONS[c.type]||'🟨',
      text:`<strong>${c.player.name}</strong>`
    }));
  }
  if(newInjuries&&newInjuries.length){
    newInjuries.forEach(p=>{
      const injMin=p.minute!==undefined?p.minute:Math.floor(20+Math.random()*65);
      // Lesión
      allEvents.push({
        minute:injMin,
        type:'injury',icon:'✚',
        text:`<strong>${p.name}</strong>`
      });
      // Tarjeta al rival en el mismo minuto (falta que causó la lesión)
      if(p.injury&&p.injury.foulCard){
        let foulerName=p.foulerName;
        if(!foulerName){
          const oppPool=nextOpponent?nextOpponent.players:[];
          const fouler=oppPool[Math.floor(Math.random()*oppPool.length)];
          foulerName=fouler?fouler.name:null;
        }
        if(foulerName){
          const cardIcon=CICONS[p.injury.foulCard]||'🟨';
          allEvents.push({
            minute:injMin, // mismo minuto que la lesión
            type:'oppcard',
            icon:cardIcon,
            text:`<strong>${foulerName}</strong> <span style="font-size:10px;color:#e74c3c">(falta sobre ${p.name})</span>`
          });
        }
      }
    });
  }
  // Eventos del rival (lesiones y tarjetas)
  if(oppEvents){
    const CICONS={yellow:'🟨',double_yellow:'🟨🟥',red:'🟥'};
    if(oppEvents.injuries&&oppEvents.injuries.length){
      oppEvents.injuries.forEach(p=>{
        const injMin=p.minute!==undefined?p.minute:Math.floor(20+Math.random()*65);
        // Lesión del rival (feed derecha)
        allEvents.push({
          minute:injMin,
          type:'oppinjury',icon:'✚',
          text:`<strong>${p.name}</strong>`
        });
        // Tarjeta a mi jugador por la falta (feed izquierda), mismo minuto
        if(p._foulCard){
          let foulerName=p.foulerName;
          let fouler=foulerName?usedPlayers.find(pl=>pl.name===foulerName):null;
          if(!fouler && usedPlayers.length){
            fouler=usedPlayers[Math.floor(Math.random()*usedPlayers.length)];
            foulerName=fouler.name;
          }
          if(foulerName){
            const cardIcon=CICONS[p._foulCard]||'🟨';
            allEvents.push({
              minute:injMin,
              type:'card',icon:cardIcon,
              text:`<strong>${foulerName}</strong> <span style="font-size:10px;color:#a07a00">(${t('match.foul_on')||'falta sobre'} ${p.name})</span>`
            });
            // Si es roja, aplicar también las consecuencias de sanción
            if(p._foulCard==='red' && fouler){
              fouler.suspendedNextMatch=true;
              fouler.cardStatus='red';
              newCards.push({player:fouler, type:'red', _foulRed:true});
            }
          }
        }
      });
    }
    if(oppEvents.cards&&oppEvents.cards.length){
      oppEvents.cards.forEach(c=>allEvents.push({
        minute:c.minute!==undefined?c.minute:(c.type==='red'||c.type==='double_yellow'?(oppEvents.redMinute||Math.floor(10+Math.random()*70)):Math.floor(5+Math.random()*85)),
        type:'oppcard',icon:CICONS[c.type]||'🟨',
        text:`<strong>${c.player.name}</strong>`
      }));
    }
  }
  allEvents.sort((a,b)=>a.minute-b.minute);

  // Tiempos de descuento
  const inj1=Math.floor(1+Math.random()*4);
  const inj2=Math.floor(2+Math.random()*5);
  const MAX_MIN=90+inj2;

  // Resultado
  const wasShootout=!!penaltyInfo;
  let resultText,resultClass;
  if(draw){ resultText=t("match.draw"); resultClass="res-draw-tag"; }
  else {
    resultText=won?(wasShootout?t("match.victory"):t("match.victory")):(wasShootout?t("match.defeat"):t("match.defeat"));
    resultClass=won?"res-win-tag":"res-lose-tag";
  }

  // ── HTML inicial — diseño match-modal ──
  overlay.innerHTML=`
  <div class="match-modal" style="overflow:hidden;display:flex;flex-direction:column;max-height:85vh;position:relative">
    <button id="giroTacticoBtn" style="position:absolute;top:8px;left:8px;z-index:5;display:flex;align-items:center;gap:5px;background:none;border:1px solid ${window._giroCharges>0?'var(--gold)':'#555'};color:${window._giroCharges>0?'var(--gold)':'#777'};font-family:'Bebas Neue',Impact,sans-serif;font-size:11px;letter-spacing:.5px;padding:4px 9px;border-radius:5px;cursor:${window._giroCharges>0?'pointer':'not-allowed'}" ${window._giroCharges>0?'':'disabled'}><i class="ph ph-bold ph-notebook" style="font-size:15px"></i> GIRO TÁCTICO ${window._giroCharges||0}/${getMaxGiroCharges()}</button>
    ${window._duelId?`<div style="text-align:center;font-family:'Bebas Neue',Impact,sans-serif;font-size:14px;letter-spacing:1.5px;color:var(--gold);text-transform:uppercase;padding-bottom:4px">${(tk('mp.duel_match_of')||'PARTIDO {0} DE 5').replace('{0}', String(window._duelMatchIndex+1))}</div>`:''}
    <div class="match-header">
      <div class="match-side">
        ${window._duelId?'<i class="ph ph-bold ph-user" style="font-size:22px;color:#4a90d9"></i>':'<span class="match-flag">🐐</span>'}
        <span class="match-team-name">${myTeamName}</span>
      </div>
      <div style="text-align:center;flex:0 0 auto">
        <div class="match-scoreline" id="liveScore" style="font-size:42px;letter-spacing:4px">0 – 0</div>
        <div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-top:4px">
          <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:20px;color:var(--gold)" id="liveClock">0'</div>
          <div style="font-size:9px;font-weight:700;background:var(--accent);color:#fff;padding:2px 7px;letter-spacing:1px;text-transform:uppercase" id="liveHalf">1ª PARTE</div>
        </div>
        <div style="height:4px;background:#eee;border-radius:2px;margin-top:6px;overflow:hidden">
          <div id="liveFill" style="height:100%;background:var(--accent);border-radius:2px;width:0%;transition:width .15s linear"></div>
        </div>
      </div>
      <div class="match-side">
        ${window._duelId?'<i class="ph ph-bold ph-user" style="font-size:22px;color:#e74c3c"></i>':(nextOpponent?flagEmoji(nextOpponent.name):'<span style="font-size:22px">👤</span>')}
        <span class="match-team-name">${oppName}</span>
      </div>
    </div>
    <div id="liveEvents" style="flex:1;overflow-y:auto;display:flex;flex-direction:column;align-items:stretch;gap:2px;padding:4px 0;min-height:80px;max-height:260px"></div>
  </div>`;

  const eventsEl=document.getElementById('liveEvents');
  const clockEl=document.getElementById('liveClock');
  const halfEl=document.getElementById('liveHalf');
  const fillEl=document.getElementById('liveFill');
  const scoreEl=document.getElementById('liveScore');
  let curMy=0,curOpp=0;

  function flashScore(){ scoreEl.classList.remove('goal-flash'); void scoreEl.offsetWidth; scoreEl.classList.add('goal-flash'); }

  function addSep(text){
    const sep=document.createElement('div');
    sep.style.cssText='text-align:center;font-size:10px;font-weight:700;color:var(--accent);letter-spacing:2px;padding:4px 0;border-top:1px solid #eee;border-bottom:1px solid #eee;margin:2px 0;text-transform:uppercase';
    sep.textContent=text;
    eventsEl.appendChild(sep);
    eventsEl.scrollTop=eventsEl.scrollHeight;
  }

  function addEvt(icon,text,minLabel,type){
    const item=document.createElement('div');
    item.style.cssText='display:grid;grid-template-columns:1fr 44px 1fr;align-items:center;width:100%;font-size:12px;animation:slideInEvent .3s ease;opacity:0;animation-fill-mode:forwards;padding:3px 0;border-bottom:1px solid rgba(0,0,0,.05)';
    const isMe=type==='mygoal'||type==='card'||type==='injury'||type==='pen_me';
    const isOpp=type==='oppgoal'||type==='pen_opp'||type==='oppcard'||type==='oppinjury';
    const myColor=type==='mygoal'||type==='pen_me'?'var(--accent)':type==='card'?'#a07a00':type==='injury'?'#e74c3c':'var(--text)';
    const oppColor=type==='oppgoal'||type==='pen_opp'?'var(--red)':type==='oppcard'?'#a07a00':type==='oppinjury'?'#e74c3c':'var(--text)';
    // Centro: minuto
    const center=`<span style="font-family:'Bebas Neue',Impact,sans-serif;font-size:15px;color:#aaa;text-align:center;display:block;letter-spacing:.5px">${minLabel}</span>`;
    if(isMe){
      item.innerHTML=`<span style="text-align:right;padding-right:6px;color:${myColor};line-height:1.3">${text} <span style="font-size:14px">${icon}</span></span>${center}<span></span>`;
    } else if(isOpp){
      item.innerHTML=`<span></span>${center}<span style="text-align:left;padding-left:6px;color:${oppColor};line-height:1.3"><span style="font-size:14px">${icon}</span> ${text}</span>`;
    } else {
      // penalti neutro o separador inline
      item.innerHTML=`<span style="text-align:right;padding-right:6px;color:var(--text);line-height:1.3">${text} ${icon}</span>${center}<span></span>`;
    }
    eventsEl.appendChild(item);
    eventsEl.scrollTop=eventsEl.scrollHeight;
  }

  // ── Animación — fase 1 reglamento (9s) ──────────────────────────────────
  const REG_DURATION=9000;
  const HT_S=0.47,HT_E=0.53;
  let eventIdx=0,htShown=false;
  let regStart=performance.now();
  let currentMinute=0;
  let giroPaused=false, giroUsedThisMatch=false, giroPausedFrac=0;

  function tickReg(now){
    if(giroPaused) return; // se reanuda manualmente desde resumeAfterGiro()
    const frac=Math.min((now-regStart)/REG_DURATION,1);
    if(frac>=HT_S&&frac<HT_E){
      if(!htShown){
        htShown=true;
        clockEl.textContent=`45+${inj1}'`;
        halfEl.textContent=t('match.halftime');
        halfEl.style.background='#a07a00';
        fillEl.style.width='50%';
        addSep(`${t('match.ht_sep')||'Descanso — 45+{0}\''.replace('{0}',inj1)}`||`Descanso — 45+${inj1}'`);
        playSound('whistle');
      }
      requestAnimationFrame(tickReg); return;
    }
    let minute;
    if(frac<HT_S){
      minute=Math.min(45+inj1,Math.floor(frac/HT_S*(45+inj1)));
      halfEl.textContent=t('match.first_half')||'1ª PARTE'; halfEl.style.background='var(--accent)';
      fillEl.style.width=`${(frac/HT_S)*50}%`;
      clockEl.textContent=minute>45?`45+${minute-45}'`:`${minute}'`;
    } else {
      const f2=(frac-HT_E)/(1-HT_E);
      minute=46+Math.floor(f2*(MAX_MIN-46));
      minute=Math.min(minute,MAX_MIN);
      halfEl.textContent=t('match.second_half')||'2ª PARTE'; halfEl.style.background='var(--accent)';
      fillEl.style.width=`${50+f2*50}%`;
      clockEl.textContent=minute>90?`90+${minute-90}'`:`${minute}'`;
    }
    currentMinute=minute;
    while(eventIdx<allEvents.length&&allEvents[eventIdx].minute<=minute){
      const ev=allEvents[eventIdx++];
      const label=ev.minute>90?`90+${ev.minute-90}'`:ev.minute>45&&ev.minute<=45+inj1?`45+${ev.minute-45}'`:`${ev.minute}'`;
      addEvt(ev.icon,ev.text,label,ev.type);
      if(ev.type==='mygoal'){ curMy++; scoreEl.textContent=`${curMy} – ${curOpp}`; flashScore(); playSound('goal'); }
      else if(ev.type==='oppgoal'){ curOpp++; scoreEl.textContent=`${curMy} – ${curOpp}`; flashScore(); playSound('goal'); }
    }
    if(frac<1){ requestAnimationFrame(tickReg); return; }
    // Fin reglamento
    clockEl.textContent=`90+${inj2}'`; fillEl.style.width='100%';
    halfEl.textContent=t('match.end')||'FIN'; halfEl.style.background='#555';
    playSound('whistle');
    if(penaltyInfo) setTimeout(startExtraTime,900);
    else {
      playSound(won||draw?'victory':'defeat');
      if(window._duelId){
      mpGiroDetachDuelListener();
      // Refrescar con el resultado final (puede haber cambiado por Giro Táctico)
      if(window._duelLastMatchStats) Object.assign(window._duelLastMatchStats, {myGoals, rivalGoals:oppGoals, won, draw});
      if(draw){ setTimeout(()=>{ mpMaybeStartPenalties(); }, 800); }
      else{ setTimeout(()=>{ mpAdvanceAfterMatch(); }, 800); }
    }
      else setTimeout(showPostMatch,800);
    }
  }
  requestAnimationFrame(tickReg);

  /* ════════════ GIRO TÁCTICO — lógica de pausa/elección/reanudación ════════════ */
  const giroBtn=document.getElementById('giroTacticoBtn');
  if(giroBtn){
    giroBtn.addEventListener('click', ()=>{
      if(giroPaused||giroUsedThisMatch||!(window._giroCharges>0)) return;
      pauseForGiro();
    });
  }

  function pauseForGiro(){
    giroPaused=true;
    giroPausedFrac=Math.min((performance.now()-regStart)/REG_DURATION,1);
    playSound('select');
    if(window._duelId && window._giroDuelCtx){
      const ctxD=window._giroDuelCtx;
      const db=window._fbDb;
      if(db&&ctxD.duelId){
        db.collection('duels').doc(ctxD.duelId).update({
          [`m${ctxD.matchIndex}_giroPause`]: {by:ctxD.myRole, pauseMinute:currentMinute, active:true, ts:Date.now()}
        }).catch(e=>console.error('[Giro Táctico Duelo] aviso de pausa falló:', e));
      }
    }
    try{
      showGiroCardPicker();
    }catch(e){
      console.error('Giro Táctico picker error:', e);
      resumeAfterGiro();
    }
  }

  /* ---- Sincronización del duelo: esperar/reanudar cuando el RIVAL usa
     Giro Táctico (yo no soy quien lo pulsa) ---- */
  let mpGiroListenerUnsub=null, mpGiroWaitingOverlay=null;
  function mpGiroAttachDuelListener(){
    if(!window._duelId || !window._giroDuelCtx) return;
    const ctxD=window._giroDuelCtx;
    const db=window._fbDb;
    if(!db||!ctxD.duelId) return;
    mpGiroListenerUnsub=db.collection('duels').doc(ctxD.duelId).onSnapshot(snap=>{
      const d=snap.data();
      if(!d) return;
      const pause=d[`m${ctxD.matchIndex}_giroPause`];
      console.log('[Giro Táctico Duelo] snapshot recibido, pendingWrites:', snap.metadata.hasPendingWrites, 'pause:', pause, 'esperando:', !!mpGiroWaitingOverlay);
      if(pause && pause.active && pause.by!==ctxD.myRole && !giroPaused){
        // El rival ha pulsado Giro Táctico — pausar aquí también y esperar
        giroPaused=true;
        giroPausedFrac=Math.min((performance.now()-regStart)/REG_DURATION,1);
        mpGiroShowWaitingOverlay(pause.ts);
      }else if((!pause||!pause.active) && mpGiroWaitingOverlay){
        // El rival ya ha resuelto su Giro Táctico — adoptar el resultado
        // actualizado y reanudar, sin recalcular nada por mi cuenta.
        console.log('[Giro Táctico Duelo] reanudando por el listener en tiempo real (camino normal)');
        mpGiroHideWaitingOverlay();
        try{ mpGiroAdoptUpdatedResult(d); }
        catch(e){ console.error('[Giro Táctico Duelo] resincronización falló:', e); }
        resumeAfterGiro();
      }
    }, e=>console.error('[Giro Táctico Duelo] listener falló:', e));
  }
  function mpGiroDetachDuelListener(){
    if(mpGiroListenerUnsub){ mpGiroListenerUnsub(); mpGiroListenerUnsub=null; }
    if(mpGiroWaitTimerHandle){ clearInterval(mpGiroWaitTimerHandle); mpGiroWaitTimerHandle=null; }
    if(mpGiroSafetyTimeout){ clearInterval(mpGiroSafetyTimeout); mpGiroSafetyTimeout=null; }
  }
  let mpGiroWaitTimerHandle=null, mpGiroSafetyTimeout=null;
  function mpGiroShowWaitingOverlay(pauseTs){
    const ctxD=window._giroDuelCtx;
    const ov=document.createElement('div');
    ov.id='giroWaitOverlay';
    ov.style.cssText='position:fixed;inset:0;background:rgba(10,10,10,.97);z-index:95000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:20px;text-align:center';
    ov.innerHTML=`
      <i class="ph ph-bold ph-hourglass-medium" style="font-size:30px;color:#7b9cff"></i>
      <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:15px;color:var(--gold);letter-spacing:.5px">
        Espera mientras el rival ${mpEsc(ctxD?ctxD.opponentUsername:'')} da instrucciones a su equipo
      </div>
      <div style="width:80%;max-width:240px;height:4px;background:#222;border-radius:3px;overflow:hidden">
        <div id="giroWaitFill" style="height:100%;width:100%;background:#7b9cff;transition:width .1s linear"></div>
      </div>
      <div id="giroWaitSub" style="font-size:10px;color:var(--text-muted)"></div>`;
    document.body.appendChild(ov);
    mpGiroWaitingOverlay=ov;

    // Barra sincronizada con el mismo margen de 10s que tiene el rival
    // para elegir — si el rival ya eligió antes, se para sola al cerrarse
    // este overlay (lo hace el propio listener).
    const GIRO_TOTAL_MS=10000;
    const startTs=pauseTs||Date.now();
    const fill=document.getElementById('giroWaitFill');
    const sub=document.getElementById('giroWaitSub');
    if(mpGiroWaitTimerHandle) clearInterval(mpGiroWaitTimerHandle);
    mpGiroWaitTimerHandle=setInterval(()=>{
      const remainMs=Math.max(0, GIRO_TOTAL_MS-(Date.now()-startTs));
      if(fill) fill.style.width=(remainMs/GIRO_TOTAL_MS*100)+'%';
      if(sub) sub.textContent=remainMs>0?`${Math.ceil(remainMs/1000)}s`:'';
      if(remainMs<=0){ clearInterval(mpGiroWaitTimerHandle); mpGiroWaitTimerHandle=null; }
    },100);

    // Red de seguridad: comprobación activa cada 1.5s (no solo esperar al
    // aviso en tiempo real) — si por lo que sea la señal de "el rival ya
    // ha terminado" no llega, esto lo detecta mucho antes que un único
    // plazo largo, sin dejar nunca al jugador esperando de más.
    if(mpGiroSafetyTimeout) clearInterval(mpGiroSafetyTimeout);
    let giroSafetyChecks=0;
    mpGiroSafetyTimeout=setInterval(async()=>{
      giroSafetyChecks++;
      if(!mpGiroWaitingOverlay){ clearInterval(mpGiroSafetyTimeout); mpGiroSafetyTimeout=null; return; }
      const ctxD2=window._giroDuelCtx;
      const db=window._fbDb;
      try{
        if(db&&ctxD2&&ctxD2.duelId){
          const snap=await db.collection('duels').doc(ctxD2.duelId).get();
          const freshDoc=snap.exists?snap.data():null;
          const freshPause=freshDoc?freshDoc[`m${ctxD2.matchIndex}_giroPause`]:null;
          if(freshDoc && (!freshPause||!freshPause.active) && mpGiroWaitingOverlay){
            console.log('[Giro Táctico Duelo] reanudando por la comprobación de refuerzo (el listener en tiempo real no llegó a tiempo)');
            clearInterval(mpGiroSafetyTimeout); mpGiroSafetyTimeout=null;
            mpGiroAdoptUpdatedResult(freshDoc);
            mpGiroHideWaitingOverlay();
            resumeAfterGiro();
            return;
          }
        }
      }catch(e){ console.error('[Giro Táctico Duelo] comprobación de seguridad falló:', e); }
      // Tope de seguridad final por si algo se queda atascado de verdad
      if(giroSafetyChecks>=24 && mpGiroWaitingOverlay){
        clearInterval(mpGiroSafetyTimeout); mpGiroSafetyTimeout=null;
        mpGiroHideWaitingOverlay();
        resumeAfterGiro();
      }
    }, 500);
  }
  function mpGiroHideWaitingOverlay(){
    if(mpGiroWaitTimerHandle){ clearInterval(mpGiroWaitTimerHandle); mpGiroWaitTimerHandle=null; }
    if(mpGiroSafetyTimeout){ clearInterval(mpGiroSafetyTimeout); mpGiroSafetyTimeout=null; }
    if(mpGiroWaitingOverlay){ mpGiroWaitingOverlay.remove(); mpGiroWaitingOverlay=null; }
  }
  /* Adopta sin recalcular el resultado ya corregido por quien usó Giro
     Táctico — mismo mecanismo que ya usan los duelos para sincronizarse. */
  function mpGiroAdoptUpdatedResult(freshDoc){
    const ctxD=window._giroDuelCtx;
    if(!ctxD) return;
    const idx=ctxD.matchIndex;
    const freshResult=freshDoc[`m${idx}_result`];
    if(!freshResult) return;
    ctxD.result=freshResult;
    const myGoalEventsField=ctxD.myRole==='challenger'?'challengerGoalEvents':'opponentGoalEvents';
    const rivalGoalEventsField=ctxD.myRole==='challenger'?'opponentGoalEvents':'challengerGoalEvents';
    const myEvents=freshResult[myGoalEventsField]||[];
    const rivalEvents=freshResult[rivalGoalEventsField]||[];
    myGoals=ctxD.myRole==='challenger'?freshResult.challengerGoals:freshResult.opponentGoals;
    oppGoals=ctxD.myRole==='challenger'?freshResult.opponentGoals:freshResult.challengerGoals;
    won=myGoals>oppGoals; draw=myGoals===oppGoals;
    // Conservar lo ya mostrado (mismo instante de pausa para los dos, ya
    // que se guarda el minuto exacto de quien pulsó el botón) y añadir
    // los eventos futuros ya recalculados por el rival.
    allEvents.length=eventIdx; // truncar SIN reasignar (allEvents es const)
    myEvents.filter(ev=>ev.minute>currentMinute).forEach(ev=>{
      allEvents.push({minute:ev.minute, type:'mygoal', icon:'⚽', text:`<strong>${ev.name||'Gol'}</strong>`});
    });
    rivalEvents.filter(ev=>ev.minute>currentMinute).forEach(ev=>{
      allEvents.push({minute:ev.minute, type:'oppgoal', icon:'⚽', text:`<strong>${ev.name||'Gol'}</strong>`});
    });
    allEvents.sort((a,b)=>a.minute-b.minute);
  }
  if(window._duelId) mpGiroAttachDuelListener();

  function ensureGiroCardStyles(){
    if(document.getElementById('giroCardStylesTag')) return;
    const style=document.createElement('style');
    style.id='giroCardStylesTag';
    style.textContent=`
      #giroPickerPanel .g-card{
        position:absolute;top:50%;left:50%;width:96px;height:150px;margin:-75px 0 0 -48px;
        cursor:pointer;-webkit-tap-highlight-color:transparent;will-change:transform;z-index:2;
      }
      #giroPickerPanel .g-card.focused{ z-index:30; }
      #giroPickerPanel .g-card.dimmed .g-card-face{ filter:brightness(.55) saturate(.6); }
      #giroPickerPanel .g-card-face{
        width:100%;height:100%;border-radius:12px;
        background:radial-gradient(120% 100% at 50% -10%, rgba(232,185,35,.10), transparent 55%),
                   linear-gradient(160deg,#1c1c1c,#161616);
        border:1px solid #2a2a2a;
        box-shadow:0 8px 20px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.03);
        display:flex;flex-direction:column;align-items:center;padding:9px 7px 7px;
        position:relative;overflow:hidden;transition:box-shadow .25s ease,filter .25s ease;
      }
      #giroPickerPanel .g-card-face::before{
        content:"";position:absolute;inset:5px;border:1px solid rgba(232,185,35,.35);
        border-radius:8px;pointer-events:none;
      }
      #giroPickerPanel .g-card.focused .g-card-face{ box-shadow:0 14px 30px rgba(0,0,0,.6), 0 0 0 2px var(--gold); }
      #giroPickerPanel .g-card-tag{
        font-family:'Bebas Neue',Impact,sans-serif;font-size:7.5px;letter-spacing:1.5px;
        color:#7a621a;margin-bottom:5px;text-transform:uppercase;
      }
      #giroPickerPanel .g-card-icon{ font-size:20px;color:var(--gold);margin-bottom:5px;
        filter:drop-shadow(0 0 6px rgba(232,185,35,.3)); }
      #giroPickerPanel .g-card-title{
        font-family:'Bebas Neue',Impact,sans-serif;font-size:10px;letter-spacing:.4px;
        color:#fff;text-align:center;margin-bottom:5px;line-height:1.15;
      }
      #giroPickerPanel .g-card-divider{ width:22px;height:2px;background:#7a621a;margin-bottom:5px;border-radius:2px; }
      #giroPickerPanel .g-effect{ width:100%;font-size:8.5px;line-height:1.25;text-align:center;padding:0 1px; }
      #giroPickerPanel .g-effect-pos{ color:#bfe8c9;margin-bottom:5px; }
      #giroPickerPanel .g-effect-pos b{ color:var(--accent);font-weight:700; }
      #giroPickerPanel .g-effect-neg{ color:#f3c6c1;padding-top:5px;border-top:1px dashed #333;margin-top:auto; }
      #giroPickerPanel .g-effect-neg b{ color:var(--red);font-weight:700; }
      @keyframes giroPulse{ 0%{transform:scale(1)} 35%{transform:scale(1.09)} 60%{transform:scale(.97)} 100%{transform:scale(1.03)} }
      #giroPickerPanel .g-card.confirmed .g-card-face{ animation:giroPulse .45s ease; transform-origin:center; }
      @keyframes giroVanish{ to{ opacity:0; transform:scale(.85); } }
      #giroStage.vanishing .g-card{ animation:giroVanish .5s ease forwards; }
      #giroStage.vanishing .g-card:nth-child(1){ animation-delay:0s; }
      #giroStage.vanishing .g-card:nth-child(2){ animation-delay:.08s; }
      #giroStage.vanishing .g-card:nth-child(3){ animation-delay:.16s; }
    `;
    document.head.appendChild(style);
  }

  function showGiroCardPicker(){
    ensureGiroCardStyles();
    const pool=GIRO_CARDS.slice();
    shuffle(pool);
    const picks=pool.slice(0,3);

    // Overlay a pantalla completa (no confinado al ancho máximo de la
    // ventana del partido), para que las cartas puedan verse grandes
    // también en móvil, ocupando el ancho real de la pantalla.
    const panel=document.createElement('div');
    panel.id='giroPickerPanel';
    panel.style.cssText='position:fixed;inset:0;background:rgba(10,10,10,.97);z-index:95000;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:14px;gap:8px;overflow:hidden';
    panel.innerHTML=`
      <div style="font-family:'Bebas Neue',Impact,sans-serif;color:var(--gold);letter-spacing:1.2px;font-size:14px">GIRO TÁCTICO — MIN ${currentMinute}'</div>
      <div style="width:80%;max-width:280px;height:4px;background:#222;border-radius:3px;overflow:hidden">
        <div id="giroTimerFill" style="height:100%;width:100%;background:var(--gold);transition:width .1s linear"></div>
      </div>
      <div id="giroSub" style="font-size:11px;color:var(--text-muted);min-height:14px">Barajando...</div>
      <div id="giroStageWrap" style="position:relative;width:100%;flex:1;display:flex;align-items:center;justify-content:center;min-height:0"></div>
    `;
    document.body.appendChild(panel);

    const stageWrap=panel.querySelector('#giroStageWrap');
    const stage=document.createElement('div');
    stage.id='giroStage';
    // Diseño base a 300px; se escala hasta ocupar casi todo el ancho
    // real de la pantalla en móvil (mismo truco que en el diseño original).
    const baseW=300;
    const availW=Math.min(window.innerWidth*0.92, 480);
    const stageScale=Math.max(1, availW/baseW);
    stage.style.cssText=`position:relative;width:${baseW}px;height:160px;flex:none;transform:scale(${stageScale});transform-origin:center center`;
    stageWrap.appendChild(stage);
    const sub=panel.querySelector('#giroSub');
    const keys=['a','b','c'];
    const REST={a:{x:-78,rot:-4},b:{x:0,rot:0},c:{x:78,rot:4}};
    // Rutas de cruce del barajado — mismas proporciones que el diseño original
    const PATHS={
      a:[{x:0,y:0,rot:0,s:.94},{x:30,y:-8,rot:12,s:.97},{x:-25,y:4,rot:-10,s:.97},
         {x:50,y:-6,rot:14,s:.98},{x:-36,y:3,rot:-8,s:.98},{x:21,y:-4,rot:6,s:.98},
         {x:-88,y:-6,rot:-6,s:1.03},{x:REST.a.x,y:0,rot:REST.a.rot,s:1}],
      b:[{x:0,y:0,rot:0,s:.94},{x:-29,y:5,rot:-11,s:.96},{x:23,y:-6,rot:9,s:.97},
         {x:-45,y:2,rot:-13,s:.98},{x:34,y:-4,rot:8,s:.98},{x:-20,y:4,rot:-6,s:.98},
         {x:5,y:-6,rot:2,s:1.03},{x:REST.b.x,y:0,rot:REST.b.rot,s:1}],
      c:[{x:0,y:0,rot:0,s:.94},{x:-30,y:-6,rot:-12,s:.97},{x:25,y:4,rot:10,s:.97},
         {x:-50,y:-5,rot:-14,s:.98},{x:36,y:3,rot:8,s:.98},{x:-21,y:-3,rot:-6,s:.98},
         {x:88,y:-6,rot:6,s:1.03},{x:REST.c.x,y:0,rot:REST.c.rot,s:1}]
    };
    const STEP_MS=90;

    function setT(el,x,y,rot,s){ el.style.transform=`translate(${x}px,${y}px) rotate(${rot}deg) scale(${s})`; }

    const cardEls=[];
    picks.forEach((card,i)=>{
      const key=keys[i];
      const el=document.createElement('div');
      el.className='g-card';
      el.dataset.key=key;
      el.innerHTML=`
        <div class="g-card-face">
          <div class="g-card-tag">Giro Táctico</div>
          <i class="ph ph-bold ${card.icon} g-card-icon"></i>
          <div class="g-card-title">${card.name}</div>
          <div class="g-card-divider"></div>
          <div class="g-effect g-effect-pos"><b>${card.pos}</b></div>
          <div class="g-effect g-effect-neg"><b>${card.neg}</b></div>
        </div>`;
      el.style.transition=`transform ${STEP_MS}ms cubic-bezier(.4,0,.2,1)`;
      stage.appendChild(el);
      cardEls.push({el,card,key});
    });

    let ready=false, focusedKey=null, resolved=false, hoveredKey=null, idleActive=false;
    const hoverState={a:{s:1,l:0},b:{s:1,l:0},c:{s:1,l:0}};
    const idlePhase={a:0,b:2.1,c:4.2};

    function idleTick(t){
      if(!idleActive) return;
      cardEls.forEach(({el,key})=>{
        if(focusedKey!==null) return;
        const r=REST[key];
        const bob=Math.sin(t/650+idlePhase[key])*5;
        const hs=hoverState[key];
        const targetS=(hoveredKey===key)?1.08:1;
        hs.s+=(targetS-hs.s)*0.2;
        const hoverLift=(hoveredKey===key)?-5:0;
        setT(el, r.x, bob+hoverLift, r.rot, hs.s);
      });
      requestAnimationFrame(idleTick);
    }
    function startIdle(){ idleActive=true; cardEls.forEach(({el})=>el.style.transition='none'); requestAnimationFrame(idleTick); }

    function runShuffle(){
      let i=0;
      const maxSteps=PATHS.a.length;
      const iv=setInterval(()=>{
        playSound('spin');
        cardEls.forEach(({el,key})=>{
          const p=PATHS[key][Math.min(i,PATHS[key].length-1)];
          setT(el,p.x,p.y,p.rot,p.s);
        });
        i++;
        if(i>=maxSteps){
          clearInterval(iv);
          cardEls.forEach(({el,key})=>{
            el.style.transition='transform .3s cubic-bezier(.34,1.56,.64,1)';
            setT(el,REST[key].x,0,REST[key].rot,1);
          });
          setTimeout(()=>{ ready=true; if(sub) sub.textContent='Toca una carta para verla — vuelve a tocarla para elegirla'; startIdle(); },260);
        }
      },STEP_MS);
    }
    setTimeout(runShuffle,150);

    function focusCard(key){
      idleActive=false;
      focusedKey=key;
      const others=keys.filter(k=>k!==key);
      cardEls.forEach(({el,key:k})=>{
        el.style.transition='transform .32s cubic-bezier(.34,1.56,.64,1)';
        if(k===key){ el.classList.add('focused'); el.classList.remove('dimmed'); setT(el,0,-3,0,1.16); }
        else{
          el.classList.remove('focused'); el.classList.add('dimmed');
          const peekX=(others.indexOf(k)===0)?-52:52;
          setT(el,peekX,10,REST[k].rot,.8);
        }
      });
      if(sub) sub.textContent='Vuelve a tocarla para elegir esta carta';
    }
    function unfocusAll(){
      focusedKey=null;
      cardEls.forEach(({el})=>el.classList.remove('focused','dimmed'));
      cardEls.forEach(({el,key})=>{
        el.style.transition='transform .3s cubic-bezier(.34,1.56,.64,1)';
        setT(el,REST[key].x,0,REST[key].rot,1);
      });
      if(sub) sub.textContent='Toca una carta para verla — vuelve a tocarla para elegirla';
      setTimeout(()=>{ if(focusedKey===null) startIdle(); },320);
    }

    cardEls.forEach(({el,key})=>{
      el.addEventListener('mouseenter', ()=>{ hoveredKey=key; });
      el.addEventListener('mouseleave', ()=>{ if(hoveredKey===key) hoveredKey=null; });
      el.addEventListener('click',(e)=>{
        e.stopPropagation();
        if(!ready||resolved) return;
        if(focusedKey===key){ doResolve(cardEls.find(c=>c.key===key)); return; }
        focusCard(key);
      });
    });
    panel.addEventListener('click',()=>{
      if(!ready||resolved||focusedKey===null) return;
      unfocusAll();
    });

    const GIRO_TOTAL_MS=10000;
    const giroStart=performance.now();
    const fill=panel.querySelector('#giroTimerFill');
    let lastBeepSec=null;
    const timerHandle=setInterval(()=>{
      const remainMs=Math.max(0, GIRO_TOTAL_MS-(performance.now()-giroStart));
      const remainSec=Math.ceil(remainMs/1000);
      if(remainSec!==lastBeepSec){ lastBeepSec=remainSec; checkCountdownBeep(remainSec,'giroTactico'); }
      if(fill) fill.style.width=(remainMs/GIRO_TOTAL_MS*100)+'%';
      if(remainMs<=0){
        clearInterval(timerHandle);
        handleGiroTimeout();
      }
    },100);

    function doResolve(entry){
      if(resolved||!entry) return;
      resolved=true;
      idleActive=false;
      clearInterval(timerHandle);
      playSound('select');
      entry.el.classList.add('confirmed');
      if(sub) sub.textContent='¡Elegida! Aplicando efecto...';
      setTimeout(()=>{ stage.classList.add('vanishing'); }, 250);
      setTimeout(()=>{ resolveGiroPick(entry.card, panel); }, 750);
    }

    // Si se agota el tiempo sin confirmar ninguna carta (aunque hubiera
    // una enfocada), no se aplica ningún efecto — pero el uso SÍ se
    // consume, como penalización por no decidir a tiempo.
    function handleGiroTimeout(){
      if(resolved) return;
      resolved=true;
      idleActive=false;
      if(sub) sub.textContent='Tiempo agotado — no se eligió ninguna carta';
      setTimeout(()=>{ stage.classList.add('vanishing'); }, 400);
      setTimeout(()=>{
        if(panel) panel.remove();
        try{ consumeGiroChargeNoEffect(); }
        catch(e){ console.error('[Giro Táctico] consumo por tiempo agotado falló:', e); }
        finally{ resumeAfterGiro(); }
      }, 900);
    }
  }

  // Consume 1 uso de Giro Táctico sin aplicar ningún efecto — se llama
  // cuando el jugador deja pasar el tiempo sin elegir carta.
  function consumeGiroChargeNoEffect(){
    giroUsedThisMatch=true;
    window._giroCharges=Math.max(0,(window._giroCharges||1)-1);
    const btn=document.getElementById('giroTacticoBtn');
    if(btn){
      btn.disabled=true; btn.style.opacity='.4'; btn.style.cursor='not-allowed'; btn.style.borderColor='#555'; btn.style.color='#777';
      btn.innerHTML=`<i class="ph ph-bold ph-notebook" style="font-size:15px"></i> GIRO TÁCTICO ${window._giroCharges||0}/${getMaxGiroCharges()}`;
    }
    // No se registra window._giroCardUsed — no hubo carta elegida, así
    // que el resumen final no debe mostrar ningún efecto aplicado.
    if(window._duelId && window._giroDuelCtx){
      const ctxD=window._giroDuelCtx;
      const db=window._fbDb;
      if(db&&ctxD.duelId){
        const roleField=ctxD.myRole==='challenger'?'giroChallenger':'giroOpponent';
        db.collection('duels').doc(ctxD.duelId).update({
          [`m${ctxD.matchIndex}_giroPause`]: {active:false},
          [`m${ctxD.matchIndex}_${roleField}`]: {minute:currentMinute, noPick:true}
        }).catch(e=>console.error('[Giro Táctico Duelo] aviso de "no elegido" falló:', e));
      }
    }
  }

  function resolveGiroPick(card, panel){
    // Pase lo que pase al aplicar la carta, el partido SIEMPRE debe
    // reanudarse — nunca debe quedarse congelado.
    try{
      if(panel) panel.remove();
      if(window._duelId) applyGiroCardDuel(card);
      else applyGiroCard(card);
    }catch(e){
      console.error('Giro Táctico error:', e);
      if(typeof showToast==='function') showToast('⚠ Giro Táctico: parte del efecto no se pudo aplicar', 'toast-neg');
    }finally{
      resumeAfterGiro();
    }
  }

  /* Versión para duelo — calcula el tramo restante usando las plantillas
     reales de ambos jugadores y escribe el resultado corregido para que
     el rival lo adopte sin tener que recalcular nada. */
  function applyGiroCardDuel(card){
    const ctxD=window._giroDuelCtx;
    if(!ctxD){ console.error('[Giro Táctico Duelo] sin contexto'); return; }
    giroUsedThisMatch=true;
    window._giroCharges=Math.max(0,(window._giroCharges||1)-1);
    window._giroCardUsed={name:card.name, pos:card.pos, neg:card.neg, icon:card.icon};
    const btn=document.getElementById('giroTacticoBtn');
    if(btn){
      btn.disabled=true; btn.style.opacity='.4'; btn.style.cursor='not-allowed'; btn.style.borderColor='#555'; btn.style.color='#777';
      btn.innerHTML=`<i class="ph ph-bold ph-notebook" style="font-size:15px"></i> GIRO TÁCTICO ${window._giroCharges||0}/${getMaxGiroCharges()}`;
    }

    let ctx={myLambda:1.15, oppLambda:1.15, fatigue:0, morale:0, cardRiskDelta:0, injuryRiskDelta:0, starBoost:0};
    let starPlayer=null;
    try{
      const result=ctxD.result||{};
      const remFrac=Math.max(0.03,(90-currentMinute)/90);
      const myBaseLambda=(ctxD.myRole==='challenger'?result.challengerBaseLambda:result.opponentBaseLambda)||1.15;
      const rivalBaseLambda=(ctxD.myRole==='challenger'?result.opponentBaseLambda:result.challengerBaseLambda)||1.15;
      ctx={myLambda:myBaseLambda*remFrac, oppLambda:rivalBaseLambda*remFrac, fatigue:0, morale:0, cardRiskDelta:0, injuryRiskDelta:0, starBoost:0};
      card.apply(ctx);
      ctx.myLambda=Math.max(0.05,ctx.myLambda);
      ctx.oppLambda=Math.max(0.05,ctx.oppLambda);
      if(ctx.fatigue){
        usedPlayers.forEach(p=>{ p.fatigue=Math.max(0,Math.min(100,(p.fatigue===undefined?100:p.fatigue)+ctx.fatigue)); });
      }
      if(ctx.morale){ teamMorale=Math.max(-50,Math.min(50,teamMorale+ctx.morale)); }
      if(ctx.starBoost){
        starPlayer=usedPlayers.slice().sort((a,b)=>(b.rating||0)-(a.rating||0))[0];
        if(starPlayer){ starPlayer.rating=(starPlayer.rating||70)+ctx.starBoost; ctx.myLambda+=(ctx.starBoost/100)*0.35; }
      }
      ctx.myLambda=Math.max(0.05,ctx.myLambda);
    }catch(e){
      console.error('[Giro Táctico Duelo] Bloque 1 (efecto) falló:', e);
    }

    let pendingCardEvent=null, pendingInjuryEvent=null;
    try{
      if(ctx.cardRiskDelta){
        const baseCardChance=0.08;
        const cardChance=Math.max(0,Math.min(0.9,baseCardChance+ctx.cardRiskDelta));
        if(Math.random()<cardChance && usedPlayers.length){
          const target=usedPlayers[Math.floor(Math.random()*usedPlayers.length)];
          const isRed=Math.random()<(RED_RISK_PER_PLAYER/(RED_RISK_PER_PLAYER+YELLOW_RISK_PER_PLAYER));
          const cardMin=Math.min(90,currentMinute+1+Math.floor(Math.random()*Math.max(1,90-currentMinute)));
          pendingCardEvent={minute:cardMin, type:'card', icon:isRed?'🟥':'🟨', text:`<strong>${target.name}</strong>`};
        }
      }
      if(ctx.injuryRiskDelta && Math.random()<ctx.injuryRiskDelta){
        const target=starPlayer||(usedPlayers.length?usedPlayers[Math.floor(Math.random()*usedPlayers.length)]:null);
        if(target && !target.injury){
          const r=Math.random();
          const type=r<0.6?'leve':r<0.9?'básica':'grave';
          target.injury={remaining:type==='leve'?1:type==='básica'?2:3, type};
          target.forcedInjured=true;
          const injMin=Math.min(90,currentMinute+1+Math.floor(Math.random()*Math.max(1,90-currentMinute)));
          pendingInjuryEvent={minute:injMin, type:'injury', icon:'✚', text:`<strong>${target.name}</strong>`};
        }
      }
    }catch(e){
      console.error('[Giro Táctico Duelo] Bloque 2 (riesgo tarjeta/lesión) falló:', e);
    }

    try{
      const extraMy=poissonSample(ctx.myLambda);
      const extraRival=poissonSample(ctx.oppLambda);

      const myPoolRaw=(ctxD.mySquad.pitch||[]).filter(p=>p.placedPos&&["DC","EI","ED","MC"].includes(p.placedPos));
      const rivalPoolRaw=(ctxD.rivalSquad.pitch||[]).filter(p=>p.placedPos&&["DC","EI","ED","MC"].includes(p.placedPos));
      const myPool=myPoolRaw.length?myPoolRaw:(ctxD.mySquad.pitch||[]);
      const rivalPool=rivalPoolRaw.length?rivalPoolRaw:(ctxD.rivalSquad.pitch||[]);

      const newMyMin=[]; for(let i=0;i<extraMy;i++) newMyMin.push(Math.min(90,currentMinute+1+Math.floor(Math.random()*Math.max(1,90-currentMinute))));
      const newRivalMin=[]; for(let i=0;i<extraRival;i++) newRivalMin.push(Math.min(90,currentMinute+1+Math.floor(Math.random()*Math.max(1,90-currentMinute))));
      newMyMin.sort((a,b)=>a-b); newRivalMin.sort((a,b)=>a-b);
      const newMyEvents=newMyMin.map(min=>({name:myPool.length?myPool[Math.floor(Math.random()*myPool.length)].name:null, minute:min}));
      const newRivalEvents=newRivalMin.map(min=>({name:rivalPool.length?rivalPool[Math.floor(Math.random()*rivalPool.length)].name:null, minute:min}));

      const result=ctxD.result||{};
      const myGoalEventsField=ctxD.myRole==='challenger'?'challengerGoalEvents':'opponentGoalEvents';
      const rivalGoalEventsField=ctxD.myRole==='challenger'?'opponentGoalEvents':'challengerGoalEvents';
      const pastMyEvents=(result[myGoalEventsField]||[]).filter(ev=>ev.minute<=currentMinute);
      const pastRivalEvents=(result[rivalGoalEventsField]||[]).filter(ev=>ev.minute<=currentMinute);
      const updatedMyEvents=[...pastMyEvents, ...newMyEvents];
      const updatedRivalEvents=[...pastRivalEvents, ...newRivalEvents];
      const newMyTotal=pastMyEvents.length+extraMy;
      const newRivalTotal=pastRivalEvents.length+extraRival;

      myGoals=newMyTotal;
      oppGoals=newRivalTotal;
      won=myGoals>oppGoals; draw=myGoals===oppGoals;

      allEvents.length=eventIdx; // truncar SIN reasignar (allEvents es const)
      if(pendingCardEvent) allEvents.push(pendingCardEvent);
      if(pendingInjuryEvent) allEvents.push(pendingInjuryEvent);
      newMyEvents.forEach(ev=>allEvents.push({minute:ev.minute, type:'mygoal', icon:'⚽', text:`<strong>${ev.name||'Gol'}</strong>`}));
      newRivalEvents.forEach(ev=>allEvents.push({minute:ev.minute, type:'oppgoal', icon:'⚽', text:`<strong>${ev.name||'Gol'}</strong>`}));
      allEvents.sort((a,b)=>a.minute-b.minute);

      const updatedResult=Object.assign({}, result, {
        [myGoalEventsField]: updatedMyEvents,
        [rivalGoalEventsField]: updatedRivalEvents,
        [ctxD.myRole==='challenger'?'challengerGoals':'opponentGoals']: newMyTotal,
        [ctxD.myRole==='challenger'?'opponentGoals':'challengerGoals']: newRivalTotal,
      });
      ctxD.result=updatedResult;

      const db=window._fbDb;
      if(db&&ctxD.duelId){
        const roleField=ctxD.myRole==='challenger'?'giroChallenger':'giroOpponent';
        db.collection('duels').doc(ctxD.duelId).update({
          [`m${ctxD.matchIndex}_result`]: updatedResult,
          [`m${ctxD.matchIndex}_giroPause`]: {active:false},
          [`m${ctxD.matchIndex}_${roleField}`]: {cardName:card.name, pos:card.pos, neg:card.neg, minute:currentMinute, icon:card.icon}
        }).catch(e=>console.error('[Giro Táctico Duelo] guardado del resultado corregido falló:', e));
      }
    }catch(e){
      console.error('[Giro Táctico Duelo] Bloque 3 (resimular goles) falló:', e);
    }
  }

  function applyGiroCard(card){
    giroUsedThisMatch=true;
    window._giroCharges=Math.max(0,(window._giroCharges||1)-1);
    // Registrar la carta usada YA, antes de cualquier cálculo — así el
    // resumen final siempre la muestra, pase lo que pase después.
    window._giroCardUsed={name:card.name, pos:card.pos, neg:card.neg, icon:card.icon};
    const btn=document.getElementById('giroTacticoBtn');
    if(btn){
      btn.disabled=true; btn.style.opacity='.4'; btn.style.cursor='not-allowed'; btn.style.borderColor='#555'; btn.style.color='#777';
      btn.innerHTML=`<i class="ph ph-bold ph-notebook" style="font-size:15px"></i> GIRO TÁCTICO ${window._giroCharges||0}/${getMaxGiroCharges()}`;
    }

    const oldMyGoals=myGoals, oldOppGoals=oppGoals, oldWon=won, oldDraw=draw;

    // ── Bloque 1: calcular el contexto del efecto (lambdas, fatiga, moral...) ──
    let ctx={ myLambda:1.15, oppLambda:1.15, fatigue:0, morale:0, cardRiskDelta:0, injuryRiskDelta:0, starBoost:0 };
    let starPlayer=null;
    try{
      const remFrac=Math.max(0.03,(90-currentMinute)/90);
      const baseCtx=window._giroLambdaCtx||{myLambda:1.15,oppLambda:1.15};
      ctx={ myLambda:baseCtx.myLambda*remFrac, oppLambda:baseCtx.oppLambda*remFrac,
        fatigue:0, morale:0, cardRiskDelta:0, injuryRiskDelta:0, starBoost:0 };
      card.apply(ctx);
      ctx.myLambda=Math.max(0.05,ctx.myLambda);
      ctx.oppLambda=Math.max(0.05,ctx.oppLambda);

      if(ctx.fatigue){
        usedPlayers.forEach(p=>{ p.fatigue=Math.max(0,Math.min(100,(p.fatigue===undefined?100:p.fatigue)+ctx.fatigue)); });
      }
      if(ctx.morale){ teamMorale=Math.max(-50,Math.min(50,teamMorale+ctx.morale)); }
      if(ctx.starBoost){
        starPlayer=usedPlayers.slice().sort((a,b)=>(b.rating||0)-(a.rating||0))[0];
        if(starPlayer){
          starPlayer.rating=(starPlayer.rating||70)+ctx.starBoost;
          ctx.myLambda+=(ctx.starBoost/100)*0.35;
        }
      }
      ctx.myLambda=Math.max(0.05,ctx.myLambda);
    }catch(e){
      console.error('[Giro Táctico] Bloque 1 (efecto/fatiga/moral) falló:', e);
    }

    // ── Bloque 2: riesgo extra de tarjeta/lesión en lo que resta ──
    let pendingCardEvent=null, pendingInjuryEvent=null;
    try{
      if(ctx.cardRiskDelta){
        const baseCardChance=0.08;
        const cardChance=Math.max(0,Math.min(0.9,baseCardChance+ctx.cardRiskDelta));
        if(Math.random()<cardChance && usedPlayers.length){
          const target=usedPlayers[Math.floor(Math.random()*usedPlayers.length)];
          const isRed=Math.random()<(RED_RISK_PER_PLAYER/(RED_RISK_PER_PLAYER+YELLOW_RISK_PER_PLAYER));
          const cardMin=Math.min(MAX_MIN,currentMinute+1+Math.floor(Math.random()*Math.max(1,MAX_MIN-currentMinute)));
          pendingCardEvent={minute:cardMin, type:'card', icon:isRed?'🟥':'🟨', text:`<strong>${target.name}</strong>`};
          if(newCards) newCards.push({player:{name:target.name}, type:isRed?'red':'yellow'});
        }
      }
      if(ctx.injuryRiskDelta && Math.random()<ctx.injuryRiskDelta){
        const target=starPlayer||(usedPlayers.length?usedPlayers[Math.floor(Math.random()*usedPlayers.length)]:null);
        if(target && !target.injury){
          const r=Math.random();
          const type=r<0.6?'leve':r<0.9?'básica':'grave';
          const remaining=type==='leve'?1:type==='básica'?2:3;
          target.injury={remaining,type};
          target.forcedInjured=true;
          const injMin=Math.min(MAX_MIN,currentMinute+1+Math.floor(Math.random()*Math.max(1,MAX_MIN-currentMinute)));
          pendingInjuryEvent={minute:injMin, type:'injury', icon:'✚', text:`<strong>${target.name}</strong>`};
          if(newInjuries) newInjuries.push({name:target.name, injury:target.injury});
        }
      }
    }catch(e){
      console.error('[Giro Táctico] Bloque 2 (riesgo tarjeta/lesión) falló:', e);
    }

    // ── Bloque 3: resimular los goles restantes y actualizar el marcador ──
    try{
      const extraMy=poissonSample(ctx.myLambda);
      const extraOpp=poissonSample(ctx.oppLambda);

      const myPool=usedPlayers.filter(p=>p.placedPos&&["DC","EI","ED","MC"].includes(p.placedPos));
      const oppPool=nextOpponent?nextOpponent.players:[];
      const newMinutes=[];
      for(let i=0;i<extraMy;i++) newMinutes.push({side:'my', minute:Math.min(MAX_MIN,currentMinute+1+Math.floor(Math.random()*Math.max(1,MAX_MIN-currentMinute)))});
      for(let i=0;i<extraOpp;i++) newMinutes.push({side:'opp', minute:Math.min(MAX_MIN,currentMinute+1+Math.floor(Math.random()*Math.max(1,MAX_MIN-currentMinute)))});
      newMinutes.sort((a,b)=>a.minute-b.minute);

      // Descartar eventos futuros aún no mostrados; conservar lo ya ocurrido
      allEvents.length=eventIdx; // truncar SIN reasignar (allEvents es const)
      if(pendingCardEvent) allEvents.push(pendingCardEvent);
      if(pendingInjuryEvent) allEvents.push(pendingInjuryEvent);
      newMinutes.forEach(nm=>{
        if(nm.side==='my'){
          const scorer=myPool.length?myPool[Math.floor(Math.random()*myPool.length)]:null;
          allEvents.push({minute:nm.minute, type:'mygoal', icon:'⚽', text:`<strong>${scorer?scorer.name:'Gol'}</strong>`});
        }else{
          const scorer=oppPool.length?oppPool[Math.floor(Math.random()*oppPool.length)]:null;
          allEvents.push({minute:nm.minute, type:'oppgoal', icon:'⚽', text:`<strong>${scorer?scorer.name:'Gol'}</strong>`});
        }
      });
      allEvents.sort((a,b)=>a.minute-b.minute);

      myGoals=curMy+extraMy;
      oppGoals=curOpp+extraOpp;
      won=myGoals>oppGoals;
      draw=myGoals===oppGoals;
      resultText=draw?t("match.draw"):(won?t("match.victory"):t("match.defeat"));
      resultClass=draw?"res-draw-tag":(won?"res-win-tag":"res-lose-tag");
      if(!wasShootout && stage!=="group" && draw){
        const q=simulatePenalties(computeMyPower(), computeOppPower(nextOpponent));
        won=q.myWon; draw=false;
        resultText=won?t("match.victory"):t("match.defeat");
        resultClass=won?"res-win-tag":"res-lose-tag";
      }
    }catch(e){
      console.error('[Giro Táctico] Bloque 3 (resimular goles/marcador) falló:', e);
    }

    // ── Bloque 4: mantener coherente la tabla de grupos y el historial ──
    try{
      if(stage==="group"){
        const meRow=groupTable.find(r=>r.isMe);
        const oppRow=groupTable.find(r=>r.team===nextOpponent);
        if(meRow&&oppRow){
          meRow.gf-=oldMyGoals; meRow.ga-=oldOppGoals;
          oppRow.gf-=oldOppGoals; oppRow.ga-=oldMyGoals;
          if(oldDraw){ meRow.drawn--; meRow.pts-=1; oppRow.drawn--; oppRow.pts-=1; }
          else if(oldWon){ meRow.won--; meRow.pts-=3; oppRow.lost--; }
          else { meRow.lost--; oppRow.won--; oppRow.pts-=3; }
          meRow.gf+=myGoals; meRow.ga+=oppGoals;
          oppRow.gf+=oppGoals; oppRow.ga+=myGoals;
          if(draw){ meRow.drawn++; meRow.pts+=1; oppRow.drawn++; oppRow.pts+=1; }
          else if(won){ meRow.won++; meRow.pts+=3; oppRow.lost++; }
          else { meRow.lost++; oppRow.won++; oppRow.pts+=3; }
        }
      }
      if(matchResults&&matchResults.length){
        const last=matchResults[matchResults.length-1];
        last.score=`${myGoals}-${oppGoals}`;
        last.won=won; last.draw=draw;
        if(typeof renderMatchHistory==='function') renderMatchHistory();
      }
    }catch(e){
      console.error('[Giro Táctico] Bloque 4 (tabla de grupos/historial) falló:', e);
    }
  }

  function resumeAfterGiro(){
    regStart=performance.now()-giroPausedFrac*REG_DURATION;
    giroPaused=false;
    requestAnimationFrame(tickReg);
  }

  // ── Fase 3: Prórroga ────────────────────────────────────────────────────
  function startExtraTime(){
    const gBtn=document.getElementById('giroTacticoBtn'); if(gBtn) gBtn.style.display='none';
    halfEl.textContent=t('match.extratime'); halfEl.style.background='#7a3a0a';
    addSep('— '+t('match.extratime')+' —');    const ET=4000,ET_S=0.47,ET_E=0.53;
    let etHt=false;
    const etStart=performance.now();
    function tickET(now){
      const frac=Math.min((now-etStart)/ET,1);
      if(frac>=ET_S&&frac<ET_E){
        if(!etHt){ etHt=true; clockEl.textContent="105'"; halfEl.textContent=t("match.halftime"); halfEl.style.background='#a07a00'; addSep(t('match.et_ht_sep')||"Descanso prórroga — 105'"); playSound('whistle'); }
        requestAnimationFrame(tickET); return;
      }
      if(frac<ET_S){ clockEl.textContent=`${91+Math.floor((frac/ET_S)*14)}'`; halfEl.textContent=t('match.et_first')||'PRÓRROGA 1ª'; halfEl.style.background='#7a3a0a'; }
      else { const f2=(frac-ET_E)/(1-ET_E); clockEl.textContent=`${106+Math.floor(f2*14)}'`; halfEl.textContent=t('match.et_second')||'PRÓRROGA 2ª'; halfEl.style.background='#7a3a0a'; }
      if(frac<1){ requestAnimationFrame(tickET); return; }
      clockEl.textContent="120'"; halfEl.textContent=t("match.extratime")+" "+(t('match.end')||'FIN'); halfEl.style.background='#555';
      playSound('whistle'); setTimeout(startPenalties,900);
    }
    requestAnimationFrame(tickET);
  }

  // ── Fase 4: Penaltis ────────────────────────────────────────────────────
  function startPenalties(){
    halfEl.textContent=t('match.penalties'); halfEl.style.background='#3a0a5a'; clockEl.textContent='—';
    addSep('— '+t('match.penalties')+' —');
    const myShots=penaltyInfo.myShots,oppShots=penaltyInfo.oppShots;
    const maxLen=Math.max(myShots.length,oppShots.length);
    const sequence=[];
    for(let i=0;i<maxLen;i++){
      if(i<myShots.length) sequence.push({team:'me',shot:myShots[i],round:i+1});
      if(i<oppShots.length) sequence.push({team:'opp',shot:oppShots[i],round:i+1});
    }
    let penMy=0,penOpp=0,seqIdx=0;
    function label(r){ return r<=5?`P${r}`:'SD'; }
    function updatePenScore(){ scoreEl.textContent=`${curMy}(${penMy}) – ${curOpp}(${penOpp})`; }
    updatePenScore();
    function nextPen(){
      if(seqIdx>=sequence.length){ finishPenalties(); return; }
      const {team,shot,round}=sequence[seqIdx++];
      setTimeout(()=>{
        if(team==='me'){
          if(shot.scored) penMy++;
          addEvt(shot.scored?'✅':'❌',`<strong>${shot.name}</strong>`,label(round),'pen_me');
        } else {
          if(shot.scored) penOpp++;
          addEvt(shot.scored?'✅':'❌',`<strong>${shot.name}</strong>`,label(round),'pen_opp');
        }
        updatePenScore();
        if(shot.scored) playSound('goal');
        const myRem=myShots.filter((_,i)=>i>=Math.ceil(seqIdx/2)).length;
        const oppRem=oppShots.filter((_,i)=>i>=Math.floor(seqIdx/2)).length;
        const diff=penMy-penOpp;
        if(diff>oppRem||-diff>myRem){ setTimeout(finishPenalties,600); return; }
        setTimeout(nextPen,700);
      },600);
    }
    function finishPenalties(){
      const penWon=penMy>penOpp;
      if(penWon){ window._consecutivePenWins=(window._consecutivePenWins||0)+1; if(window._consecutivePenWins>=2) unlockAchievement('two_pen_wins'); }
      else window._consecutivePenWins=0;
      addSep(penWon
        ? (t('match.pen_win')||'🏆 {0} gana la tanda {1}–{2}').replace('{0}',myTeamName).replace('{1}',penMy).replace('{2}',penOpp)
        : (t('match.pen_lose')||'💔 {0} gana la tanda {1}–{2}').replace('{0}',oppName).replace('{1}',penOpp).replace('{2}',penMy));
      playSound(penWon?'victory':'defeat');
      setTimeout(showPostMatch,1200);
    }
    setTimeout(nextPen,500);
  }

  // ── Post-partido: añadir info al mismo modal ─────────────────────────────
  function showPostMatch(){
    const modal=overlay.querySelector('.match-modal');
    if(!modal) return;
    modal.style.overflowY='auto';

    // Banner resultado
    const banner=document.createElement('div');
    banner.className=`match-result-tag ${resultClass}`;
    banner.textContent=resultText;
    banner.style.animation='slideInEvent .4s ease forwards';
    modal.insertBefore(banner, eventsEl.nextSibling);

    // Info post-partido (lesiones, tarjetas, prensa, estrategia)
    const infoWrap=document.createElement('div');
    infoWrap.style.cssText='display:flex;flex-direction:column;gap:6px;margin-top:8px';

    // Estadísticas del partido: posesión + tiros (primeras 2 líneas del summary)
    const summaryDiv=document.createElement('div');
    summaryDiv.className='match-summary';
    // Extraer la parte de estadísticas (antes del bloque goals-columns)
    // El summary tiene el formato: "Posesión:...<br>Tiros:...\n<div class=goals-columns>..."
    const goalsColIdx=summary.indexOf('<div class="goals-columns">');
    const statsRaw=goalsColIdx>0 ? summary.substring(0,goalsColIdx) : summary;
    // Limpiar: el statsRaw ya tiene HTML válido con <strong> y <br>
    summaryDiv.innerHTML=statsRaw.trim();
    infoWrap.appendChild(summaryDiv);
    // Los goles ya aparecen en el feed secuencial arriba, no se duplican aquí

    // Giro Táctico — si se usó en este partido, mostrar la carta elegida
    if(window._giroCardUsed){
      const gc=document.createElement('div');
      gc.className='match-summary';
      gc.style.cssText='border:1px solid var(--gold);border-radius:8px;padding:10px;display:flex;align-items:center;gap:10px';
      gc.innerHTML=`
        <i class="ph ph-bold ${window._giroCardUsed.icon||'ph-notebook'}" style="font-size:26px;color:var(--gold);flex-shrink:0"></i>
        <div>
          <strong style="color:var(--gold)">${t('giro.used_title')||'Giro Táctico usado'}: ${window._giroCardUsed.name}</strong><br>
          <span style="color:#bfe8c9">${window._giroCardUsed.pos}</span> · <span style="color:#f3c6c1">${window._giroCardUsed.neg}</span>
        </div>`;
      infoWrap.appendChild(gc);
      window._giroCardUsed=null; // no arrastrar al siguiente partido
    }

    // Recuperados
    if(recovered.length){
      const r=document.createElement('div');
      r.className='match-summary recovered-box';
      r.innerHTML=`<strong>✅ ${t("match.recovered")||"Recuperados"}:</strong> ${recovered.join(", ")}`;
      infoWrap.appendChild(r);
    }

    // Lesiones
    if(newInjuries.length){
      const ILABELS={
        leve:   t('match.injury_leve')  ||'leve (1 partido)',
        básica: t('match.injury_basica')||'básica (2 partidos)',
        grave:  t('match.injury_grave') ||'grave (3 partidos)',
      };
      const inj=document.createElement('div');
      inj.className='injury-section';
      inj.innerHTML=`<p>${(t('match.injuries_short')||'⚠ Lesiones en {0}:').replace('{0}',myTeamName)}</p><ul>${newInjuries.map(p=>`<li><span style="color:#e74c3c">✚</span> ${p.name}: ${t('result.injury_item')||'lesión'} ${ILABELS[p.injury.type]||''}</li>`).join('')}</ul>`;
      infoWrap.appendChild(inj);
    }

    // Tarjetas
    if(newCards&&newCards.length){
      const CARD_LABELS={
        yellow:       {icon:'🟨', text:t('match.card_yellow_s') ||'amarilla'},
        yellow2:      {icon:'🟨🟨',text:t('match.card_yellow2_s')||'2ª amarilla — sancionado'},
        double_yellow:{icon:'🟨🟥',text:t('match.card_double_s') ||'doble amarilla — sancionado'},
        red:          {icon:'🟥', text:t('match.card_red_s')    ||'roja directa — sancionado'},
      };
      const cd=document.createElement('div');
      cd.className='card-section';
      cd.innerHTML=`<p>${t('match.cards_short')||'📋 Tarjetas:'}</p><ul>${newCards.map(c=>{const l=CARD_LABELS[c.type];return `<li>${l.icon} ${c.player.name}: ${l.text}</li>`;}).join('')}</ul>`;
      infoWrap.appendChild(cd);
    }

    // Entrevista de prensa
    if(predictionResult){
      const cls=predictionResult.outcome==='correct'?'press-prediction-good':predictionResult.outcome==='wrong'?'press-prediction-bad':'press-prediction-neutral';
      const pr=document.createElement('div');
      pr.className=`press-prediction-section ${cls}`;
      pr.textContent=predictionResult.text;
      infoWrap.appendChild(pr);
    }

    // Estrategia
    if(selectedMatchStrategy&&nextOpponent){
      const rivalKey=getRivalStrategyKey(nextOpponent);
      const myKey=selectedMatchStrategy;
      const myStrat=STRATEGIES[myKey];
      const iCounter=myStrat&&myStrat.counters===rivalKey;
      const iPartial=myStrat&&myStrat.partialCounters&&myStrat.partialCounters.includes(rivalKey);
      const counteredBy=STRATEGIES[rivalKey]&&STRATEGIES[rivalKey].counters===myKey;
      let stratMsg,stratClass;
      if(iCounter){stratMsg=(window.t?window.t('strategy.fb.counter'):'✓ Tu estrategia ({0}) contrarrestó perfectamente a {1}.').replace('{0}',myStrat.name).replace('{1}',oppName);stratClass='strategy-feedback-good';}
      else if(iPartial){stratMsg=(window.t?window.t('strategy.fb.partial'):'✓ Tu estrategia ({0}) controló bien a {1}.').replace('{0}',myStrat.name).replace('{1}',oppName);stratClass='strategy-feedback-good';}
      else if(counteredBy){stratMsg=(window.t?window.t('strategy.fb.beaten'):'✗ {0} aprovechó el enfrentamiento táctico.').replace('{0}',oppName);stratClass='strategy-feedback-bad';}
      else if(myKey===rivalKey){stratMsg=(window.t?window.t('strategy.fb.mirror'):'= Ambos jugaron con un enfoque similar ({0}).').replace('{0}',myStrat.name);stratClass='strategy-feedback-neutral';}
      else{stratMsg=(window.t?window.t('strategy.fb.neutral'):'Estrategia neutral: {0}, sin ventaja táctica clara.').replace('{0}',myStrat.name);stratClass='strategy-feedback-neutral';}
      const sf=document.createElement('div');
      sf.className=`strategy-feedback ${stratClass}`;
      sf.textContent=stratMsg;
      infoWrap.appendChild(sf);
    }

    modal.appendChild(infoWrap);

    // MÉDICO DE ÉLITE: curar lesiones leves al finalizar el partido
    if(window._skillCache&&window._skillCache.medico){
      usedPlayers.forEach(p=>{
        if(p.injury&&p.injury.type==='leve') p.injury=null;
      });
    }
    // Restaurar ratings de expulsados que quedaron en campo con 0
    [...usedPlayers,...bench].forEach(p=>{
      if(p._redThisMatchOnPitch && p._originalRating!==undefined){
        p.rating=p._originalRating;
        delete p._originalRating;
        delete p._redThisMatchOnPitch;
      }
      delete p._redThisMatch;
    });
    // Aplicar efectos del partido ahora que ha terminado
    applyMatchFatigue();
    refreshPitchRatings();
    baseTeamOVR=computeTeamOVR();
    updateConvocadosTable();
    updateBenchTable();

    // Botón continuar
    let btnLabel,outcome;
    if(stage==='group'){
      if(groupMatchIdx>=3){btnLabel=t("match.group_results");outcome='groupDone';}
      else{btnLabel=t('match.next_match');outcome='nextGroupMatch';}
    } else {
      if(!won){btnLabel=t('match.end_tournament')||'FIN DEL TORNEO';outcome='knockoutLost';}
      else if(knockoutRound>=ROUND_NAMES.length-1){btnLabel=t('match.see_summary')||'VER RESUMEN FINAL';outcome='champion';}
      else{btnLabel=t('match.next_round')||'SIGUIENTE RONDA';outcome='nextKnockoutMatch';}
    }
    const btn=document.createElement('button');
    btn.className='modal-btn';
    btn.textContent=btnLabel;
    btn.style.marginTop='10px';
    // Logros post-partido
    if(won && swapsUsedThisMatch===0) unlockAchievement('no_subs_win');
    if(won && stage==='knockout') unlockAchievement('comeback'); // simplificado
    // Todos en posición ★
    const allStars=usedPlayers.every(p=>p.positions&&p.placedPos&&p.positions[0]===p.placedPos);
    if(allStars&&usedPlayers.length===11) unlockAchievement('all_stars');
    // 5 jugadores 90+
    const top5=usedPlayers.filter(p=>(p.rating||0)>=90).length>=5;
    if(top5) unlockAchievement('5_nineties');
    // Táctica perfecta
    if(won&&selectedMatchStrategy&&nextOpponent){
      const rk=getRivalStrategyKey(nextOpponent);
      if(STRATEGIES[selectedMatchStrategy]&&STRATEGIES[selectedMatchStrategy].counters===rk) unlockAchievement('perfect_tactic');
    }

    btn.addEventListener('click',()=>{
      overlay.innerHTML='';
      switch(outcome){
        case 'nextGroupMatch': pickNextOpponent(); break;
        case 'groupDone': renderMatchHistory(); showGroupResultsPopup(); break;
        case 'nextKnockoutMatch':
          if(knockoutRound===1) clearYellowCardsAfterQuarterfinals();
          // PATROCINADOR: +1 GOAT Point al clasificar a cuartos (pasar de grupos)
          if(knockoutRound===0&&window._skillCache&&window._skillCache.patrocinador){
            const _u=window._fbAuth&&window._fbAuth.currentUser;
            if(_u&&window._fbDb) window._fbDb.collection('users').doc(_u.uid).get().then(s=>{
              const d=s.exists?s.data():{};
              window._fbDb.collection('users').doc(_u.uid).set({scratchPoints:(d.scratchPoints||0)+1},{merge:true});
            });
          }
          knockoutRound++; pickNextOpponent(); break;
        case 'champion': showVictory(); break;
        case 'knockoutLost': showEliminated(); break;
      }
    });
    modal.appendChild(btn);

    // Mostrar logros desbloqueados durante el partido
    if(window._pendingAchievements&&window._pendingAchievements.length){
      const achWrap=document.createElement('div');
      achWrap.style.cssText='margin-top:10px;display:flex;flex-direction:column;gap:6px';
      window._pendingAchievements.forEach(def=>{
        const row=document.createElement('div');
        row.style.cssText=`display:flex;align-items:center;gap:10px;padding:8px 10px;background:rgba(201,162,39,.1);border:1px solid var(--gold);animation:slideInEvent .4s ease forwards`;
        const _n=window.t?window.t('ach.'+def.id)||def.name:def.name;
        const _d=window.t?window.t('ach.'+def.id+'.d')||def.desc:def.desc;
        row.innerHTML=`<i class="ph ph-bold ${def.icon}" style="font-size:20px;color:#c9a227;flex-shrink:0"></i><div><div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:12px;letter-spacing:1px;color:var(--gold)">${t("match.achievement_unlocked")||"LOGRO"}: ${_n}</div><div style="font-size:10px;color:var(--text-muted)">${_d} · <span style="color:var(--gold)">+${def.pts} pts</span></div></div>`;
        achWrap.appendChild(row);
      });
      modal.appendChild(achWrap);
      window._pendingAchievements=[];
    }

    // Scroll al final para ver el banner y la info
    setTimeout(()=>{ overlay.querySelector('.match-modal').scrollTop=9999; },100);
  }
}


function showMatchModal(myGoals,oppGoals,summary,recovered,newInjuries,won,draw,penaltyInfo,newCards,predictionResult){
  const wasShootout=!!penaltyInfo;
  let resultText, resultClass;
  if(draw){
    resultText=t("match.draw"); resultClass="res-draw-tag";
  } else {
    resultText=won?(wasShootout?t('match.victory_pen')||'¡VICTORIA EN PENALTIS!':t('match.victory')||'¡VICTORIA!'):(wasShootout?t('match.defeat_pen')||'DERROTA EN PENALTIS':t('match.defeat')||'DERROTA');
    resultClass=won?"res-win-tag":"res-lose-tag";
  }
  playSound(won||draw?'victory':'defeat');
  let extraHTML="";
  if(recovered.length){
    extraHTML+=`<div class="match-summary recovered-box"><strong>${t('match.recovered')||'Recuperados'}:</strong> ${recovered.join(", ")}</div>`;
  }
  if(newInjuries.length){
    const ILABELS={
      leve:   t('result.injury.leve')  ||'leve (1 partido)',
      básica: t('result.injury.basica')||'básica (2 partidos)',
      grave:  t('result.injury.grave') ||'grave (3 partidos)',
    };
    extraHTML+=`<div class="injury-section"><p>${(t('result.injuries_title')||'⚠ Lesiones en {0} tras el partido:').replace('{0}',myTeamName)}</p><ul>${newInjuries.map(p=>`<li>${p.name}: ${t('result.injury_item')||'lesión'} ${ILABELS[p.injury.type]}</li>`).join('')}</ul><p class="injury-note">${(t('result.injury_note')||'Recuerda: puedes hacer hasta <strong>{0} cambios</strong> entre Convocados y Banquillo antes del próximo partido. Hazlo manualmente desde las tablas de la izquierda.').replace('{0}',getMaxSubs())}</p></div>`;
  }
  if(newCards&&newCards.length){
    const CARD_LABELS={
      yellow:       {icon:"🟨", text:t('result.card.yellow')      ||'amarilla'},
      yellow2:      {icon:"🟨🟨",text:t('result.card.yellow2')    ||'2ª amarilla (acumulación) — sancionado el próximo partido'},
      double_yellow:{icon:"🟨🟥",text:t('result.card.double_yellow')||'doble amarilla — expulsado, sancionado el próximo partido'},
      red:          {icon:"🟥", text:t('result.card.red')         ||'roja directa — sancionado el próximo partido'},
    };
    extraHTML+=`<div class="card-section"><p>${(t('result.cards_title')||'📋 Tarjetas en {0} tras el partido:').replace('{0}',myTeamName)}</p><ul>${newCards.map(c=>{
      const lbl=CARD_LABELS[c.type];
      return `<li>${lbl.icon} ${c.player.name}: ${lbl.text}</li>`;
    }).join('')}</ul></div>`;
  }
  if(predictionResult){
    const cls=predictionResult.outcome==='correct'?'press-prediction-good':
               predictionResult.outcome==='wrong'?'press-prediction-bad':'press-prediction-neutral';
    extraHTML+=`<div class="press-prediction-section ${cls}">${predictionResult.text}</div>`;
  }
  // Strategy result feedback
  if(selectedMatchStrategy && nextOpponent){
    const rivalKey=getRivalStrategyKey(nextOpponent);
    const myKey=selectedMatchStrategy;
    const myStrat=STRATEGIES[myKey];
    const iCounter = myStrat && myStrat.counters===rivalKey;
    const iPartialCounter = myStrat && myStrat.partialCounters && myStrat.partialCounters.includes(rivalKey);
    const counteredByRival = STRATEGIES[rivalKey] && STRATEGIES[rivalKey].counters===myKey;
    let stratMsg, stratClass;
    if(iCounter){ stratMsg=(window.t?window.t('strategy.fb.counter2'):'✓ Tu estrategia ({0}) contrarrestó perfectamente a {1}.').replace('{0}',myStrat.name).replace('{1}',getTeamName(nextOpponent.name)); stratClass="strategy-feedback-good"; }
    else if(iPartialCounter){ stratMsg=(window.t?window.t('strategy.fb.partial2'):'✓ Tu estrategia ({0}) controló bien a {1}, aunque no era la elección perfecta.').replace('{0}',myStrat.name).replace('{1}',getTeamName(nextOpponent.name)); stratClass="strategy-feedback-good"; }
    else if(counteredByRival){ stratMsg=(window.t?window.t('strategy.fb.beaten2'):'✗ {0} aprovechó mejor el enfrentamiento táctico esta vez.').replace('{0}',getTeamName(nextOpponent.name)); stratClass="strategy-feedback-bad"; }
    else if(myKey===rivalKey){ stratMsg=(window.t?window.t('strategy.fb.mirror2'):'= Ambos equipos jugaron con un enfoque similar ({0}).').replace('{0}',myStrat.name); stratClass="strategy-feedback-neutral"; }
    else { stratMsg=`Estrategia neutral: ${myStrat.name}, sin ventaja táctica clara.`; stratClass="strategy-feedback-neutral"; }
    extraHTML+=`<div class="strategy-feedback ${stratClass}">${stratMsg}</div>`;
  }

  // Determine continue-button label and the outcome it leads to
  let btnLabel, outcome;
  if(stage==="group"){
    if(groupMatchIdx>=3) btnLabel=t("match.group_results"), outcome="groupDone";
    else btnLabel=t("match.next_match"), outcome="nextGroupMatch";
  } else { // knockout
    if(!won){ btnLabel=t('match.end_tournament')||'FIN DEL TORNEO'; outcome="knockoutLost"; }
    else if(knockoutRound>=ROUND_NAMES.length-1){ btnLabel=t('match.see_summary')||'VER RESUMEN FINAL'; outcome="champion"; }
    else { btnLabel=t('match.next_round')||'SIGUIENTE RONDA'; outcome="nextKnockoutMatch"; }
  }

  document.getElementById("matchOverlay").innerHTML=`
  <div class="match-modal">
    <div class="match-header">
      <div class="match-side">
        <span class="flag-emoji match-flag">🐐</span>
        <span class="match-team-name">${myTeamName}</span>
      </div>
      <div class="match-scoreline">${myGoals} – ${oppGoals}</div>
      <div class="match-side">
        ${flagEmoji(nextOpponent.name)}
        <span class="match-team-name">${getTeamName(nextOpponent.name)}</span>
      </div>
    </div>
    <div class="match-result-tag ${resultClass}">${resultText}</div>
    <div class="match-summary">${summary}</div>
    ${extraHTML}
    <button class="modal-btn" id="matchContinueBtn">${btnLabel}</button>
  </div>`;
  document.getElementById("matchContinueBtn").addEventListener("click",()=>{
    document.getElementById("matchOverlay").innerHTML="";
    switch(outcome){
      case "nextGroupMatch":
        pickNextOpponent();
        break;
      case "groupDone":
        renderMatchHistory();
        showGroupResultsPopup();
        break;
      case "nextKnockoutMatch":
        // If we're moving FROM Cuartos de Final (index 1) TO Semifinal (index 2),
        // wipe accumulated yellow cards per FIFA rules — nobody should miss
        // a final purely from earlier-round accumulation.
        if(knockoutRound===1) clearYellowCardsAfterQuarterfinals();
        knockoutRound++;
        pickNextOpponent();
        break;
      case "champion":
        showVictory();
        break;
      case "knockoutLost":
        showEliminated();
        break;
    }
  });
}

/* ---------- PROGRESSIVE GROUP RESULTS POPUP ---------- */
function showGroupResultsPopup(){
  // Logros de fase de grupos
  const meRow=groupTable.find(r=>r.isMe);
  if(meRow){
    if(meRow.lost===0) unlockAchievement('groups_unbeaten');
    if(meRow.ga===0) unlockAchievement('groups_no_concede');
    if(meRow.won===3) unlockAchievement('win_all_groups');
    unlockAchievement('first_groups');
  }
  const sorted=sortedGroupTable();
  const meIdx=sorted.findIndex(r=>r.isMe);
  const qualified=meIdx<2;
  document.getElementById("matchOverlay").innerHTML=`
  <div class="match-modal">
    <h3>${t('result.groups_title')||'FASE DE GRUPOS — RESULTADOS'}</h3>
    <div class="match-summary">${t('result.groups_table_intro')||'Así queda la tabla de tu grupo:'}</div>
    <div id="groupResultsTableWrap"></div>
    <button class="modal-btn" id="groupResultsContinueBtn" style="display:none">${t('result.groups_continue')||'CONTINUAR'}</button>
  </div>`;
  const wrap=document.getElementById("groupResultsTableWrap");
  let i=0;
  function revealNext(){
    const shown=sorted.slice(0,i+1);
    let rows="";
    shown.forEach((r,idx)=>{
      const qual=idx<2;
      const cls=(r.isMe?"group-row-me":"")+(qual?' group-row-qualified':'');
      rows+=`<tr class="${cls}">
        <td>${idx+1}</td>
        <td>${r.isMe?('<span class="flag-emoji goat-emoji">🐐</span> '+getTeamName(r.name)):(flagEmoji(r.name,18)+' '+getTeamName(r.name))}</td>
        <td>${r.played}</td><td>${r.won}</td><td>${r.drawn}</td><td>${r.lost}</td>
        <td>${r.gf}-${r.ga}</td><td><strong>${r.pts}</strong></td>
      </tr>`;
    });
    wrap.innerHTML=`<table class="group-table"><thead><tr><th>#</th><th>${t('result.group_th_team')||'Equipo'}</th><th>${t('result.group_th_pld')||'PJ'}</th><th>${t('result.group_th_w')||'G'}</th><th>${t('result.group_th_d')||'E'}</th><th>${t('result.group_th_l')||'P'}</th><th>GF-GC</th><th>${t('result.group_th_pts')||'Pts'}</th></tr></thead><tbody>${rows}</tbody></table>`;
    playSound('reveal');
    i++;
    if(i<sorted.length){
      setTimeout(revealNext, 600);
    } else {
      const btn=document.getElementById("groupResultsContinueBtn");
      const summary=document.createElement("div");
      summary.className="match-result-tag "+(qualified?"res-win-tag":"res-lose-tag");
      summary.textContent=qualified
        ? (t('result.qualified')||'¡{0} clasificado para {1}! ({2}º del grupo)').replace('{0}',myTeamName).replace('{1}',t('comp.r16')||'Octavos de Final').replace('{2}',meIdx+1).replace('{3}','')
        : (t('result.eliminated_group')||'{0} eliminado en la fase de grupos ({1}º del grupo)').replace('{0}',myTeamName).replace('{1}',meIdx+1).replace('{2}','');
      wrap.parentNode.insertBefore(summary, btn);
      btn.style.display="block";
      btn.addEventListener("click",()=>{
        document.getElementById("matchOverlay").innerHTML="";
        if(qualified){
          stage="knockout";
          knockoutRound=0;
          renderMatchHistory();
          renderCenterSummary();
          pickNextOpponent();
        } else {
          showEliminatedGroupStage();
        }
      });
    }
  }
  setTimeout(revealNext, 300);
}

/* ---------- END SCREENS ---------- */
function showEliminatedGroupStage(){
  const sc=computeFinalScore(false);
  if(typeof window.saveMatchStat==="function") window.saveMatchStat(false,false,0,0);
  if(typeof window.saveFinalScore==="function") window.saveFinalScore(sc.total);
  document.getElementById("matchOverlay").innerHTML=`
  <div class="match-modal">
    <h3>${t('result.elim_groups_title')||'FASE DE GRUPOS'}</h3>
    <div class="match-result-tag res-lose-tag">${t('result.elim_groups_tag')||'ELIMINADO EN FASE DE GRUPOS'}</div>
    <div class="match-summary">${(t('result.elim_groups_text')||'{0} no ha conseguido clasificarse entre los 2 primeros del grupo.').replace('{0}',myTeamName)}</div>
    <div class="victory-score-wrap" style="border-top:1px solid #333;margin-top:12px;padding-top:12px">
      <div class="victory-score-label">${t('result.score')||'PUNTUACIÓN'}</div>
      <div class="victory-score-num" style="font-size:48px">${sc.total}</div>
    </div>
    <button class="modal-btn danger" onclick="location.reload()">${t('match.new_game')||'NUEVA PARTIDA'}</button>
  </div>`;
}
function showEliminated(){
  const round=getRoundName(knockoutRound);
  const sc=computeFinalScore(false);
  if(typeof window.saveFinalScore==="function") window.saveFinalScore(sc.total);
  const grade=sc.total>=750?t('result.grade.elite')||'ÉLITE':sc.total>=550?t('result.grade.very_good')||'MUY BUENO':sc.total>=350?t('result.grade.good')||'BUENO':t('result.grade.improvable')||'MEJORABLE';
  // Run encadenada: nº de jugadores conservados según nivel de mejora (mín. octavos alcanzados)
  const slots=getChainSlots();
  const chainBtn=slots>0
    ?`<button class="modal-btn" onclick="document.getElementById('matchOverlay').innerHTML='';showChainRunModal()">
        ${(t('result.chain_keep')||'🔗 CONSERVAR {0} JUGADOR{1}').replace('{0}',slots).replace('{1}',slots>1?'ES':'')}
      </button>`
    :"";
  document.getElementById("matchOverlay").innerHTML=`
  <div class="match-modal">
    <h3>${round?round.toUpperCase():t('comp.r16')||'ELIMINATORIAS'}</h3>
    <div class="match-result-tag res-lose-tag">${(t('result.elim_ko_tag')||'ELIMINADO EN {0}').replace('{0}',round?round.toUpperCase():'')}</div>
    <div class="victory-score-wrap" style="border:1px solid #333;margin:12px 0;padding:12px">
      <div class="victory-score-label">${t('result.final_score')||'PUNTUACIÓN FINAL'}</div>
      <div class="victory-score-num" style="font-size:52px">${sc.total}</div>
      <div class="victory-grade" style="color:#aaa;font-size:16px">${grade}</div>
    </div>
    ${slots>0?`<p style="font-size:12px;color:var(--gold);margin-bottom:8px">${(t('result.chain_info')||'🔗 Run Encadenada: conserva {0} jugador{1} para el siguiente intento').replace('{0}',slots).replace('{1}',slots>1?'es':'')}</p>`:""}
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      ${chainBtn}
      <button class="modal-btn danger" onclick="location.reload()">${t('match.new_game')||'NUEVA PARTIDA'}</button>
    </div>
  </div>`;
}
function computeFinalScore(champion){
  const scores={};

  // Stage factor: how far you got scales ALL quality metrics
  // This ensures early elimination truly hurts — not just a small penalty
  let stageFactor, stageBonus;
  if(champion){
    stageFactor=1.0; stageBonus=250;
  } else if(stage==="knockout"){
    const factors=[0.45, 0.60, 0.75, 0.88];
    stageFactor=factors[Math.min(knockoutRound,3)]||0.45;
    const bonuses=[60, 100, 150, 200];
    stageBonus=bonuses[Math.min(knockoutRound,3)]||60;
  } else {
    stageFactor=0.20; stageBonus=20; // groups → harsh penalty
  }
  scores.stage=stageBonus;

  // Team quality (OVR) — scaled by stageFactor
  scores.ovr=Math.round((baseTeamOVR||60)/100*150*stageFactor);

  // Goals scored
  const totalGoals=matchResults.reduce((s,r)=>{const g=parseInt(r.score)||0;return s+g;},0);
  scores.goals=Math.round(Math.min(80*stageFactor, totalGoals/12*80*stageFactor));

  // Defensive solidity
  const totalConceded=matchResults.reduce((s,r)=>{
    const parts=r.score.split('-'); return s+(parseInt(parts[1])||0);
  },0);
  scores.defense=Math.round(Math.max(0,(1-Math.min(totalConceded,10)/10)*60*stageFactor));

  // Morale
  scores.morale=Math.round(Math.max(0,(teamMorale+50)/100*50*stageFactor));

  // Star players in position
  const stars=usedPlayers.filter(p=>p.positions&&p.placedPos&&p.positions[0]===p.placedPos).length;
  scores.stars=Math.round(stars*(60/11)*stageFactor);

  // Scorer streaks
  const streakTotal=Object.values(scorerStreaks).reduce((s,v)=>s+Math.min(v,MAX_STREAK_BONUS),0);
  scores.streaks=Math.round(Math.min(60*stageFactor, streakTotal*12*stageFactor));

  // Penalty wins (reward for drama — not scaled, it's hard enough to earn)
  const penWins=matchResults.filter(r=>r.won&&r.score.includes('pen.')).length;
  scores.penalties=Math.min(80, penWins*30);

  // Clean sheets
  const cleanSheets=matchResults.filter(r=>{
    const parts=r.score.split('-');
    return r.won&&(parseInt(parts[1])||0)===0;
  }).length;
  scores.cleanSheets=Math.round(Math.min(60*stageFactor, cleanSheets*12*stageFactor));

  const raw=Object.values(scores).reduce((a,b)=>a+b,0);
  const total=Math.min(1000, Math.round(raw));
  return {total, breakdown:scores, penWins, totalGoals, totalConceded, stars, cleanSheets, stageFactor};
}
function showVictory(){
  unlockAchievement('champion_unbeaten'); // simplificado — ganar el mundial
  // Triple corona: contar mundiales ganados
  const user=window._fbAuth&&window._fbAuth.currentUser;
  if(user&&window._fbDb){
    window._fbDb.collection('users').doc(user.uid).get().then(s=>{
      const d=s.exists?s.data():{};
      const wins=(d.worldCupWins||0)+1;
      window._fbDb.collection('users').doc(user.uid).set({worldCupWins:wins},{merge:true});
      if(wins>=3) unlockAchievement('triple_crown');
    });
  }
  const sc=computeFinalScore(true);
  if(typeof window.saveVictoryStat==="function") window.saveVictoryStat(sc.total);
  if(typeof window.saveFinalScore==="function") window.saveFinalScore(sc.total);
  const grade=sc.total>=900?t('result.grade.legendary')||'LEGENDARIO':sc.total>=750?t('result.grade.elite')||'ÉLITE':sc.total>=600?t('result.grade.excellent')||'EXCELENTE':sc.total>=450?t('result.grade.very_good')||'MUY BUENO':t('result.grade.good')||'BUENO';
  const gradeColor=sc.total>=900?"#f0c419":sc.total>=750?"#e67e22":sc.total>=600?"#0f6b3b":"#3498db";

  document.getElementById("matchOverlay").innerHTML=`
  <div class="match-modal victory-modal">
    <div class="match-result-tag res-win-tag">${t("comp.champion")}</div>
    <div class="victory-score-wrap">
      <div class="victory-score-label">${t('result.final_score')||'PUNTUACIÓN FINAL'}</div>
      <div class="victory-score-num">${sc.total}</div>
      <div class="victory-grade" style="color:${gradeColor}">${grade}</div>
    </div>
    <div class="victory-breakdown">
      <div class="vb-row"><span>${(t('result.vb.ovr')||'Calidad del equipo (OVR {0})').replace('{0}',baseTeamOVR||0)}</span><span class="vb-pts">${sc.breakdown.ovr} pts</span></div>
      <div class="vb-row"><span>${(t('result.vb.goals')||'Goles marcados ({0})').replace('{0}',sc.totalGoals)}</span><span class="vb-pts">${sc.breakdown.goals} pts</span></div>
      <div class="vb-row"><span>${(t('result.vb.defense')||'Solidez defensiva ({0} goles encajados)').replace('{0}',sc.totalConceded)}</span><span class="vb-pts">${sc.breakdown.defense} pts</span></div>
      <div class="vb-row"><span>${(t('result.vb.morale')||'Gestión de moral ({0}{1})').replace('{0}',teamMorale>0?'+':'').replace('{1}',teamMorale)}</span><span class="vb-pts">${sc.breakdown.morale} pts</span></div>
      <div class="vb-row"><span>${(t('result.vb.clean')||'Portería a cero ({0} partidos)').replace('{0}',sc.cleanSheets)}</span><span class="vb-pts">${sc.breakdown.cleanSheets} pts</span></div>
      <div class="vb-row"><span>${(t('result.vb.stars')||'Jugadores en posición ★ ({0}/11)').replace('{0}',sc.stars)}</span><span class="vb-pts">${sc.breakdown.stars} pts</span></div>
      <div class="vb-row"><span>${t('result.vb.streaks')||'Rachas de goleador'}</span><span class="vb-pts">${sc.breakdown.streaks} pts</span></div>
      ${sc.penWins?`<div class="vb-row"><span>${(t('result.vb.penalties')||'Victorias en penaltis ({0})').replace('{0}',sc.penWins)}</span><span class="vb-pts">${sc.breakdown.penalties} pts</span></div>`:''}
    </div>
    <button class="modal-btn" onclick="window._launchGoldenAndReload()">${t("comp.end_tournament")}</button>
  </div>`;
}

window._launchGoldenAndReload=function(){ showGoldenTicket(); };

/* ── TICKET DORADO: solo cabras y una X roja. Se gasta al instante. ── */
function showGoldenTicket(){
  const GOLD_GRID=9;
  // 1 bomba, 8 cabras (3pts cada una → max 24pts)
  const bombIdx=Math.floor(Math.random()*GOLD_GRID);
  const cellsData=[];
  for(let i=0;i<GOLD_GRID;i++){
    cellsData.push(i===bombIdx ? {type:'bomb',value:0} : {type:'star',value:3});
  }

  // Crear overlay encima del modal de victoria
  const wrap=document.createElement('div');
  wrap.id='goldenTicketWrap';
  wrap.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:60000;display:flex;align-items:center;justify-content:center;overflow-y:auto;padding:20px 0;';

  const serial=String(Math.floor(1000+Math.random()*8999))+'-'+String(Math.floor(1000+Math.random()*8999));
  wrap.innerHTML=`
  <div style="position:relative;width:340px;background:linear-gradient(180deg,#3a2a00 0%,#1a1200 100%);border-radius:18px;box-shadow:0 0 0 2px #f0c419,0 30px 60px -10px rgba(0,0,0,.9);overflow:hidden;">
    <button onclick=\"window.gtClose(0)\" style=\"position:absolute;top:10px;right:12px;background:none;border:none;color:rgba(240,196,25,.5);font-size:20px;cursor:pointer;z-index:10;line-height:1;padding:4px\" title=\"${tk('ticket.close_x')}\">✕</button>
    <div style="padding:26px 22px 22px;">
      <div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:2px;">
        <span style="font-size:18px">🏆</span>
        <span style="font-family:Bebas Neue,Impact,sans-serif;font-size:22px;letter-spacing:2px;color:#f0c419;text-shadow:0 0 12px rgba(240,196,25,.6)">${tk("ticket.golden_title")}</span>
        <span style="font-size:18px">🏆</span>
      </div>
      <div style="text-align:center;font-size:10px;letter-spacing:3px;color:rgba(240,196,25,.6);text-transform:uppercase;margin-bottom:16px;font-weight:700">${tk("ticket.prize_champion")}</div>
      <div style="height:1px;background:repeating-linear-gradient(90deg,rgba(240,196,25,.5) 0 6px,transparent 6px 12px);margin:14px 0"></div>
      <div style="display:flex;justify-content:space-between;font-size:9px;letter-spacing:1px;color:rgba(240,196,25,.4);text-transform:uppercase;margin-bottom:14px;">
        <span>Nº <b style="color:rgba(240,196,25,.7)">${serial}</b></span><span>${tk("ticket.edition_gold")}</span>
      </div>
      <div style="text-align:center;margin-bottom:18px;">
        <div style="font-size:9px;letter-spacing:3px;text-transform:uppercase;color:rgba(240,196,25,.5);margin-bottom:4px;font-weight:700">${tk("ticket.accumulated_pts")}</div>
        <div id="gtPrize" style="font-family:'Bebas Neue',Impact,sans-serif;font-size:40px;color:#f0c419;text-shadow:0 0 12px rgba(240,196,25,.4);">0 <span style="font-size:20px;opacity:.85">PTS</span></div>
      </div>
      <div id="gtGrid" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:18px;"></div>
      <div id="gtDots" style="display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:16px;flex-wrap:wrap;">
        <span style="font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:rgba(240,196,25,.5);font-weight:700;margin-right:4px;">${tk('ticket.scratched')}</span>
      </div>
      <button id="gtCashBtn" disabled onclick="gtCashOut(false)" style="width:100%;border:none;border-radius:0;font-family:'Bebas Neue',Impact,sans-serif;font-size:22px;letter-spacing:2px;padding:14px;cursor:pointer;background:linear-gradient(180deg,#ffe27a,#f0c419 55%,#c9960c);color:#08160d;box-shadow:0 6px 0 #8a6a08;opacity:.35;pointer-events:none;">${tk('ticket.cashout')}</button>
      <div style="text-align:center;font-size:9px;color:rgba(240,196,25,.35);margin-top:14px;letter-spacing:.5px;line-height:1.5">
        ${tk("ticket.goat_hint")}
      </div>
    </div>
  </div>
  <div id="gtResultOverlay" style="display:none;position:fixed;inset:0;z-index:70000;background:rgba(0,0,0,.8);align-items:center;justify-content:center;padding:20px;"></div>`;
  document.body.appendChild(wrap);

  let gtPoints=0, gtScratched=0, gtOver=false;

  function gtUpdateUI(){
    const p=$id('gtPrize'); if(p) p.innerHTML=`${gtPoints} <span style="font-size:20px;opacity:.85">PTS</span>`;
    const cb=$id('gtCashBtn'); const ca=$id('gtCashAmt');
    if(ca) ca.textContent=gtPoints;
    if(cb){
      const ok=gtPoints>0&&!gtOver;
      cb.disabled=!ok; cb.style.opacity=ok?'1':'.35'; cb.style.pointerEvents=ok?'auto':'none';
    }
  }

  const grid=$id('gtGrid');
  const dotsRow=$id('gtDots');

  for(let i=0;i<GOLD_GRID;i++){
    const data=cellsData[i];
    const cell=document.createElement('div');
    cell.style.cssText='position:relative;aspect-ratio:1;border-radius:10px;overflow:hidden;background:#2a1f00;box-shadow:inset 0 0 0 2px rgba(240,196,25,.3);';
    cell.dataset.index=i;
    const res=document.createElement('div');
    res.style.cssText='position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:2px;font-family:"Bebas Neue",Impact,sans-serif;background:#1a1200;';
    if(data.type==='bomb'){
      res.innerHTML=`<span style="font-size:26px">❌</span><span style="font-size:13px;color:#f87171;letter-spacing:.5px">${tk("ticket.cell_lose")}</span>`;
    } else {
      res.innerHTML=`<span style="font-size:26px">🐐</span><span style="font-size:13px;color:#f0c419;letter-spacing:.5px">${tk("ticket.cell_goat_gold")}</span>`;
    }
    cell.appendChild(res);
    const canvas=document.createElement('canvas');
    canvas.style.cssText='position:absolute;inset:0;width:100%;height:100%;cursor:pointer;touch-action:none;';
    cell.appendChild(canvas);
    grid.appendChild(cell);

    const dot=document.createElement('span');
    dot.style.cssText='width:9px;height:9px;border-radius:50%;background:rgba(240,196,25,.18);display:inline-block;transition:all .25s ease;';
    dot.dataset.di=i;
    dotsRow.appendChild(dot);

    // Init canvas (misma lógica pero dorada)
    const dpr=window.devicePixelRatio||1;
    const rect=cell.getBoundingClientRect()||{width:80,height:80};
    const w=Math.max(rect.width,80), h=Math.max(rect.height,80);
    canvas.width=w*dpr; canvas.height=h*dpr;
    canvas.style.width=w+'px'; canvas.style.height=h+'px';
    const ctx=canvas.getContext('2d');
    ctx.scale(dpr,dpr);
    const grad=ctx.createLinearGradient(0,0,w,h);
    grad.addColorStop(0,'#c9960c'); grad.addColorStop(.5,'#f0c419'); grad.addColorStop(1,'#c9960c');
    ctx.fillStyle=grad; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle='rgba(255,220,50,.4)'; ctx.lineWidth=2;
    for(let x=-h;x<w;x+=6){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x+h,h);ctx.stroke();}
    ctx.font='20px sans-serif'; ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.globalAlpha=.5; ctx.fillStyle='#000'; ctx.fillText('🐐',w/2,h/2); ctx.globalAlpha=1;
    ctx.globalCompositeOperation='destination-out';

    let scratching=false;
    function scratchAt(cx,cy){
      const r=canvas.getBoundingClientRect();
      ctx.beginPath(); ctx.arc(cx-r.left,cy-r.top,18,0,Math.PI*2); ctx.fill();
      const d=ctx.getImageData(0,0,canvas.width,canvas.height).data;
      let cl=0,s=0;
      for(let p=3;p<d.length;p+=160){s++;if(d[p]<80)cl++;}
      if(cl/s>0.5&&!cell.dataset.revealed) gtReveal(cell,i,canvas);
    }
    canvas.addEventListener('mousedown',e=>{scratching=true;scratchAt(e.clientX,e.clientY);e.preventDefault();});
    canvas.addEventListener('mousemove',e=>{if(!scratching)return;scratchAt(e.clientX,e.clientY);e.preventDefault();});
    window.addEventListener('mouseup',()=>{if(scratching&&!cell.dataset.revealed)gtReveal(cell,i,canvas);scratching=false;});
    canvas.addEventListener('touchstart',e=>{scratching=true;scratchAt(e.touches[0].clientX,e.touches[0].clientY);e.preventDefault();},{passive:false});
    canvas.addEventListener('touchmove',e=>{if(!scratching)return;scratchAt(e.touches[0].clientX,e.touches[0].clientY);e.preventDefault();},{passive:false});
    canvas.addEventListener('touchend',()=>{if(scratching&&!cell.dataset.revealed)gtReveal(cell,i,canvas);scratching=false;});
  }

  function gtReveal(cell,idx,canvas){
    if(cell.dataset.revealed) return;
    cell.dataset.revealed='1';
    canvas.style.opacity='0'; canvas.style.transition='opacity .35s ease'; canvas.style.pointerEvents='none';
    const data=cellsData[idx];
    const dot=dotsRow.querySelector(`[data-di="${idx}"]`);
    gtScratched++;
    if(data.type==='bomb'){
      if(dot){dot.style.background='#f87171';dot.style.boxShadow='0 0 6px rgba(248,113,113,.7)';}
      gtOver=true;
      Array.from(grid.children).forEach(c=>{
        if(!c.dataset.revealed){c.dataset.revealed='1';const cv=c.querySelector('canvas');if(cv){cv.style.opacity='0';cv.style.pointerEvents='none';}}
      });
      gtUpdateUI();
      setTimeout(()=>gtShowResult(false,0),600);
    } else {
      gtPoints+=data.value;
      if(dot){dot.style.background='#f0c419';dot.style.boxShadow='0 0 6px rgba(240,196,25,.7)';}
      gtUpdateUI();
      if(gtScratched>=GOLD_GRID) setTimeout(()=>gtCashOut(true),500);
    }
  }

  window.gtCashOut=function(auto){
    if(gtOver||gtPoints<=0) return;
    gtOver=true; gtUpdateUI();
    gtShowResult(true,gtPoints,auto);
  };

  function gtShowResult(win,pts,auto){
    const ro=$id('gtResultOverlay'); if(!ro) return;
    ro.style.display='flex';
    if(win) playSound('victory');
    else playSound('scratch_bomb');
    ro.innerHTML=`
    <div style="background:linear-gradient(180deg,#3a2a00,#1a1200);border-radius:0;padding:30px 26px;text-align:center;max-width:300px;width:90%;box-shadow:0 0 0 2px #f0c419,0 30px 60px -10px rgba(0,0,0,.9);animation:popIn .3s cubic-bezier(.2,1.4,.4,1)">
      <style>@keyframes popIn{0%{transform:scale(.7);opacity:0}100%{transform:scale(1);opacity:1}}</style>
      <span style="font-size:54px;display:block;margin-bottom:10px">${win?(auto?'🏆':'💰'):'❌'}</span>
      <h2 style="font-family:'Bebas Neue',Impact,sans-serif;font-size:26px;letter-spacing:1px;color:${win?'#f0c419':'#f87171'};margin-bottom:6px">${win?tk('ticket.result_win_auto'):tk('ticket.result_lose')}</h2>
      <p style="font-size:12px;color:rgba(240,196,25,.7);line-height:1.5;margin-bottom:12px">${win?tk('ticket.golden_win_msg'):tk('ticket.golden_lose_msg')}</p>
      <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:34px;color:${win?'#f0c419':'#f87171'};margin-bottom:18px">${(win && pts>0)?'+'+pts+' PTS':win?'0 PTS':''}</div>
      <button onclick="gtClose(${win?pts:0})" style="width:100%;border:none;border-radius:0;padding:12px;font-family:'Bebas Neue',Impact,sans-serif;font-size:15px;letter-spacing:1.5px;background:linear-gradient(180deg,#ffe27a,#f0c419 55%,#c9960c);color:#08160d;cursor:pointer;">${tk('ticket.close')}</button>
    </div>`;
  }

  window.gtClose=async function(ptsEarned){
    // Guardar puntos directamente (no consume boleto acumulado)
    if(ptsEarned>0&&window._fbAuth&&window._fbAuth.currentUser){
      try{
        const user=window._fbAuth.currentUser;
        const snap=await window._fbDb.collection('users').doc(user.uid).get();
        const d=snap.exists?snap.data():{};
        const newPts=(d.scratchPoints||0)+ptsEarned;
        const newEarned=(d.scratchPointsEarned||0)+ptsEarned;
        if(ptsEarned>0) showGoatPointsBadge();
        await window._fbDb.collection('users').doc(user.uid).set({scratchPoints:newPts,scratchPointsEarned:newEarned},{merge:true});
        const pse=$id('pstat-scratch-pts'); if(pse) pse.textContent=newPts;
      }catch(e){console.warn('Error guardando pts golden ticket:',e);}
    }
    const w=$id('goldenTicketWrap'); if(w) w.remove();
    // Recargar para nueva partida
    setTimeout(()=>location.reload(), 400);
  };
}


/* ========= MORALE SYSTEM ========= */
function clampMorale(v){ return Math.max(-50, Math.min(50, v)); }
function changeMorale(delta){
  teamMorale=clampMorale(teamMorale+delta);
  renderMorale();
  updateLed();
}
function renderMorale(){
  const section=document.getElementById("moraleSection");
  const valEl=document.getElementById("moraleValue");
  const fill=document.getElementById("moraleFill");
  if(!section||!valEl||!fill) return;
  section.style.display="block";
  valEl.textContent=(teamMorale>0?"+":"")+teamMorale;
  const pct=Math.abs(teamMorale)/50*50; // 0-50% width
  fill.style.width=pct+"%";
  fill.style.height="100%";
  if(teamMorale>=0){
    fill.classList.add("positive"); fill.classList.remove("negative");
    fill.style.left="50%";
  } else {
    fill.classList.add("negative"); fill.classList.remove("positive");
    fill.style.left=(50-pct)+"%";
  }
}
function moraleLambdaBonus(){
  // Morale gives up to ±0.15 on the scoring lambda
  return (teamMorale/50)*0.15;
}

/* ========= WEATHER SYSTEM ========= */
function rollWeather(){
  // Cloudy is more common (neutral), others less so
  const weights=[1.5, 4, 2, 1.5, 1]; // hot,cloudy,rain,wind,hot_extreme
  // Actually use WEATHER_TYPES indices
  const w=[2,2,1,1.5,1]; // probabilities matching WEATHER_TYPES order
  const total=w.reduce((a,b)=>a+b,0);
  let r=Math.random()*total;
  for(let i=0;i<WEATHER_TYPES.length;i++){
    r-=w[i]; if(r<=0){ currentWeather=WEATHER_TYPES[i]; return; }
  }
  currentWeather=WEATHER_TYPES[1]; // fallback cloudy
}
function renderWeather(){
  const el=document.getElementById("weatherDisplay");
  if(!el||!currentWeather) return;
  el.style.display="flex";
  el.innerHTML=`
    <span class="weather-icon">${currentWeather.label.split(' ')[0]}</span>
    <div class="weather-block">
      <span>${currentWeather.label.slice(currentWeather.label.indexOf(' ')+1)}</span>
      <span class="weather-desc">${currentWeather.desc}</span>
    </div>`;
}
function weatherStatModifier(){
  // Returns a delta to apply to myStatProfile and oppStatProfile
  // Weather affects both teams equally (fair)
  if(!currentWeather) return {};
  return currentWeather.effect;
}
function weatherLambdaEffect(){
  // Converts stat modifiers to a lambda delta (small effect)
  const eff=weatherStatModifier();
  let delta=0;
  if(eff.pace) delta+=eff.pace*0.3;
  if(eff.technique) delta+=eff.technique*0.2;
  if(eff.passing) delta+=eff.passing*0.15;
  if(eff.defense) delta+=eff.defense*0.15;
  return delta; // applied to BOTH lambdas equally (same conditions)
}

/* ========= SCORER STREAK SYSTEM ========= */
const MAX_STREAK_BONUS = 3;
function getStreakLambdaBonus(){
  // Sum bonus from all attackers currently in squad
  let bonus=0;
  usedPlayers.forEach(p=>{
    if(p.placedPos&&["DC","EI","ED","MC"].includes(p.placedPos)){
      const streak=scorerStreaks[p.name]||0;
      bonus+=Math.min(streak,MAX_STREAK_BONUS)*0.015; // +1.5% per streak level
    }
  });
  return bonus;
}
function updateScorerStreaks(scorerNames){
  const scorerSet=new Set(scorerNames);
  usedPlayers.forEach(p=>{
    if(!["DC","EI","ED","MC"].includes(p.placedPos)) return; // only track attackers/mids
    if(scorerSet.has(p.name)){
      scorerStreaks[p.name]=(scorerStreaks[p.name]||0)+1;
    } else {
      scorerStreaks[p.name]=0; // reset if didn't score
    }
  });
}
function getStreakBadge(playerName){
  const s=scorerStreaks[playerName]||0;
  if(s<=0) return "";
  const fire="🔥".repeat(Math.min(s,MAX_STREAK_BONUS));
  return `<span class="streak-badge" title="Racha Goleadora">${fire}+${Math.min(s,MAX_STREAK_BONUS)}</span>`;
}
function getCardBadge(p){
  // Shows the player's active card status: a single yellow on file (not
  // yet suspended), or an active suspension (yellow2/double_yellow/red).
  if(p.suspended){
    return `<span class="card-badge card-badge-suspended" title="Sancionado este partido">🚫</span>`;
  }
  if((p.yellowCount||0)>=1){
    return `<span class="card-badge card-badge-yellow" title="Tarjeta amarilla acumulada">🟨</span>`;
  }
  return "";
}

/* ========= PRE-MATCH PREDICTIVE PRESS CONFERENCE ========= */
let pendingPrediction=null; // {event, answerIdx} set when player answers, resolved after the match

function maybeShowPressConference(callback){
  const chance=stage==="knockout"?0.40:0.25;
  if(Math.random()>chance){ callback(); return; }
  const event=getPressEvents()[Math.floor(Math.random()*getPressEvents().length)];
  showPressEventModal(event, callback);
}
function showPressEventModal(event, callback){
  document.getElementById("matchOverlay").innerHTML=`
  <div class="press-modal">
    <span class="press-icon">🎙</span>
    <h3>${window.t?window.t('press.title_full'):'RUEDA DE PRENSA · ANTES DEL PARTIDO'}</h3>
    <p class="press-question">${event.q}</p>
    <div class="press-answers">
      ${event.answers.map((a,i)=>`
        <button class="press-answer-btn" onclick="choosePressAnswer(${i})">
          <span>${a.text}</span>
          <span class="press-answer-label">${a.label}</span>
        </button>`).join('')}
    </div>
    <div class="press-timer-track"><div class="press-timer-fill" id="pressTimerFill"></div></div>
  </div>`;
  window._pressCallback=callback;
  window._pressEvent=event;
  window._pressAnswered=false;

  // 8-second countdown — if the player doesn't answer in time, the press
  // conference closes as if it never happened: no prediction is stored,
  // so the result later carries no morale effect at all.
  const DURATION=8000;
  const fill=document.getElementById("pressTimerFill");
  // Aviso sonoro en los últimos 5 segundos, igual que el resto de
  // cuentas atrás del juego — se cancela si ya se respondió.
  window._pressBeepTimers=(window._pressBeepTimers||[]).map(id=>{clearTimeout(id);});
  window._pressBeepTimers=[5,4,3,2,1].map(secLeft=>setTimeout(()=>{
    if(window._pressAnswered) return;
    checkCountdownBeep(secLeft, 'pressConference');
  }, DURATION-secLeft*1000));
  if(fill){
    // Force the browser to paint the initial width:100% state BEFORE
    // starting the transition — a single requestAnimationFrame can fire
    // before the first paint on slower devices (common on mobile), which
    // skips the animation entirely and makes the bar invisible. Double
    // rAF guarantees one full paint cycle has happened first.
    fill.style.transition="none";
    fill.style.width="100%";
    requestAnimationFrame(()=>{
      requestAnimationFrame(()=>{
        fill.style.transition=`width ${DURATION}ms linear`;
        fill.style.width="0%";
      });
    });
  }
  window._pressTimerId=setTimeout(()=>{
    if(window._pressAnswered) return;
    window._pressAnswered=true;
    document.getElementById("matchOverlay").innerHTML="";
    pendingPrediction=null; // no answer given — no prediction to resolve later
    showToast(window.t?window.t('press.timeout'):'No respondiste a tiempo — la prensa se queda sin declaraciones.', "toast-neutral");
    if(window._pressCallback) window._pressCallback();
  }, DURATION);
}
window.choosePressAnswer=function(idx){
  if(window._pressAnswered) return; // already timed out or answered
  window._pressAnswered=true;
  if(window._pressTimerId){ clearTimeout(window._pressTimerId); window._pressTimerId=null; }
  const event=window._pressEvent;
  const answer=event.answers[idx];
  document.getElementById("matchOverlay").innerHTML="";
  // Store the prediction — it will be checked against the real result
  // once this match is played, and resolved in the match result modal.
  pendingPrediction={event, answer};
  showToast(`${window.t?window.t('press.promise_made'):'Promesa hecha'}: "${answer.label}"`, "toast-neutral");
  setTimeout(()=>{ if(window._pressCallback) window._pressCallback(); }, 700);
};

/* Resolves the pending prediction against the real match result.
   Returns {label, text, delta} for display, or null if there was no
   pending prediction for this match. */
function resolvePendingPrediction(matchResult){
  if(!pendingPrediction) return null;
  const {event, answer}=pendingPrediction;
  pendingPrediction=null; // consume it — one prediction per match

  if(answer.stance==="neutral"){
    return {label:answer.label, outcome:"neutral", delta:0,
      text:window.t?window.t('press.resolved_neutral'):'🎙 Respuesta neutral: la moral no se ve afectada.'};
  }
  const correct=answer.check(matchResult);
  if(correct===true){
    const delta=8;
    changeMorale(delta);
    return {label:answer.label, outcome:"correct", delta,
      text:(window.t?window.t('press.resolved_correct'):'🎙 Promesa cumplida ("{0}"): +{1} moral.').replace('{0}',answer.label).replace('{1}',delta)};
  } else {
    const delta=-8;
    changeMorale(delta);
    return {label:answer.label, outcome:"wrong", delta,
      text:(window.t?window.t('press.resolved_wrong'):'🎙 Promesa incumplida ("{0}"): {1} moral.').replace('{0}',answer.label).replace('{1}',delta)};
  }
}

/* ========= TOAST NOTIFICATION ========= */
function showToast(msg, cls){
  let t=document.getElementById("gameToast");
  if(!t){ t=document.createElement("div"); t.id="gameToast"; document.body.appendChild(t); }
  t.className="game-toast "+(cls||"");
  t.textContent=msg;
  t.style.opacity="1";
  clearTimeout(t._tid);
  t._tid=setTimeout(()=>{ t.style.opacity="0"; }, 2200);
}

/* ========= CHAIN RUN SYSTEM ========= */
function getChainSlots(){
  // Requiere haber llegado como mínimo a octavos para poder conservar jugadores.
  // El número de jugadores conservados depende del nivel de la mejora "Run Encadenada"
  // (mejoras > perfil), igual que el resto de mejoras: nivel 0 = 1 jugador, hasta nivel 5 = 6.
  if(bestRoundReached<1) return 0;
  return 1 + (window._upgradeCache.chain||0);
}
function showChainRunModal(){
  const slots=getChainSlots();
  if(slots<=0){ location.reload(); return; }
  const allPlayers=[...usedPlayers,...bench];
  document.getElementById("matchOverlay").innerHTML=`
  <div class="chain-modal">
    <h3>RUN ENCADENADA</h3>
    <p class="chain-subtitle">Has llegado a ${bestRoundReached>=3?"Semifinales":bestRoundReached>=2?"Cuartos de Final":"Octavos de Final"}. Puedes conservar <strong>${slots} jugador${slots>1?"es":""}</strong> para el siguiente intento. Elige sabiamente.</p>
    <div class="chain-player-grid" id="chainPlayerGrid">
      ${allPlayers.map((p,i)=>`
        <div class="chain-player-card" id="cpc_${i}" onclick="toggleChainPlayer(${i}, ${slots})">
          <div class="cpname">${p.name}</div>
          <div class="cprating">${p.rating||0}</div>
          <div class="cppos">${(p.positions||[]).join('/')}</div>
        </div>`).join('')}
    </div>
    <div class="chain-actions">
      <button class="modal-btn" id="chainConfirmBtn" disabled onclick="confirmChainRun()">CONTINUAR CON ${slots} JUGADOR${slots>1?"ES":""}</button>
      <button class="modal-btn danger" onclick="location.reload()">NUEVA PARTIDA</button>
    </div>
  </div>`;
  window._chainSelected=[];
  window._chainPlayers=allPlayers;
  window._chainSlots=slots;
}
window.toggleChainPlayer=function(idx, slots){
  const sel=window._chainSelected;
  const card=document.getElementById("cpc_"+idx);
  const alreadyIdx=sel.indexOf(idx);
  if(alreadyIdx>=0){
    sel.splice(alreadyIdx,1);
    card.classList.remove("selected");
    card.querySelector(".chain-selected-mark")?.remove();
  } else {
    if(sel.length>=slots) return;
    sel.push(idx);
    card.classList.add("selected");
    const mark=document.createElement("div");
    mark.className="chain-selected-mark"; mark.textContent=sel.length;
    card.appendChild(mark);
  }
  const btn=document.getElementById("chainConfirmBtn");
  if(btn) btn.disabled=sel.length!==slots;
};
window.confirmChainRun=function(){
  const selected=window._chainSelected.map(i=>window._chainPlayers[i]);
  // Save full player objects so the next run can pre-place them, plus the
  // formation that was used — the new run will suggest the same one.
  try{
    sessionStorage.setItem('g2g_inherited', JSON.stringify(selected));
    sessionStorage.setItem('g2g_inherited_formation', JSON.stringify(currentFormation));
  }catch(e){}
  location.reload();
};
function restoreInheritedFormation(){
  // Restore the formation used in the previous run, if this is a chain
  // run continuation — called BEFORE the initial pitch render, so the
  // correct formation shows from the very first frame.
  try{
    const rawF=sessionStorage.getItem('g2g_inherited_formation');
    if(rawF){
      const savedFormation=JSON.parse(rawF);
      if(savedFormation && savedFormation.category && savedFormation.code){
        const f=FORMATIONS[savedFormation.category]?.find(x=>x.code===savedFormation.code);
        if(f){
          currentFormation={category:savedFormation.category, code:savedFormation.code};
          return f.bonus;
        }
      }
    }
  }catch(e){}
  return null;
}
function loadInheritedPlayers(){
  try{
    const raw=sessionStorage.getItem('g2g_inherited');
    if(!raw){ inheritedPlayers=[]; return; }
    inheritedPlayers=JSON.parse(raw);
    sessionStorage.removeItem('g2g_inherited');
  }catch(e){ inheritedPlayers=[]; }
  try{ sessionStorage.removeItem('g2g_inherited_formation'); }catch(e){}
}
loadInheritedPlayers();

/* Si hay un duelo multijugador activo en sessionStorage, retomarlo.
   No interfiere con el modo un jugador si no hay duelo activo. */
initDuelModeFromSession();

/* If there are inherited players from a chain run, auto-place them on the
   pitch at their primary position, skipping that many draft picks. */
/* ========= SETTINGS DROPDOWN (header, shown only when logged out) ========= */
function toggleSettingsMenu(){
  const dd=document.getElementById("settingsDropdown");
  const btn=document.getElementById("settingsToggle");
  if(!dd||!btn) return;
  if(dd.classList.contains("open")){
    dd.classList.remove("open");
    return;
  }
  const rect=btn.getBoundingClientRect();
  dd.style.top=(rect.bottom+6)+"px";
  dd.style.right=(window.innerWidth-rect.right)+"px";
  dd.classList.add("open");
}
document.addEventListener("click", function(e){
  const menu=document.getElementById("settingsMenu");
  if(menu && !menu.contains(e.target)){
    const dd=document.getElementById("settingsDropdown");
    if(dd) dd.classList.remove("open");
  }
});

function applyInheritedPlayers(){
  if(!inheritedPlayers.length) return;
  const slots=getPitchSlots();

  // Process highest-rated players FIRST, so when two inherited players
  // compete for the same primary position, the better one gets it and
  // the other is reassigned sensibly (their own secondary position, or
  // a position they can actually play) — never an unrelated slot like
  // POR for an outfield player.
  const ordered=[...inheritedPlayers].sort((a,b)=>(b.rating||0)-(a.rating||0));

  ordered.forEach(p=>{
    const positions=p.positions||[];
    let slot=null;

    // 1) Try every position this player can actually play, in priority
    //    order (primary first, then secondary), picking the first free slot.
    for(const pos of positions){
      slot=slots.find(s=>!s.classList.contains('locked')&&s.dataset.label===pos);
      if(slot) break;
    }

    // 2) If none of the player's own positions are free, find the closest
    //    sensible alternative: prefer a slot in the same "zone" as their
    //    primary position (defense/midfield/attack), never goalkeeper for
    //    an outfield player and never an outfield slot for a keeper.
    if(!slot && positions.length){
      const ZONES={
        POR:['POR'],
        DFC:['DFC','LI','LD'], LI:['LI','DFC','LD'], LD:['LD','DFC','LI'],
        MC:['MC','EI','ED'], EI:['EI','MC','ED'], ED:['ED','MC','EI'],
        DC:['DC','EI','ED'],
      };
      const zone=ZONES[positions[0]]||[];
      for(const pos of zone){
        slot=slots.find(s=>!s.classList.contains('locked')&&s.dataset.label===pos);
        if(slot) break;
      }
    }

    // 3) Absolute last resort: any free slot that is NOT goalkeeper unless
    //    the player actually is a keeper, and not an outfield slot for a
    //    keeper either. This avoids the "Maradona en portería" bug.
    if(!slot){
      const isKeeper=positions.includes('POR');
      slot=slots.find(s=>!s.classList.contains('locked') &&
        (isKeeper ? s.dataset.label==='POR' : s.dataset.label!=='POR'));
    }
    if(!slot) return; // no sensible slot available at all — skip

    const label=slot.dataset.label;
    const inPos=positions.includes(label);
    const star=inPos&&positions[0]===label?' <span class="star">★</span>':'';
    const r=inPos?(p.rating||70):Math.round((p.rating||70)*0.85);
    p.placedPos=label;
    // Fresh start for a new chain run — fully rested, no carried-over injury/cards.
    const playerObj={...p, placedPos:label, fatigue:100, injury:null, suspended:false, suspendedNextMatch:false, yellowCount:0, cardStatus:null};
    slot._player=playerObj;
    slot.classList.add('locked');
    renderSlotContent(slot, playerObj, label, r, star);
    usedPlayers.push(playerObj); // same reference as slot._player
    draftedCount++;
  });
  updateDraftCounter();
  updateConvocadosTable();
  updateStats();
  // Show a toast so the player knows inherited players are ready
  showToast(`${inheritedPlayers.length} jugador${inheritedPlayers.length>1?'es':''}  heredado${inheritedPlayers.length>1?'s':''} colocado${inheritedPlayers.length>1?'s':''} en el campo`, 'toast-pos');
  inheritedPlayers=[];
}

/* ========= LED SCOREBOARD ========= */
function buildLedMessages(){
  const SEP = "   ·   ";
  const msgs = [];

  // Always: team name + OVR
  if(baseTeamOVR!==null){
    msgs.push(`🐐 ${myTeamName}  ${t('hud.ovr')||'NOTA'} ${baseTeamOVR}`);
  } else {
    msgs.push(`GOAL2GOAT  ·  ${t('hud.tagline')||'MONTA TU EQUIPO LEGENDARIO Y CONQUISTA EL MUNDIAL'}`);
  }

  // Stage info
  if(stage==="group" && groupOpponents.length){
    msgs.push(`${t("comp.groups")}  ·  ${t("comp.play_match")} ${groupMatchIdx+1}/3`);
  } else if(stage==="knockout"){
    msgs.push(`${(t('hud.knockout')||'ELIMINATORIAS').toUpperCase()}  ·  ${getRoundName(knockoutRound).toUpperCase()}`);
  }

  // Last match result
  const last = matchResults[matchResults.length-1];
  if(last){
    const res = last.won?"VICTORIA":last.draw?"EMPATE":"DERROTA";
    msgs.push(`${t('hud.last_match')||'ÚLTIMO PARTIDO'}  ${res}  vs ${getTeamName(last.rival).toUpperCase()}  ${last.score}`);
  }

  // Next opponent
  if(nextOpponent){
    msgs.push(`${t('hud.next_rival')||'PRÓXIMO RIVAL'}  ${getTeamName(nextOpponent.name).toUpperCase()}`);
  }

  // Injured players
  const injured = usedPlayers.filter(p=>p.injury);
  if(injured.length){
    msgs.push(`${t('hud.injured')||'LESIONADOS'}  ${injured.map(p=>`${p.name.split(' ')[0]} (${p.injury.remaining}P)`).join('  ')}`);
  }

  // Top scorer (player with most goals in match history — proxy: highest rated attacker)
  const attackers = usedPlayers.filter(p=>p.placedPos&&["DC","EI","ED"].includes(p.placedPos));
  if(attackers.length){
    const top = attackers.reduce((a,b)=>effRating(a)>=effRating(b)?a:b);
    msgs.push(`${t('hud.top_scorer')||'MÁXIMO GOLEADOR'}  ${top.name.toUpperCase()}  ★${effRating(top)}`);
  }

  // Morale
  if(baseTeamOVR!==null){
    const sign=teamMorale>=0?"+":"";
    msgs.push(`${t('hud.morale')||'MORAL'}  ${sign}${teamMorale}`);
  }

  // Weather
  if(currentWeather && currentWeather.id!=='cloudy'){
    msgs.push(`${t('hud.weather')||'CLIMA'}  ${currentWeather.label.replace(/[^\w\s]/g,'').trim().toUpperCase()}`);
  }

  // Scorer streaks
  const onStreak=usedPlayers.filter(p=>(scorerStreaks[p.name]||0)>0);
  if(onStreak.length){
    msgs.push(`${t('hud.streak')||'EN RACHA'}  ${onStreak.map(p=>`${p.name.split(' ')[0].toUpperCase()} x${scorerStreaks[p.name]}`).join('  ')}`);
  }

  return msgs.join(SEP + "   ");
}

function updateLed(){
  const el = document.getElementById("ledText");
  if(!el) return;
  el.textContent = buildLedMessages();
  // Reset animation so it restarts smoothly from the right
  el.style.animation="none";
  void el.offsetWidth; // reflow trigger
  el.style.animation="";
}

// Update LED whenever game state changes meaningfully
let _ledInterval = null;
function startLedLoop(){
  updateLed();
  if(_ledInterval) clearInterval(_ledInterval);
  _ledInterval = setInterval(updateLed, 8000);
}

/* ========= UTILS ========= */
// Augment teams with _styleKey for hint lookup
teams=teams.map(t=>{
  const raw=rawTeams.find(r=>r.name===t.name);
  return {...t,_styleKey:raw?raw.style:''};
});

/* ========= QUICK BUILD ========= */
(function setupQuickBuild(){
  const btn=document.getElementById("quickBuildWrap");
  if(!btn) return;
  btn.addEventListener("click",quickBuild);
})();

function quickBuild(){
  if(phase!=="draft"&&phase!=="bench") return;
  if(maybeShowMobileFormationGate(()=>quickBuild())) return; // pauses for confirmation on mobile, first time only
  // Lock the formation choice the moment quick-build is used, same as
  // manual drafting — the formation is no longer changeable from here on.
  if(phase==="draft"&&draftedCount===0) lockFormationDisplay();
  revealPreDraftBoxes();
  const btn=document.getElementById("quickBuildWrap");
  if(btn){ btn.disabled=true; btn.textContent=window.t?window.t('draft.generating_btn'):'Generando...'; }
  // Ocultar multijugador al empezar a jugar — solo visible en pantalla inicial
  const mpwQ=document.getElementById("multiplayerWrap");
  if(mpwQ) mpwQ.style.display="none";

  // Always show the spin animation in the center/pitch area, visible on both mobile and desktop
  // We overlay a temporary fullscreen-ish modal so scroll is irrelevant
  const spinOverlay=document.createElement("div");
  spinOverlay.id="quickBuildSpinOverlay";
  spinOverlay.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:9999;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px";
  spinOverlay.innerHTML=`
    <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:22px;letter-spacing:2px;color:#c9a227">${window.t?window.t('draft.generating'):'GENERANDO EQUIPO...'}</div>
    <div style="display:flex;gap:24px;align-items:center">
      <div id="reel1" style="font-size:56px;min-width:80px;text-align:center"></div>
      <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:28px;color:#555">VS</div>
      <div id="reel2" style="font-size:56px;min-width:80px;text-align:center"></div>
    </div>`;
  document.body.appendChild(spinOverlay);

  const pool=teams.slice();
  const r1=document.getElementById("reel1");
  const r2=document.getElementById("reel2");
  const spin=setInterval(()=>{
    const ta=pool[Math.floor(Math.random()*pool.length)];
    const tb=pool[Math.floor(Math.random()*pool.length)];
    if(r1) r1.innerHTML=flagEmoji(ta.name,56);
    if(r2) r2.innerHTML=flagEmoji(tb.name,56);
    playSound('spin');
  },80);

  setTimeout(()=>{
    clearInterval(spin);
    playSound('reveal');
    // Remove overlay
    const ov=document.getElementById("quickBuildSpinOverlay");
    if(ov) ov.remove();
    playerCardEl.innerHTML="";
    _executeQuickBuild();
    if(btn){ btn.style.display="none"; }
  }, 700);
}

function _executeQuickBuild(){
  // Simulate the REAL draft process: random team pairs → pick best team → pick best fitting player
  // This mirrors what an optimal player would do given the random draws they get
  const usedNames=new Set();
  const pickedTeamNames=new Set();
  const pitchSlots=getPitchSlots().filter(s=>!s.classList.contains("locked"));

  function drawTeamPair(){
    // Draw 2 random teams not already heavily used
    const pool=teams.filter(t=>!pickedTeamNames.has(t.name));
    shuffle(pool);
    return [pool[0], pool[1]||pool[0]];
  }
  function pickBestPlayer(teamPlayers, neededPos){
    // From 5 random players from a team, pick the best for the needed position
    const available=teamPlayers.filter(p=>!usedNames.has(p.name));
    if(!available.length) return null;
    shuffle(available);
    const hand=available.slice(0,5);
    // Score: primary position match = big bonus, secondary match = smaller, any = base rating
    hand.sort((a,b)=>{
      const scoreA=(a.positions&&a.positions[0]===neededPos?200:a.positions&&a.positions.includes(neededPos)?100:0)+(a.rating||70);
      const scoreB=(b.positions&&b.positions[0]===neededPos?200:b.positions&&b.positions.includes(neededPos)?100:0)+(b.rating||70);
      return scoreB-scoreA;
    });
    return hand[0];
  }

  // Fill each pitch slot
  pitchSlots.forEach(slot=>{
    const label=slot.dataset.label;
    const [t1,t2]=drawTeamPair();
    // Pick the team whose players better cover the needed position
    const t1best=pickBestPlayer(t1.players,label);
    const t2best=pickBestPlayer(t2.players,label);
    let chosenTeam, chosenPlayer;
    if(!t1best){ chosenTeam=t2; chosenPlayer=t2best; }
    else if(!t2best){ chosenTeam=t1; chosenPlayer=t1best; }
    else {
      const s1=(t1best.positions&&t1best.positions[0]===label?200:t1best.positions&&t1best.positions.includes(label)?100:0)+(t1best.rating||70);
      const s2=(t2best.positions&&t2best.positions[0]===label?200:t2best.positions&&t2best.positions.includes(label)?100:0)+(t2best.rating||70);
      chosenTeam=s1>=s2?t1:t2; chosenPlayer=s1>=s2?t1best:t2best;
    }
    if(!chosenPlayer) return;

    pickedTeamNames.add(chosenTeam.name);
    usedNames.add(chosenPlayer.name);
    applyBonuses({bonuses:chosenTeam.bonuses||{}});

    const inPos=chosenPlayer.positions&&chosenPlayer.positions.includes(label);
    const r=inPos?(chosenPlayer.rating||70):Math.round((chosenPlayer.rating||70)*0.85);
    const star=inPos&&chosenPlayer.positions[0]===label?' <span class="star">★</span>':'';
    const playerObj={...chosenPlayer, placedPos:label};
    slot._player=playerObj;
    slot.classList.add("locked");
    renderSlotContent(slot, playerObj, label, r, star);
    usedPlayers.push(playerObj);
    draftedCount++;
  });

  // Fill bench (3 players) — simulate 3 more draws
  const benchNeeded=getMaxBench()-bench.length;
  for(let i=0;i<benchNeeded;i++){
    const [t1,t2]=drawTeamPair();
    const pool1=t1.players.filter(p=>!usedNames.has(p.name));
    const pool2=t2.players.filter(p=>!usedNames.has(p.name));
    shuffle(pool1); shuffle(pool2);
    const hand=[...(pool1.slice(0,3)), ...(pool2.slice(0,3))];
    if(!hand.length) continue;
    hand.sort((a,b)=>(b.rating||70)-(a.rating||70));
    const best=hand[0];
    usedNames.add(best.name);
    bench.push({...best});
    benchCount++;
  }

  // Freeze OVR and transition to ready phase
  baseTeamOVR=computeTeamOVR();
  phase="ready";
  rollBtn.style.display="none";
  const tipsBox=document.getElementById("tipsBox");
  const howTo=document.getElementById("howToPlayBox");
  const statsGuide=document.getElementById("statsGuideBox");
  lockFormationDisplay();
  // Collapse (don't hide) the tutorial boxes — still consultable on
  // desktop once the squad is built, just compact at the bottom.
  if(tipsBox) tipsBox.classList.add("collapsed");
  if(howTo) howTo.classList.add("collapsed");
  if(statsGuide) statsGuide.classList.add("collapsed");

  updateDraftCounter();
  updateConvocadosTable();
  updateBenchTable();
  updateStats();
  refreshPitchRatings();
  document.getElementById("benchSection").style.display="block";
  startMatchPhase();
  startLedLoop();
  showToast("¡Equipo generado! OVR "+baseTeamOVR, "toast-pos");
}

/* ========= TOP BAR: AUDIO & THEME TOGGLES ========= */
// Two sets of buttons control the same preferences: one inside the
// profile modal (AJUSTES tab, for logged-in users) and one in the header
// (visible only when logged OUT — see the auth state listener below).
// Both are kept in sync on every interaction.
const audioToggleBtn=document.getElementById("audioToggle");
const themeToggleBtn=document.getElementById("themeToggle");
const audioToggleHeaderBtn=document.getElementById("audioToggleHeader");
const themeToggleHeaderBtn=document.getElementById("themeToggleHeader");
const audioToggleBtns=[audioToggleBtn, audioToggleHeaderBtn].filter(Boolean);
const themeToggleBtns=[themeToggleBtn, themeToggleHeaderBtn].filter(Boolean);

function syncAudioToggleUI(){
  audioToggleBtns.forEach(btn=>{
    btn.querySelector(".topbar-dot").classList.toggle("on",audioEnabled);
    btn.classList.toggle("off",!audioEnabled);
  });
}
function syncThemeToggleUI(isDark){
  themeToggleBtns.forEach(btn=>{
    btn.querySelector(".topbar-dot").classList.toggle("on",isDark);
    btn.querySelector(".topbar-label").textContent=isDark?"TEMA OSCURO":"TEMA CLARO";
  });
}

// Restore saved preferences on load
(function restorePrefs(){
  // Welcome popup: always show on load, salvo que haya un duelo multijugador activo
  try{
    const o=document.getElementById("welcomeOverlay");
    if(o && !window._duelId) o.style.display="flex";
  }catch(e){}
  syncAudioToggleUI();
  // Theme: dark is the default; only go light if explicitly saved as light
  let isDark=true;
  try{
    const saved=localStorage.getItem('darkTheme');
    if(saved==='false') isDark=false;
  }catch(e){}
  if(isDark) {
    document.body.classList.add("dark-theme");
    document.body.classList.remove("light-theme");
  } else {
    document.body.classList.remove("dark-theme");
    document.body.classList.add("light-theme");
  }
  document.documentElement.classList.remove('dark-theme-init');
  requestAnimationFrame(()=>requestAnimationFrame(()=>document.body.classList.add("theme-ready")));
  syncThemeToggleUI(isDark);
})();

audioToggleBtns.forEach(btn=>{
  btn.addEventListener("click",()=>{
    audioEnabled=!audioEnabled;
    syncAudioToggleUI();
    try{ localStorage.setItem('g2g_audioEnabled', audioEnabled); }catch(e){}
    if(audioEnabled) playSound('select');
  });
});
themeToggleBtns.forEach(btn=>{
  btn.addEventListener("click",()=>{
    const isDark=document.body.classList.toggle("dark-theme");
    if(isDark) document.body.classList.remove("light-theme");
    else document.body.classList.add("light-theme");
    syncThemeToggleUI(isDark);
    try{ localStorage.setItem('darkTheme', isDark); }catch(e){}
    playSound('select');
  });
});

// Apply inherited players from a chain run (runs after DOM is fully ready)
setTimeout(applyInheritedPlayers, 100);

/* ========= FIREBASE AUTH ========= */
function initFirebaseAuth(){
  if(typeof firebase==='undefined'){
    console.warn('Firebase not available - auth disabled');
    return;
  }
  const auth=firebase.auth();
  const db=firebase.firestore();
  window._fbAuth=auth;
  window._fbDb=db;

  /* ─── VALIDATION ─── */
  function vUsername(v){
    if(!v) return window.t?window.t('auth.err.username_required'):'Nombre de usuario obligatorio.';
    if(v.length<3) return window.t?window.t('auth.err.username_min'):'Mínimo 3 caracteres.';
    if(v.length>20) return window.t?window.t('auth.err.username_max'):'Máximo 20 caracteres.';
    if(!/^[a-zA-Z0-9_]+$/.test(v)) return window.t?window.t('auth.err.username_format'):'Solo letras, números y _ (guión bajo).';
    return '';
  }
  function vEmail(v){
    if(!v) return window.t?window.t('auth.err.email_required'):'Correo obligatorio.';
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return window.t?window.t('auth.err.email_format'):'Formato de correo no válido.';
    return '';
  }
  function vPassword(v){
    if(!v) return window.t?window.t('auth.err.password_required'):'Contraseña obligatoria.';
    if(v.length<8) return window.t?window.t('auth.err.password_min'):'Mínimo 8 caracteres.';
    return '';
  }
  function $id(id){return document.getElementById(id);}
  window.$id=$id;
  function setErr(id,msg){
    const el=$id(id); if(!el) return;
    el.textContent=msg||""; el.style.display=msg?"block":"none";
  }
  function clearAll(){
    ["loginIdentifierErr","loginPasswordErr","loginGlobalErr",
     "regUsernameErr","regEmailErr","regPasswordErr","regPassword2Err","regGlobalErr"]
    .forEach(id=>setErr(id,""));
  }
  function setBtnLoading(id,loading){
    const btn=$id(id); if(!btn) return;
    btn.disabled=loading;
    btn.textContent=loading?(window.t?window.t('auth.loading'):'...'):(id==='loginSubmitBtn'?(window.t?window.t('auth.submit_login'):'ENTRAR'):(window.t?window.t('auth.submit_register'):'CREAR CUENTA'));
  }
  function fbErr(code){
    return({
      'auth/email-already-in-use': window.t?window.t('auth.fb.email_in_use'):'Este correo ya está registrado.',
      'auth/invalid-email':        window.t?window.t('auth.fb.invalid_email'):'Correo no válido.',
      'auth/weak-password':        window.t?window.t('auth.fb.weak_password'):'Contraseña demasiado débil.',
      'auth/user-not-found':       window.t?window.t('auth.fb.wrong_creds'):'Usuario o contraseña incorrectos.',
      'auth/wrong-password':       window.t?window.t('auth.fb.wrong_creds'):'Usuario o contraseña incorrectos.',
      'auth/invalid-credential':   window.t?window.t('auth.fb.wrong_creds'):'Usuario o contraseña incorrectos.',
      'auth/too-many-requests':    window.t?window.t('auth.fb.too_many'):'Demasiados intentos. Espera un momento.',
      'auth/network-request-failed':window.t?window.t('auth.fb.network'):'Sin conexión. Comprueba tu red.',
    })[code]||(window.t?window.t('auth.fb.unknown'):'Error inesperado. Inténtalo de nuevo.');
  }

  /* ─── MODAL ─── */
  window.showAuthModal=function(tab){
    const o=$id("authOverlay"); if(o) o.style.display="flex";
    window.switchAuthTab(tab||"login");
    clearAll();
  };
  window.closeAuthModal=function(){
    const o=$id("authOverlay"); if(o) o.style.display="none";
    clearAll();
  };
  window.switchAuthTab=function(tab){
    const login=$id("authLogin"), reg=$id("authRegister");
    const tl=$id("tabLogin"), tr=$id("tabRegister");
    if(login) login.style.display=tab==="login"?"block":"none";
    if(reg)   reg.style.display=tab==="register"?"block":"none";
    if(tl)    tl.classList.toggle("auth-tab-active",tab==="login");
    if(tr)    tr.classList.toggle("auth-tab-active",tab==="register");
  };

  /* ─── REGISTER ─── */
  window.submitRegister=async function(){
    const username=($id("regUsername")||{}).value?.trim()||"";
    const email=($id("regEmail")||{}).value?.trim()||"";
    const pass=($id("regPassword")||{}).value||"";
    const pass2=($id("regPassword2")||{}).value||"";
    const uErr=vUsername(username),eErr=vEmail(email),
          pErr=vPassword(pass),p2Err=pass!==pass2?(window.t?window.t('auth.err.password_match'):'Las contraseñas no coinciden.'):'';
    setErr('regUsernameErr',uErr); setErr('regEmailErr',eErr);
    setErr('regPasswordErr',pErr); setErr('regPassword2Err',p2Err);
    setErr('regGlobalErr','');
    if(uErr||eErr||pErr||p2Err) return;
    setBtnLoading('regSubmitBtn',true);
    try{
      const snap=await db.collection('users').where('username_lower','==',username.toLowerCase()).get();
      if(!snap.empty){setErr('regUsernameErr',window.t?window.t('auth.err.username_taken'):'Este nombre de usuario ya está en uso.');setBtnLoading('regSubmitBtn',false);return;}
      const cred=await auth.createUserWithEmailAndPassword(email,pass);
      await db.collection('users').doc(cred.user.uid).set({
        username,username_lower:username.toLowerCase(),email,
        createdAt:new Date().toISOString(),
        ticketCount:1, ticketLastRegen:Date.now(), scratchPoints:0, scratchPointsEarned:0, scratchPointsSpent:0,
        stats:{gamesPlayed:0,wins:0,draws:0,losses:0,goalsFor:0,goalsAgainst:0,bestScore:0,titles:0}
      });
      if(window._initTicketSystem) window._initTicketSystem(cred.user, true);
      window.closeAuthModal();
    }catch(err){
      console.error('Firebase register error:', err.code, err.message);
      setErr("regGlobalErr",fbErr(err.code));
      setBtnLoading("regSubmitBtn",false);
    }
  };

  /* ─── LOGIN ─── */
  window.submitLogin=async function(){
    const identifier=($id("loginIdentifier")||{}).value?.trim()||"";
    const pass=($id("loginPassword")||{}).value||"";
    setErr('loginIdentifierErr',''); setErr('loginPasswordErr',''); setErr('loginGlobalErr','');
    if(!identifier){setErr('loginIdentifierErr',window.t?window.t('auth.err.field_required'):'Campo obligatorio.');return;}
    if(!pass){setErr('loginPasswordErr',window.t?window.t('auth.err.field_required'):'Campo obligatorio.');return;}
    setBtnLoading('loginSubmitBtn',true);
    try{
      let email=identifier;
      if(!identifier.includes('@')){
        const snap=await db.collection('users').where('username_lower','==',identifier.toLowerCase()).get();
        if(snap.empty){setErr('loginIdentifierErr',window.t?window.t('auth.err.user_not_found'):'Usuario no encontrado.');setBtnLoading('loginSubmitBtn',false);return;}
        email=snap.docs[0].data().email;
      }
      await auth.signInWithEmailAndPassword(email,pass);
      window.closeAuthModal();
    }catch(err){setErr('loginGlobalErr',fbErr(err.code));setBtnLoading('loginSubmitBtn',false);}
  };

  /* ─── RECUPERAR CONTRASEÑA ─── */
  window.submitPasswordReset=async function(){
    const identifier=($id("loginIdentifier")||{}).value?.trim()||"";
    setErr('loginIdentifierErr',''); setErr('loginGlobalErr','');
    const msgEl=$id('loginResetMsg'); if(msgEl){ msgEl.style.display='none'; msgEl.textContent=''; }
    if(!identifier){
      setErr('loginIdentifierErr', window.t?window.t('auth.err.reset_need_identifier'):'Escribe tu usuario o email arriba para recuperar la contraseña.');
      return;
    }
    const link=$id('forgotPasswordLink');
    const originalText=link?link.textContent:'';
    if(link) link.textContent=window.t?window.t('auth.sending'):'Enviando...';
    try{
      let email=identifier;
      if(!identifier.includes('@')){
        const snap=await db.collection('users').where('username_lower','==',identifier.toLowerCase()).get();
        if(snap.empty){
          setErr('loginIdentifierErr', window.t?window.t('auth.err.user_not_found'):'Usuario no encontrado.');
          if(link) link.textContent=originalText;
          return;
        }
        email=snap.docs[0].data().email;
      }
      await auth.sendPasswordResetEmail(email);
      if(msgEl){
        msgEl.textContent=window.t?window.t('auth.reset_sent'):'Te hemos enviado un correo para restablecer tu contraseña.';
        msgEl.style.display='block';
      }
    }catch(err){
      setErr('loginGlobalErr', fbErr(err.code));
    }finally{
      if(link) link.textContent=originalText;
    }
  };

  /* ─── LOGOUT ─── */
  window.authLogout=async function(){await auth.signOut();};

  /* ─── AUTH STATE ─── */
  auth.onAuthStateChanged(async user=>{
    const authBtn=$id("authBtn");
    const profileBtn=$id("profileBtn");
    const settingsMenu=$id("settingsMenu");
    if(user){
      const snap=await db.collection("users").doc(user.uid).get();
      const username=snap.exists?snap.data().username:user.email;
      if(authBtn)    authBtn.style.display="none";
      if(profileBtn){
        profileBtn.style.display="";
        const lbl=profileBtn.querySelector('#profileUsernameLabel');
        if(lbl) lbl.textContent=username;
        // Restaurar badge si existe
        const badge=profileBtn.querySelector('#profileGoatBadge');
        if(badge) profileBtn.appendChild(badge);
      }
      if(settingsMenu) settingsMenu.style.display="none";
      // Botón multijugador: visible para cualquier usuario con sesión iniciada,
      // salvo que haya un duelo activo (se oculta hasta que termine)
      const mpWrap=$id('multiplayerWrap');
      if(mpWrap) mpWrap.style.display=window._duelId?'none':'flex';
      // Mostrar botón de tickets en desktop
      const hBtn=$id("headerTicketBtn"); if(hBtn) hBtn.style.display="";
      const pun=$id("profileUsername"); if(pun) pun.textContent=username;
      window.currentUsername=username;
      const data=snap.exists?snap.data():{};
      window.preferredTeamName=data.preferredTeamName||"";
      window.useFixedTeamName=!!data.useFixedTeamName;
      // Sincronizar nombre del equipo para el contador de convocados
      if(window.preferredTeamName) window._currentTeamName=window.preferredTeamName.toUpperCase();
      // Si el draft ya llegó a 11/11 antes de que esto resolviera, repintar
      // el título para que muestre el nombre de equipo en vez del genérico.
      if(typeof updateDraftCounter==='function') updateDraftCounter();
      // Cargar idioma guardado
      if(data.lang && (data.lang==='es'||data.lang==='en')){
        window.LANG=data.lang;
        try{localStorage.setItem('g2g_lang',data.lang);}catch(e){}
      }
      if(window.applyTranslations) window.applyTranslations();
      // Inicializar sistema de boletos
      if(window._initTicketSystem) window._initTicketSystem(user, false);
      // Listener en tiempo real de mejoras
      startUpgradeListener(user.uid);
      // Listener de habilidades
      startSkillListener(user.uid);
      // Listener de logros
      startAchievementsListener(user.uid);
      // Vigilante de duelos salientes (detecta cuando el rival acepta)
      startDuelWatcher(user.uid);
      startMpNotificationListener(user.uid);
    }else{
      if(authBtn)    authBtn.style.display="";
      if(profileBtn) profileBtn.style.display="none";
      if(settingsMenu) settingsMenu.style.display="";
      const hBtn=$id("headerTicketBtn"); if(hBtn) hBtn.style.display="none";
      const mpWrap=$id('multiplayerWrap'); if(mpWrap) mpWrap.style.display='none';
      // Limpiar cache de mejoras al cerrar sesión
      stopUpgradeListener();
      stopDuelWatcher();
      stopMpNotificationListener();
      window.currentUsername=null;
      window.preferredTeamName="";
      window.useFixedTeamName=false;
      // Sin sesión: mensaje diferenciado en el welcome overlay
      const wt=$id('welcomeText');
      const wrb=$id('welcomeRegisterBtn');
      if(wt) wt.innerHTML=window.t?window.t('welcome.text_guest'):'Bienvenido a <strong style="color:var(--gold)">Goal2Goat</strong>, <strong style="color:var(--gold)">REGÍSTRATE</strong> para guardar tu progreso y tener acceso a contenido exclusivo.<br><br>Goal2Goat es un manager de fútbol con alma de roguelike. Tu apoyo nos ayuda a seguir mejorando el juego, añadiendo contenido nuevo y manteniéndolo libre de publicidad invasiva.';
      if(wrb){
        wrb.style.display='block';
        wrb.textContent=window.t?window.t('welcome.register'):'REGÍSTRATE';
        wrb.onclick=()=>{
          const wo=$id("welcomeOverlay"); if(wo) wo.style.display="none";
          window.showAuthModal&&window.showAuthModal('register');
        };
      }
      updateTicketBadge(0);
    }
  });

  /* ─── PROFILE MODAL ─── */
  window.showProfileModal=async function(){
    const o=$id("profileOverlay"); if(o) o.style.display="flex";
    const user=auth.currentUser;
    if(!user) return;
    // Show loading state
    ["pstat-games","pstat-wins","pstat-draws","pstat-losses",
     "pstat-gf","pstat-ga","pstat-best","pstat-titles"]
    .forEach(id=>{ const el=$id(id); if(el) el.textContent="..."; });
    try{
      const snap=await db.collection("users").doc(user.uid).get();
      if(!snap.exists) return;
      const s=snap.data().stats||{};
      // If missing fields (old account), patch them silently
      const needsPatch=s.draws===undefined||s.losses===undefined||s.goalsFor===undefined;
      if(needsPatch){
        await db.collection("users").doc(user.uid).update({
          "stats.draws":s.draws||0,"stats.losses":s.losses||0,
          "stats.goalsFor":s.goalsFor||0,"stats.goalsAgainst":s.goalsAgainst||0,
          "stats.titles":s.titles||0
        });
      }
      // Self-heal: reconcile bestScore against this user's actual run history,
      // in case an old race condition left a stale (too low) bestScore stored.
      let displayBest=s.bestScore||0;
      try{
        const myScoresSnap=await db.collection("scores").where("uid","==",user.uid).get();
        let actualBest=0;
        myScoresSnap.forEach(d=>{ const sc=d.data().score||0; if(sc>actualBest) actualBest=sc; });
        if(actualBest>displayBest){
          displayBest=actualBest;
          await db.collection("users").doc(user.uid).set({stats:{bestScore:actualBest}},{merge:true});
          console.log("Reconciled bestScore:", actualBest);
        }
      }catch(e){ console.warn("bestScore reconciliation skipped:", e.code); }
      const n=(v)=>v||0;
      const set=(id,v)=>{ const el=$id(id); if(el) el.textContent=n(v); };
      set("pstat-games",  s.gamesPlayed);
      set("pstat-wins",   s.wins);
      set("pstat-draws",  s.draws);
      set("pstat-losses", s.losses);
      set("pstat-gf",     s.goalsFor);
      set("pstat-ga",     s.goalsAgainst);
      set("pstat-best",   displayBest);
      set("pstat-titles", s.titles);
      // Puntos rasca y gana
      const spEl=$id("pstat-scratch-pts");
      if(spEl) spEl.textContent=snap.data().scratchPoints||0;

      // Load team-name preference (USUARIO tab)
      const data=snap.data();
      const nameInp=$id("preferredTeamNameInput");
      const checkbox=$id("useFixedTeamNameCheckbox");
      if(nameInp)  nameInp.value=data.preferredTeamName||"";
      if(checkbox) checkbox.checked=!!data.useFixedTeamName;
      // Cheats: solo visible y funcional para tiopops (jesuslor85@gmail.com)
      const cheatsSection=$id("cheatsSection");
      const isCheatUser=CHEAT_USERS.includes((data.email||'').toLowerCase());
      if(cheatsSection) cheatsSection.style.display=isCheatUser?"block":"none";
      if(isCheatUser){
        // Clonar para eliminar listeners previos acumulados
        const oldCb=$id("cheatsCheckbox");
        if(oldCb){
          const newCb=oldCb.cloneNode(true);
          oldCb.parentNode.replaceChild(newCb, oldCb);
          newCb.checked=!!window.CHEATS_ACTIVE;
          newCb.addEventListener('change',function(){
            window.CHEATS_ACTIVE=this.checked;
            updateTicketBadge(window.CHEATS_ACTIVE?3:undefined);
            // Mostrar selector de idioma solo con cheats activos
            // langSelectorWrap is always visible (removed cheats gate)
            if(window.CHEATS_ACTIVE){const pse=$id('pstat-scratch-pts');if(pse)pse.textContent=100;}
            // Botón multijugador: visible con sesión iniciada, salvo duelo activo
            const mpWrap=$id('multiplayerWrap');
            if(mpWrap) mpWrap.style.display=(auth.currentUser&&!window._duelId)?'flex':'none';
            showToast(window.CHEATS_ACTIVE?"⚙️ Cheats ON — ganas todos, tickets 3/3, pts 100":"⚙️ Cheats OFF — juego normal","toast-pos");
          });
        }
      }
    }catch(e){
      console.warn("Stats load error:", e);
      ["pstat-games","pstat-wins","pstat-draws","pstat-losses",
       "pstat-gf","pstat-ga","pstat-best","pstat-titles"]
      .forEach(id=>{ const el=$id(id); if(el) el.textContent="—"; });
    }
  };
  window.closeProfileModal=function(){
    const o=$id("profileOverlay"); if(o) o.style.display="none";
  };

  // Save the team-name preference (preferredTeamName + useFixedTeamName).
  // Auto-saves on checkbox toggle / input blur — no separate button needed.
  window.saveTeamNamePreference=async function(silent){
    const user=auth.currentUser; if(!user) return;
    const nameInp=$id("preferredTeamNameInput");
    const checkbox=$id("useFixedTeamNameCheckbox");
    const preferredTeamName=(nameInp?nameInp.value.trim():"").toUpperCase();
    window._currentTeamName=preferredTeamName||myTeamName||'MI EQUIPO';
    const useFixedTeamName=!!(checkbox&&checkbox.checked);
    if(useFixedTeamName&&!preferredTeamName){
      if(checkbox) checkbox.checked=false; // can't activate without a name
      showToast("Escribe un nombre de equipo antes de activar la opción.", "toast-neg");
      return;
    }
    try{
      await db.collection("users").doc(user.uid).set({
        preferredTeamName, useFixedTeamName
      },{merge:true});
      // CRITICAL: also update the live global variables — showTeamNameModal
      // reads these directly, and they're otherwise only set once at login.
      window.preferredTeamName=preferredTeamName;
      window.useFixedTeamName=useFixedTeamName;
      if(!silent) showToast(useFixedTeamName?"Nombre fijo activado.":"Preferencia guardada.", "toast-pos");
    }catch(e){
      console.warn("saveTeamNamePreference error:", e);
      showToast("No se pudo guardar la preferencia.", "toast-neg");
    }
  };

  window.switchProfileTab=function(tab){
    const tabs={
      stats:        {btn:$id("profileTabStats"),        pane:$id("profileStatsPane")},
      user:         {btn:$id("profileTabUser"),         pane:$id("profileUserPane")},
      upgrades:     {btn:$id("profileTabUpgrades"),     pane:$id("profileUpgradesPane")},
      notes:        {btn:$id("profileTabNotes"),        pane:$id("profileNotesPane")},
      achievements: {btn:$id("profileTabAchievements"), pane:$id("profileAchievementsPane")},
    };
    Object.entries(tabs).forEach(([key,{btn,pane}])=>{
      const active=(key===tab);
      btn?.classList.toggle("auth-tab-active", active);
      pane?.classList.toggle("profile-tab-pane-active", active);
    });
    if(tab==='upgrades'){ renderUpgradesTab(); hideGoatPointsBadge(); }
    if(tab==='notes'){ renderSkillsTab(); const sb=$id('skillsBadge'); if(sb) sb.style.display='none'; }
    if(tab==='achievements'){
      renderAchievementsTab();
      const ab=$id('achievementsBadge');
      if(ab) ab.style.display='none';
      try{localStorage.removeItem('_g2g_ach_pending');}catch(e){}
    }
  };

  // Save match result to Firestore
  window.saveMatchStat=async function(won, draw, goalsFor, goalsAgainst){
    // Logros por partido
    unlockAchievement('first_match');
    if(won) unlockAchievement('first_win');
    if(goalsFor>=5) unlockAchievement('score_5');
    if(goalsFor>=7) unlockAchievement('score_7');
    if(goalsAgainst===0&&won) unlockAchievement('clean_sheet');
    // Hat-trick: detectar si algún scorer marcó 3+ (usando lastMatchScorers)
    if(typeof generateMatchSummary._scorers!=='undefined'){
      const scorerCounts={};
      (generateMatchSummary._scorers||[]).forEach(n=>{ scorerCounts[n]=(scorerCounts[n]||0)+1; });
      if(Object.values(scorerCounts).some(c=>c>=3)) unlockAchievement('hattrick_player');
    }
    const user=auth.currentUser; if(!user) return;
    try{
      const inc=firebase.firestore.FieldValue.increment;
      const ref=db.collection("users").doc(user.uid);
      // Use set+merge so missing fields get created automatically
      await ref.set({
        stats:{
          gamesPlayed: inc(1),
          wins:        inc(won?1:0),
          draws:       inc(draw?1:0),
          losses:      inc(!won&&!draw?1:0),
          goalsFor:    inc(goalsFor||0),
          goalsAgainst:inc(goalsAgainst||0),
        }
      },{merge:true});
      console.log("Stat saved:", {won,draw,goalsFor,goalsAgainst});
    }catch(e){ console.warn("Stat save error:", e.code, e.message); }
  };

  window.saveVictoryStat=async function(score){
    const user=auth.currentUser; if(!user) return;
    try{
      const inc=firebase.firestore.FieldValue.increment;
      await db.collection("users").doc(user.uid)
        .set({stats:{titles:inc(1)}},{merge:true});
    }catch(e){ console.warn("Victory stat error:", e.code, e.message); }
  };

  // Save score for any run — updates bestScore only if better, always adds to scores collection
  // Save score for any run — updates bestScore only if better (atomic via transaction
  // to avoid race conditions when multiple runs finish in quick succession), always
  // adds this run's score to the global 'scores' collection.
  window.saveFinalScore=async function(score){
    const user=auth.currentUser; if(!user) return;
    if(!score||score<=0) return;
    try{
      const userRef=db.collection("users").doc(user.uid);

      // 1. Atomically update bestScore only if this score is higher than whatever
      //    is currently stored — a transaction prevents two near-simultaneous
      //    runs from both reading a stale value and one overwriting the other.
      const username = await db.runTransaction(async (tx)=>{
        const snap=await tx.get(userRef);
        const data=snap.exists?snap.data():{};
        const s=data.stats||{};
        const currentBest=s.bestScore||0;
        if(score>currentBest){
          tx.set(userRef,{
            stats:{bestScore:score},
            bestTeamName:typeof myTeamName!=='undefined'?myTeamName:'—'
          },{merge:true});
        }
        return data.username||'—';
      });

      // 2. Always add this score to the global 'scores' collection (one doc per run)
      //    The ranking reads from this collection, so ALL scores are preserved
      await db.collection("scores").add({
        uid:       user.uid,
        username:  username,
        teamName:  typeof myTeamName!=='undefined'?myTeamName:'—',
        score:     score,
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });
      console.log("Score saved:", score);
    }catch(e){ console.warn("saveFinalScore error:", e.code, e.message); }
  };

  // Load top 50 from the 'scores' collection — all runs, all users, ordered desc
  window.loadRanking=async function(targetId){
    const el=document.getElementById(targetId||'rankingTable');
    if(!el) return;
    el.innerHTML=`<p class="ranking-loading">${tk('ranking.loading')}</p>`;
    try{
      const snap=await db.collection("scores")
        .orderBy("score","desc")
        .limit(50)
        .get();
      if(snap.empty){
        el.innerHTML=`<p class="ranking-loading">${tk('ranking.empty')}</p>`;
        return;
      }
      let rows=''; let pos=0;
      snap.docs.forEach(doc=>{
        const d=doc.data();
        if(!d.score||d.score<=0) return;
        pos++;
        const posClass=pos===1?'gold':pos===2?'silver':pos===3?'bronze':'';
        const medal=pos===1?'🥇':pos===2?'🥈':pos===3?'🥉':'';
        rows+=`<tr>
          <td class="rank-pos ${posClass}">${medal||pos}</td>
          <td class="rank-name">${d.username||'—'}<br>
            <span style="font-size:10px;color:var(--text-muted);font-weight:400">${d.teamName||'—'}</span>
          </td>
          <td class="rank-score">${d.score}</td>
        </tr>`;
      });
      el.innerHTML=rows
        ?`<table class="ranking-table">
            <thead><tr><th>${tk('ranking.pos')}</th><th>${tk('ranking.player')}</th><th style="text-align:right">${tk('ranking.score')}</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>`
        :`<p class="ranking-loading">${tk('ranking.empty_play')}</p>`;
    }catch(e){
      console.warn("Ranking load error:", e);
      el.innerHTML=`<p class="ranking-loading">${tk('ranking.error')}</p>`;
    }
  };

  window.showRankingModal=function(){
    const o=document.getElementById('rankingOverlay');
    if(o){ o.style.display='flex'; window.loadRanking('rankingTableDesktop'); }
  };

  /* ─── CLOSE ON BACKDROP ─── */
  document.addEventListener("click",e=>{
    const auth=$id("authOverlay");
    if(auth&&e.target===auth) window.closeAuthModal();
    const prof=$id("profileOverlay");
    if(prof&&e.target===prof) window.closeProfileModal();
    const rank=$id("rankingOverlay");
    if(rank&&e.target===rank) rank.style.display='none';
  });

  /* ─── WIRE BUTTONS ─── */
  function wire(id,fn){ const el=$id(id); if(el) el.addEventListener("click",fn); }
  wire("authBtn",          ()=>window.showAuthModal("login"));
  wire("profileBtn",       ()=>window.showProfileModal());
  wire("authCloseBtn",     ()=>window.closeAuthModal());
  wire("profileCloseBtn",  ()=>window.closeProfileModal());
  wire("profileLogoutBtn", ()=>{ window.authLogout(); window.closeProfileModal(); });
  wire("profileTabStats",    ()=>window.switchProfileTab("stats"));
  wire("profileTabUser",     ()=>window.switchProfileTab("user"));
  wire("profileTabUpgrades", ()=>window.switchProfileTab("upgrades"));
  wire("profileTabNotes",    ()=>window.switchProfileTab("notes"));
  wire("profileTabAchievements", ()=>window.switchProfileTab("achievements"));
  // Auto-save the team-name preference: checkbox toggles save immediately,
  // the text field saves when the user leaves it (blur) or presses Enter.
  (function(){
    const checkbox=$id("useFixedTeamNameCheckbox");
    const nameInp=$id("preferredTeamNameInput");
    if(checkbox) checkbox.addEventListener("change", ()=>window.saveTeamNamePreference());
    if(nameInp){
      nameInp.addEventListener("blur", ()=>window.saveTeamNamePreference(true));
      nameInp.addEventListener("keydown", e=>{ if(e.key==="Enter") window.saveTeamNamePreference(); });
    }
  })();
  wire("tabLogin",         ()=>window.switchAuthTab("login"));
  wire("tabRegister",      ()=>window.switchAuthTab("register"));
  wire("loginSubmitBtn",   ()=>window.submitLogin());
  wire("forgotPasswordLink", ()=>window.submitPasswordReset());
  wire("regSubmitBtn",     ()=>window.submitRegister());

  // Enter key support for auth forms
  function addEnterKey(inputId, submitFn){
    const el=$id(inputId);
    if(el) el.addEventListener("keydown",e=>{ if(e.key==="Enter") submitFn(); });
  }
  // Login: Enter on any field submits
  ["loginIdentifier","loginPassword"].forEach(id=>addEnterKey(id,window.submitLogin));
  // Register: Enter on last field submits
  ["regUsername","regEmail","regPassword","regPassword2"].forEach(id=>addEnterKey(id,window.submitRegister));
  // Welcome popup
  wire("welcomeStartBtn",  ()=>{
    const o=$id("welcomeOverlay"); if(o) o.style.display="none";
  });
}

// initFirebaseAuth() is called by firebase.js once all Firebase SDKs are loaded

/* ========= MOBILE TAB NAVIGATION ========= */
function switchMobileTab(tab){
  if(window.innerWidth>1050) return;

  document.querySelectorAll('.mob-tab').forEach(btn=>{
    btn.classList.toggle('active', btn.dataset.tab===tab);
  });

  const left=document.querySelector('.left-panel');
  const right=document.querySelector('.right-panel');
  const ranking=document.getElementById('rankingPanel');
  const info=document.getElementById('infoPanel');
  if(left)    left.classList.remove('mob-active');
  if(right)   right.classList.remove('mob-active');
  if(ranking) ranking.classList.remove('mob-active');
  if(info)    info.classList.remove('mob-active');

  if(tab==='campo'){
    if(typeof renderMobileFormationInfo==='function') renderMobileFormationInfo();
    setTimeout(()=>{
      const p=document.getElementById('pitchBox')||document.getElementById('pitch');
      if(p) p.scrollIntoView({behavior:'smooth',block:'start'});
    },50);
  } else if(tab==='equipo'){
    if(left) left.classList.add('mob-active');
    setTimeout(()=>{
      // Before the formation is locked, FORMACIÓN + PERFIL DEL EQUIPO
      // still live in the center panel — scroll there instead of
      // CONVOCADOS (which has no relevant content to show yet).
      if(!formationIsLocked){
        const fp=document.getElementById('formationPickerBox');
        if(fp) fp.scrollIntoView({behavior:'smooth',block:'start'});
        return;
      }
      const cb=document.getElementById('convocadosBox')||left;
      if(cb) cb.scrollIntoView({behavior:'smooth',block:'start'});
    },50);
  } else if(tab==='rival'){
    if(right) right.classList.add('mob-active');
    const badge=document.querySelector('.mob-tab[data-tab="rival"] .mob-tab-badge');
    if(badge) badge.style.display='none';
    setTimeout(()=>{
      const rb=document.getElementById('rivalBox');
      if(rb) rb.scrollIntoView({behavior:'smooth',block:'start'});
      else if(right) right.scrollIntoView({behavior:'smooth',block:'start'});
    },50);
  } else if(tab==='historial'){
    if(right) right.classList.add('mob-active');
    setTimeout(()=>{
      const mh=document.getElementById('matchHistoryBox');
      if(mh) mh.scrollIntoView({behavior:'smooth',block:'start'});
      else if(right) right.scrollIntoView({behavior:'smooth',block:'start'});
    },80);
  } else if(tab==='info'){
    if(info){
      info.classList.add('mob-active');
      setTimeout(()=>info.scrollIntoView({behavior:'smooth',block:'start'}),50);
    }
    // Auto-expand all three tutorial boxes when entering INFORMACIÓN
    const tipsBox=document.getElementById("tipsBox");
    const howTo=document.getElementById("howToPlayBox");
    const statsGuide=document.getElementById("statsGuideBox");
    if(tipsBox) tipsBox.classList.remove("collapsed");
    if(howTo) howTo.classList.remove("collapsed");
    if(statsGuide) statsGuide.classList.remove("collapsed");
  } else {
    // Any other tab: re-collapse the tutorial boxes (they live off-screen
    // in infoPanel, but keep the collapsed state consistent for next visit
    // and for when they relocate back to the right panel on desktop).
    const tipsBox=document.getElementById("tipsBox");
    const howTo=document.getElementById("howToPlayBox");
    const statsGuide=document.getElementById("statsGuideBox");
    if(tipsBox) tipsBox.classList.add("collapsed");
    if(howTo) howTo.classList.add("collapsed");
    if(statsGuide) statsGuide.classList.add("collapsed");
  }
  if(tab==='ranking'){
    if(ranking){
      ranking.classList.add('mob-active');
      setTimeout(()=>ranking.scrollIntoView({behavior:'smooth',block:'start'}),50);
    }
    if(typeof window.loadRanking==='function') window.loadRanking('rankingTable');
  }
}
function notifyMobileRivalTab(){
  if(window.innerWidth>1050) return;
  const badge=document.querySelector('.mob-tab[data-tab="rival"] .mob-tab-badge');
  if(badge){ badge.style.display='flex'; }
  const btn=document.querySelector('.mob-tab[data-tab="rival"]');
  if(btn) btn.style.color='var(--gold)';
}
// Clear rival badge when tab is opened
document.addEventListener('click', e=>{
  if(e.target.closest('.mob-tab[data-tab="rival"]')){
    const badge=document.querySelector('.mob-tab[data-tab="rival"] .mob-tab-badge');
    if(badge) badge.style.display='none';
  }
});

// Add badge HTML to rival tab on init
(function(){
  const rivalTab=document.querySelector('.mob-tab[data-tab="rival"]');
  if(rivalTab && !rivalTab.querySelector('.mob-tab-badge')){
    const badge=document.createElement('span');
    badge.className='mob-tab-badge';
    badge.style.display='none';
    badge.textContent='!';
    rivalTab.appendChild(badge);
  }
})();

/* ── Temporizador de guía — pestaña CAMPO (móvil) ──
   Si pasan 20s sin que el jugador pulse "JUGAR PARTIDO" (al empezar el
   torneo o entre partidos), un aviso silencioso en la pestaña CAMPO le
   indica dónde está el botón. Sin barra visible ni sonido — no es un
   temporizador de juego, solo una guía de interfaz. */
let _campoGuideTimer=null;
function startCampoGuideTimer(){
  clearCampoGuideTimer();
  if(window.innerWidth>1050) return; // solo tiene sentido en móvil
  _campoGuideTimer=setTimeout(()=>{ notifyMobileCampoTab(); }, 20000);
}
function clearCampoGuideTimer(){
  if(_campoGuideTimer){ clearTimeout(_campoGuideTimer); _campoGuideTimer=null; }
  const badge=document.querySelector('.mob-tab[data-tab="campo"] .mob-tab-badge-guide');
  if(badge) badge.style.display='none';
  const btn=document.querySelector('.mob-tab[data-tab="campo"]');
  if(btn) btn.style.color='';
}
function notifyMobileCampoTab(){
  if(window.innerWidth>1050) return;
  const badge=document.querySelector('.mob-tab[data-tab="campo"] .mob-tab-badge-guide');
  if(badge) badge.style.display='flex';
  const btn=document.querySelector('.mob-tab[data-tab="campo"]');
  if(btn) btn.style.color='var(--gold)';
}
// Limpiar el aviso en cuanto se visita la pestaña CAMPO
document.addEventListener('click', e=>{
  if(e.target.closest('.mob-tab[data-tab="campo"]')) clearCampoGuideTimer();
});
// Añadir el HTML del aviso a la pestaña CAMPO al iniciar
(function(){
  const campoTab=document.querySelector('.mob-tab[data-tab="campo"]');
  if(campoTab && !campoTab.querySelector('.mob-tab-badge-guide')){
    const badge=document.createElement('span');
    badge.className='mob-tab-badge mob-tab-badge-guide';
    badge.style.display='none';
    badge.textContent='!';
    campoTab.appendChild(badge);
  }
})();
document.getElementById("playMatchBtn").addEventListener("click", clearCampoGuideTimer);

/* ── Notificación de GOAT Points ganados ── */
function checkPointsAchievements(pts){
  if(pts>=50) unlockAchievement('50_goat_pts');
  if(pts>=100) unlockAchievement('100_pts');
}
function showGoatPointsBadge(){
  const pb=$id('profileGoatBadge');
  const ub=$id('upgradesBadge');
  const sb=$id('skillsBadge');
  if(pb) pb.style.display='block'; // siempre mostrar en botón perfil
  if(ub) ub.style.display='inline-block';
  if(sb) sb.style.display='inline-block';
  try{ localStorage.setItem('_g2g_pts_pending','1'); }catch(e){}
}
function showProfileBadge(){
  // Muestra solo el badge del botón perfil (sin indicar pestaña específica)
  const pb=$id('profileGoatBadge');
  if(pb) pb.style.display='block';
}
function hideGoatPointsBadge(){
  // Solo ocultar si no hay logros pendientes tampoco
  const achPending=localStorage.getItem('_g2g_ach_pending');
  const pb=$id('profileGoatBadge');
  const ub=$id('upgradesBadge');
  const sb=$id('skillsBadge');
  if(!achPending&&pb) pb.style.display='none';
  if(ub) ub.style.display='none';
  if(sb) sb.style.display='none';
  try{ localStorage.removeItem('_g2g_pts_pending'); }catch(e){}
}
// Restaurar badge si había puntos pendientes de ver al cargar la página
(function(){
  try{ if(localStorage.getItem('_g2g_pts_pending')) showGoatPointsBadge(); }catch(e){}
  try{
    if(localStorage.getItem('_g2g_ach_pending')){
      const ab=document.getElementById('achievementsBadge');
      if(ab) ab.style.display='inline-block';
      // También mostrar badge en perfil
      const pb=document.getElementById('profileGoatBadge');
      if(pb) pb.style.display='block';
    }
  }catch(e){}
})();

/* ============================================================
   SISTEMA DE BOLETOS RASCA Y GANA
   - 1 boleto cada 4h, máximo 3 acumulados
   - Al crear cuenta: 1 boleto inicial
   - Premios: 🪙 moneda = 1 pt, 🐐 cabra = 3 pts, ❌ = pierde todo
   - 2 casillas X roja, 1 cabra, resto monedas (9 casillas total)
   - Puntos se guardan en Firestore: users/{uid}.scratchPoints
   ============================================================ */

const TICKET_MAX = 3;
const TICKET_FIXED_HOURS = [0, 4, 8, 12, 16, 20]; // horas locales de recarga

/* Devuelve el timestamp local del próximo slot de recarga a partir de 'now' */
function nextTicketSlot(now){
  const d = new Date(now);
  const h = d.getHours(), m = d.getMinutes(), s = d.getSeconds(), ms = d.getMilliseconds();
  const minutesNow = h * 60 + m;
  // Buscar el próximo slot en el mismo día
  for(const fh of TICKET_FIXED_HOURS){
    if(fh * 60 > minutesNow){
      const next = new Date(d);
      next.setHours(fh, 0, 0, 0);
      return next.getTime();
    }
  }
  // Si ya pasaron todos los slots de hoy → primer slot de mañana
  const next = new Date(d);
  next.setDate(next.getDate() + 1);
  next.setHours(TICKET_FIXED_HOURS[0], 0, 0, 0);
  return next.getTime();
}

/* Cuántos slots han pasado entre lastChecked y now */
function slotsBetween(lastChecked, now){
  let count = 0;
  let cursor = lastChecked;
  while(true){
    const slot = nextTicketSlot(cursor);
    if(slot > now) break;
    count++;
    cursor = slot;
  }
  return count;
}

function computeCurrentTickets(count, lastChecked){
  const now = Date.now();
  const gained = slotsBetween(lastChecked, now);
  if(gained <= 0) return { count, lastChecked };
  const newCount = Math.min(TICKET_MAX, count + gained);
  // lastChecked avanza al último slot consumido
  let cursor = lastChecked;
  for(let i = 0; i < gained; i++) cursor = nextTicketSlot(cursor);
  return { count: newCount, lastChecked: cursor };
}

/* ── Leer/escribir estado de boletos en Firestore ── */
async function getTicketState(){
  const auth=window._fbAuth; const db=window._fbDb;
  if(!auth||!db) return null;
  const user=auth.currentUser;
  if(!user) return null;
  if(window.CHEATS_ACTIVE) return {count:3, lastChecked:Date.now(), scratchPoints:100};
  const snap=await db.collection('users').doc(user.uid).get();
  if(!snap.exists) return null;
  const d=snap.data();
  return {
    count: d.ticketCount !== undefined ? d.ticketCount : 1,
    lastChecked: d.ticketLastRegen || Date.now(),
    scratchPoints: d.scratchPoints || 0,
    scratchPointsEarned: d.scratchPointsEarned || 0,
    scratchPointsSpent: d.scratchPointsSpent || 0,
  };
}

async function saveTicketState(count, lastChecked, scratchPoints){
  const auth=window._fbAuth; const db=window._fbDb;
  if(!auth||!db) return;
  const user=auth.currentUser;
  if(!user) return;
  await db.collection('users').doc(user.uid).set({
    ticketCount: count,
    ticketLastRegen: lastChecked,
    scratchPoints: scratchPoints,
  },{merge:true});
}

/* ── Actualizar badge en la tab de móvil ── */
function updateTicketBadge(count){
  // Si cheats activos, siempre mostrar 3
  if(window.CHEATS_ACTIVE) count=3;
  if(count===undefined||count===null) return; // sin datos aún
  // Mobile tab badge
  const el=$id('ticketCountBadge');
  if(el){
    el.textContent=`${count}/${TICKET_MAX}`;
    el.style.color=count>0?'var(--gold)':'#666';
  }
  // Desktop header button
  const hBtn=$id('headerTicketBtn');
  const hCount=$id('headerTicketCount');
  const hAlert=$id('headerTicketAlert');
  if(hCount) hCount.textContent=`${count}/${TICKET_MAX}`;
  if(hAlert) hAlert.style.display=count>0?'block':'none';
  // Punto de alerta en tab móvil
  const btn=$id('ticketTabBtn');
  if(btn){
    let dot=btn.querySelector('.mob-tab-badge');
    if(count>0&&!dot){
      dot=document.createElement('span');
      dot.className='mob-tab-badge';
      dot.style.cssText='background:#f87171;width:8px;height:8px;border-radius:50%;padding:0;min-width:unset;';
      btn.appendChild(dot);
    } else if(count<=0&&dot){
      dot.remove();
    }
  }
}

/* ── Abrir / cerrar overlay de tickets ── */
window.openTicketOverlay = function() {
  var ov = document.getElementById('ticketOverlay');
  if (ov) ov.style.display = 'block';
  var mt = document.getElementById('ticketMountPoint');
  if (!mt) return;

  var auth = window._fbAuth;
  if (!auth) {
    mt.innerHTML = `<div style="padding:40px;color:#f87171;text-align:center">${tk('ticket.firebase_error')}</div>`;
    return;
  }

  var user = auth.currentUser;
  if (!user) {
    mt.innerHTML = `<div style='text-align:center;color:#ccc;padding:40px 20px'><div style='font-size:48px'>🔒</div><div style='font-size:20px;color:#f0c419;margin:10px 0;font-family:Bebas Neue,sans-serif'>${tk('ticket.login_title')}</div><p style='font-size:12px;color:#aaa'>${tk('ticket.login_msg')}</p><button onclick='window.closeTicketOverlay()' style='margin-top:16px;border:1px solid #444;background:none;color:#aaa;padding:8px 20px;cursor:pointer;font-size:13px'>${tk('ticket.close')}</button></div>`;
    return;
  }

  mt.innerHTML = `<div style="text-align:center;padding:40px;color:#aaa">${tk('ticket.loading')}</div>`;

  getTicketState().then(function(state) {
    if (!state) {
      mt.innerHTML = `<div style="padding:40px;color:#f87171;text-align:center">${tk('ticket.error')}</div>`;
      return;
    }
    var updated = computeCurrentTickets(state.count, state.lastChecked);
    if (updated.count !== state.count || updated.lastChecked !== state.lastChecked) {
      saveTicketState(updated.count, updated.lastChecked, state.scratchPoints);
    }
    updateTicketBadge(updated.count);
    if (updated.count <= 0) {
      var nextSlot = nextTicketSlot(Date.now());
      var d = new Date(nextSlot);
      var hh = String(d.getHours()).padStart(2,'0');
      var mm = String(d.getMinutes()).padStart(2,'0');
      var msLeft = nextSlot - Date.now();
      var hLeft = Math.floor(msLeft / 3600000);
      var mLeft = Math.floor((msLeft % 3600000) / 60000);
      var sLeft = Math.floor((msLeft % 60000) / 1000);
      // Diseño de modal de perfil con temporizador en vivo
      mt.innerHTML = `<div class="auth-modal" style="max-width:340px;text-align:center;padding:28px 24px">
        <div style="font-size:48px;margin-bottom:8px">🎟️</div>
        <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:22px;letter-spacing:2px;color:var(--gold);margin-bottom:20px">${tk('ticket.no_tickets')}</div>
        <div style="font-size:12px;color:var(--text-muted);margin-bottom:8px;letter-spacing:1px;text-transform:uppercase">${tk('ticket.next_ticket_in')}</div>
        <div id="ticketCountdown" style="font-family:'Bebas Neue',Impact,sans-serif;font-size:48px;color:#fff;letter-spacing:4px;margin-bottom:24px">--:--:--</div>
        <button onclick="window.closeTicketOverlay()" style="width:100%;border:none;background:#c0392b;color:#fff;padding:12px;cursor:pointer;font-family:'Bebas Neue',Impact,sans-serif;font-size:16px;letter-spacing:1.5px;transition:.15s" onmouseover="this.style.background='#e74c3c'" onmouseout="this.style.background='#c0392b'">${tk('ticket.close')}</button>
      </div>`;
      // Arrancar cuenta atrás en vivo
      function _tickCountdown(){
        const el = document.getElementById('ticketCountdown');
        if(!el) return; // overlay cerrado
        const left = nextTicketSlot(Date.now()) - Date.now();
        if(left <= 0){ el.textContent = '00:00:00'; return; }
        const h = Math.floor(left/3600000);
        const m = Math.floor((left%3600000)/60000);
        const s = Math.floor((left%60000)/1000);
        el.textContent = String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
        setTimeout(_tickCountdown, 1000);
      }
      _tickCountdown();
      return;
    }
    buildTicketInMount(mt, updated.count, updated.lastChecked, state.scratchPoints);
  }).catch(function(e) {
    console.error('openTicketOverlay error:', e);
    mt.innerHTML = '<div style="padding:40px;color:#f87171;text-align:center">Error: ' + e.message + '</div>';
  });
};

window.closeTicketOverlay = function() {
  var ov = document.getElementById('ticketOverlay');
  if (ov) ov.style.display = 'none';
};

/* ── Construir el boleto dentro del mount point ── */
function buildTicketInMount(mount, ticketCount, lastRegen, currentScratchPts){
  const GRID_SIZE=9;
  // Composición: 1 X roja, 1 cabra (+4pts), 7 monedas (+1pt cada una)
  const indices=Array.from({length:GRID_SIZE},(_,i)=>i);
  for(let i=indices.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [indices[i],indices[j]]=[indices[j],indices[i]];
  }
  const bombIdx=indices[0];  // 1 sola X roja
  const starIdx=indices[1];  // 1 sola cabra

  const cellsData=[];
  for(let i=0;i<GRID_SIZE;i++){
    if(i===bombIdx)       cellsData.push({type:'bomb', value:0});
    else if(i===starIdx)  cellsData.push({type:'star', value:4});
    else                  cellsData.push({type:'coin', value:1});
  }

  let scratchedCount=0, totalPoints=0, gameOver=false;
  const serial=String(Math.floor(1000+Math.random()*8999))+'-'+String(Math.floor(1000+Math.random()*8999));

  mount.innerHTML=`
  <div class="ticket" id="ticketCard" style="position:relative;width:340px;background:linear-gradient(180deg,#0f3d24 0%,#0c2e1c 100%);border-radius:0;box-shadow:0 30px 60px -20px rgba(0,0,0,.7),0 0 0 1px rgba(240,196,25,.15);overflow:visible">
    <div style="display:flex;justify-content:space-around;margin:0 -4px;position:relative;z-index:2">${Array.from({length:12},()=>'<div style="width:16px;height:16px;border-radius:50%;background:#0a1212;border:1px solid rgba(246,241,227,.1);flex-shrink:0"></div>').join('')}</div>
    <button onclick=\"window.closeTicketOverlay()\" style=\"position:absolute;top:10px;right:12px;background:none;border:none;color:rgba(246,241,227,.5);font-size:20px;cursor:pointer;z-index:10;line-height:1;padding:4px\" title=\"${tk('ticket.close_x')}\">✕</button>

    <div style="padding:26px 22px 22px;">
      <div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:2px;">
        <span style="font-size:18px">⚽</span>
        <span style="font-family:'Bebas Neue',Impact,sans-serif;font-size:22px;letter-spacing:2px;color:#f0c419;text-shadow:0 2px 0 rgba(0,0,0,.4)">GOAL2GOAT</span>
        <span style="font-size:18px">🐐</span>
      </div>
      <div style="text-align:center;font-size:10px;letter-spacing:3px;color:rgba(246,241,227,.55);text-transform:uppercase;margin-bottom:16px;font-weight:700">${tk('ticket.goat_pts')}</div>
      <div style="height:1px;background:repeating-linear-gradient(90deg,rgba(240,196,25,.35) 0 6px,transparent 6px 12px);margin:14px 0"></div>
      <div style="display:flex;justify-content:space-between;font-size:9px;letter-spacing:1px;color:rgba(246,241,227,.4);text-transform:uppercase;margin-bottom:14px;">
        <span>Nº <b style="color:rgba(246,241,227,.65)">${serial}</b></span>
        <span>${tk("ticket.slot_n").replace("{0}",TICKET_MAX+1-ticketCount).replace("{1}",TICKET_MAX)}</span>
      </div>
      <div style="text-align:center;margin-bottom:18px;">
        <div style="font-size:9px;letter-spacing:3px;text-transform:uppercase;color:rgba(246,241,227,.5);margin-bottom:4px;font-weight:700">${tk('ticket.accumulated')}</div>
        <div id="tPrize" style="font-family:'Bebas Neue',Impact,sans-serif;font-size:40px;color:#f0c419;text-shadow:0 3px 0 rgba(0,0,0,.35);">0 <span style="font-size:20px;opacity:.85">PTS</span></div>
      </div>
      <div class="scratch-grid" id="tGrid" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:18px;"></div>
      <div id="tDots" style="display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:16px;flex-wrap:wrap;">
        <span style="font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:rgba(246,241,227,.5);font-weight:700;margin-right:4px;">${tk("ticket.scratched")}</span>
      </div>
      <div style="margin-bottom:18px;">
        <div style="display:flex;justify-content:space-between;font-size:9px;letter-spacing:1px;text-transform:uppercase;color:rgba(246,241,227,.5);font-weight:700;margin-bottom:5px;">
          <span>${tk('ticket.next_risk')}</span>
          <span style="color:#d94f3d;font-weight:800" id="tRiskVal">8%</span>
        </div>
        <div style="height:6px;border-radius:4px;background:rgba(246,241,227,.12);overflow:hidden;">
          <div id="tRiskFill" style="height:100%;border-radius:4px;background:linear-gradient(90deg,#e8b923,#d94f3d);width:8%;transition:width .4s ease;"></div>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;">
        <button id="tCashBtn" disabled onclick="ticketCashOut(false)" style="border:none;border-radius:0;font-family:'Bebas Neue',Impact,sans-serif;font-size:22px;letter-spacing:2px;padding:14px;cursor:pointer;background:linear-gradient(180deg,#ffe27a,#f0c419 55%,#c9960c);color:#08160d;box-shadow:0 6px 0 #8a6a08,0 10px 18px -6px rgba(0,0,0,.5);opacity:.35;pointer-events:none;">${tk("ticket.cashout")}</button>

      </div>
      
    </div>
  </div>
  <div id="tResultOverlay" style="display:none;position:fixed;inset:0;z-index:50000;background:rgba(0,0,0,.75);align-items:center;justify-content:center;padding:20px;"></div>`;

  // Construir grid
  const grid=$id('tGrid');
  const dotsRow=$id('tDots');
  for(let i=0;i<GRID_SIZE;i++){
    const data=cellsData[i];
    const cell=document.createElement('div');
    cell.style.cssText='position:relative;aspect-ratio:1;border-radius:10px;overflow:hidden;background:#f6f1e3;box-shadow:inset 0 0 0 2px rgba(8,22,13,.25);';
    cell.dataset.index=i;

    const res=document.createElement('div');
    res.style.cssText='position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:2px;font-family:"Bebas Neue",Impact,sans-serif;background:#fff;';
    if(data.type==='bomb'){
      res.style.background='#fff0ee';
      res.innerHTML=`<span style="font-size:26px">❌</span><span style="font-size:13px;color:#d94f3d;letter-spacing:.5px">${tk("ticket.cell_lose")}</span>`;
    } else if(data.type==='star'){
      res.style.background='#fff9e0';
      res.innerHTML=`<span style="font-size:26px">🐐</span><span style="font-size:13px;color:#0c2e1c;letter-spacing:.5px">${tk("ticket.cell_goat")}</span>`;
    } else {
      res.innerHTML=`<span style="font-size:26px">🪙</span><span style="font-size:13px;color:#0c2e1c;letter-spacing:.5px">${tk("ticket.cell_coin")}</span>`;
    }
    cell.appendChild(res);

    const canvas=document.createElement('canvas');
    canvas.style.cssText='position:absolute;inset:0;width:100%;height:100%;cursor:pointer;touch-action:none;';
    cell.appendChild(canvas);
    grid.appendChild(cell);

    // Dot indicador
    const dot=document.createElement('span');
    dot.style.cssText='width:9px;height:9px;border-radius:50%;background:rgba(246,241,227,.18);display:inline-block;transition:all .25s ease;';
    dot.dataset.dotIdx=i;
    dotsRow.appendChild(dot);

    initTicketCell(cell, canvas, i);
  }

  function riskForAttempt(n){
    return [8,16,26,38,52,68,86,99][Math.min(n,7)];
  }

  function updateUI(){
    const prizeEl=$id('tPrize');
    if(prizeEl) prizeEl.innerHTML=`${totalPoints} <span style="font-size:20px;opacity:.85">PTS</span>`;
    const cashBtn=$id('tCashBtn');
    const cashAmt=$id('tCashAmt');
    const riskBtn=null; // eliminado
    const riskVal=$id('tRiskVal');
    const riskFill=$id('tRiskFill');
    if(cashAmt) cashAmt.textContent=totalPoints;
    if(cashBtn){
      if(totalPoints>0&&!gameOver){
        cashBtn.disabled=false;
        cashBtn.style.opacity='1';
        cashBtn.style.pointerEvents='auto';
      } else {
        cashBtn.disabled=true;
        cashBtn.style.opacity='.35';
        cashBtn.style.pointerEvents='none';
      }
    }
    const risk=riskForAttempt(scratchedCount);
    if(riskVal) riskVal.textContent=risk+'%';
    if(riskFill) riskFill.style.width=risk+'%';
    if(riskBtn){
      if(gameOver) riskBtn.textContent=tk('ticket.closed')||'BOLETO CERRADO';
      else if(scratchedCount>=GRID_SIZE) riskBtn.textContent=tk('ticket.complete')||'BOLETO COMPLETO';
      else if(scratchedCount===0) riskBtn.textContent='';
      else riskBtn.innerHTML=`SIGUIENTE RASCADO · <b style="color:#d94f3d">${risk}% riesgo</b>`;
    }
  }

  function initTicketCell(cell, canvas, idx){
    const dpr=window.devicePixelRatio||1;
    const rect=cell.getBoundingClientRect();
    canvas.width=Math.max(rect.width,80)*dpr;
    canvas.height=Math.max(rect.height,80)*dpr;
    canvas.style.width=(Math.max(rect.width,80))+'px';
    canvas.style.height=(Math.max(rect.height,80))+'px';
    const ctx=canvas.getContext('2d');
    ctx.scale(dpr,dpr);
    const w=canvas.width/dpr, h=canvas.height/dpr;
    // Capa metálica
    const grad=ctx.createLinearGradient(0,0,w,h);
    grad.addColorStop(0,'#e3e8ea');
    grad.addColorStop(.5,'#9aa5ab');
    grad.addColorStop(1,'#c4cbce');
    ctx.fillStyle=grad;
    ctx.fillRect(0,0,w,h);
    ctx.strokeStyle='rgba(180,190,195,.5)';
    ctx.lineWidth=2;
    for(let x=-h;x<w;x+=6){ ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x+h,h);ctx.stroke(); }
    ctx.font='20px sans-serif';
    ctx.textAlign='center';
    ctx.textBaseline='middle';
    ctx.globalAlpha=.5;
    ctx.fillStyle='#333';
    ctx.fillText('⚽',w/2,h/2);
    ctx.globalAlpha=1;
    ctx.globalCompositeOperation='destination-out';

    let isScratching=false;
    let hasMoved=false;

    function scratchAt(cx,cy){
      const r=canvas.getBoundingClientRect();
      ctx.beginPath();
      ctx.arc(cx-r.left,cy-r.top,18,0,Math.PI*2);
      ctx.fill();
      // Check reveal %
      const imgData=ctx.getImageData(0,0,canvas.width,canvas.height).data;
      let cleared=0,sampled=0;
      for(let p=3;p<imgData.length;p+=160){sampled++;if(imgData[p]<80)cleared++;}
      if(cleared/sampled>0.5&&!cell.dataset.revealed) revealTicketCell(cell,idx,canvas);
    }

    canvas.addEventListener('mousedown',e=>{isScratching=true;hasMoved=false;scratchAt(e.clientX,e.clientY);e.preventDefault();});
    canvas.addEventListener('mousemove',e=>{if(!isScratching)return;hasMoved=true;scratchAt(e.clientX,e.clientY);e.preventDefault();});
    window.addEventListener('mouseup',()=>{
      if(isScratching&&!cell.dataset.revealed) revealTicketCell(cell,idx,canvas);
      isScratching=false;
    });
    canvas.addEventListener('touchstart',e=>{isScratching=true;hasMoved=false;scratchAt(e.touches[0].clientX,e.touches[0].clientY);e.preventDefault();},{passive:false});
    canvas.addEventListener('touchmove',e=>{if(!isScratching)return;hasMoved=true;scratchAt(e.touches[0].clientX,e.touches[0].clientY);e.preventDefault();},{passive:false});
    canvas.addEventListener('touchend',()=>{
      if(isScratching&&!cell.dataset.revealed) revealTicketCell(cell,idx,canvas);
      isScratching=false;
    });
  }

  function revealTicketCell(cell,idx,canvas){
    if(cell.dataset.revealed) return;
    cell.dataset.revealed='1';
    canvas.style.opacity='0';
    canvas.style.transition='opacity .35s ease';
    canvas.style.pointerEvents='none';

    const data=cellsData[idx];
    const dot=dotsRow.querySelector(`[data-dot-idx="${idx}"]`);

    scratchedCount++;
    if(data.type==='bomb'){
      if(dot){ dot.style.background='#d94f3d'; dot.style.boxShadow='0 0 6px rgba(217,79,61,.7)'; }
      // Sin sonido para la bomba — el silencio es más impactante
      handleTicketBomb();
    } else if(data.type==='star'){
      const colBonus=window._skillCache&&window._skillCache.coleccionista?1:0;
      totalPoints+=data.value+colBonus;
      if(dot){ dot.style.background='#f0c419'; dot.style.boxShadow='0 0 6px rgba(240,196,25,.6)'; }
      playSound('scratch_star');
      updateUI();
      if(scratchedCount>=GRID_SIZE) setTimeout(()=>ticketCashOut(true),500);
    } else {
      totalPoints+=data.value;
      if(dot){ dot.style.background='#f0c419'; dot.style.boxShadow='0 0 6px rgba(240,196,25,.6)'; }
      // Pitch progresivo: cada casilla buena sube el tono
      if(audioEnabled&&getAudioCtx()){
        const baseFreq=400+(scratchedCount*40);
        tone(getAudioCtx(), baseFreq, 0, 0.06, 'sine', 0.10, 0.0001);
        tone(getAudioCtx(), baseFreq*1.5, 0.04, 0.08, 'sine', 0.07, 0.0001);
      }
      updateUI();
      if(scratchedCount>=GRID_SIZE) setTimeout(()=>ticketCashOut(true),500);
    }
  }

  function handleTicketBomb(){
    gameOver=true;
    const stamp=$id('ticketStamp');
    if(stamp){stamp.textContent='PERDISTE';stamp.style.background='#d94f3d';}
    // Revelar todas las celdas restantes
    Array.from(grid.children).forEach(c=>{
      if(!c.dataset.revealed){
        c.dataset.revealed='1';
        const cv=c.querySelector('canvas');
        if(cv){cv.style.opacity='0';cv.style.pointerEvents='none';}
      }
    });
    updateUI();
    setTimeout(()=>showTicketResult(false,0),600);
  }

  window.ticketCashOut=function(auto){
    if(gameOver||totalPoints<=0) return;
    gameOver=true;
    const stamp=$id('ticketStamp');
    if(stamp){stamp.textContent='COBRADO';stamp.style.background='#3fae5c';}
    const pts=totalPoints;
    updateUI();
    showTicketResult(true,pts,auto);
  };

  function showTicketResult(win,pts,auto){
    const overlay=$id('tResultOverlay');
    if(!overlay) return;
    overlay.style.display='flex';
    // Sonido según resultado
    if(win) playSound('victory');
    else playSound('scratch_bomb');
    overlay.innerHTML=`
    <div style="background:linear-gradient(180deg,#0f3d24,#0c2e1c);border-radius:0;padding:30px 26px;text-align:center;max-width:300px;width:90%;box-shadow:0 30px 60px -10px rgba(0,0,0,.8),0 0 0 1px rgba(240,196,25,.2);animation:popIn .3s cubic-bezier(.2,1.4,.4,1)">
      <style>@keyframes popIn{0%{transform:scale(.7);opacity:0}100%{transform:scale(1);opacity:1}}</style>
      <span style="font-size:54px;display:block;margin-bottom:10px">${win?(auto?'🏆':'💰'):'❌'}</span>
      <h2 style="font-family:'Bebas Neue',Impact,sans-serif;font-size:26px;letter-spacing:1px;color:${win?'#f0c419':'#d94f3d'};margin-bottom:6px">${win?tk('ticket.result_win_auto'):tk('ticket.result_lose')}</h2>
      <p style="font-size:12px;color:rgba(246,241,227,.7);line-height:1.5;margin-bottom:12px">${win?(auto?tk('ticket.result_win_auto_msg'):tk('ticket.result_win_cash_msg')):tk('ticket.result_lose_msg')}</p>
      <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:34px;color:${win?'#f0c419':'#d94f3d'};margin-bottom:18px">${(win && pts>0)?'+'+pts+' PTS':win?'0 PTS':''}</div>
      <button onclick="closeTicketAndSave(${win?pts:0})" style="width:100%;border:none;border-radius:0;padding:12px;font-family:'Bebas Neue',Impact,sans-serif;font-size:15px;letter-spacing:1.5px;background:linear-gradient(180deg,#ffe27a,#f0c419 55%,#c9960c);color:#08160d;cursor:pointer;">${tk('ticket.close')}</button>
    </div>`;
  }

  window.closeTicketAndSave=async function(ptsEarned){
    // En cheats aún guardamos los puntos ganados realmente
    if(window._fbAuth&&window._fbAuth.currentUser){
      try{
        const user=window._fbAuth.currentUser;
        const db=window._fbDb;
        // Leer estado actual de Firestore para no perder puntos por estado desactualizado
        const snap=await db.collection('users').doc(user.uid).get();
        const currentData=snap.exists?snap.data():{};
        const currentPts=currentData.scratchPoints||0;
        const newPts=currentPts+ptsEarned;
        const newEarned=(currentData.scratchPointsEarned||0)+ptsEarned;
        if(ptsEarned>0) showGoatPointsBadge();
        // Calcular nuevo contador de tickets
        const updated=computeCurrentTickets(
          currentData.ticketCount!==undefined?currentData.ticketCount:1,
          currentData.ticketLastRegen||Date.now()
        );
        const newCount=Math.max(0,updated.count-1);
        await db.collection('users').doc(user.uid).set({
          ticketCount:newCount,
          ticketLastRegen:updated.lastChecked,
          scratchPoints:newPts,
          scratchPointsEarned:newEarned
        },{merge:true});
        const displayCount=window.CHEATS_ACTIVE?3:newCount;
        updateTicketBadge(displayCount);
        const pse=$id('pstat-scratch-pts');
        if(pse) pse.textContent=newPts;
      }catch(e){ console.warn('Error guardando boleto:',e); }
    }
    window.closeTicketOverlay();
  };
}

/* ── Inicializar boletos cuando el usuario se loguea ── */
async function initTicketSystem(user, isNewUser){
  if(!user) return;
  const db=window._fbDb;
  if(!db) return;
  const snap=await db.collection('users').doc(user.uid).get();
  const data=snap.exists?snap.data():{};

  if(isNewUser || data.ticketCount===undefined){
    await db.collection('users').doc(user.uid).set({
      ticketCount:1,
      ticketLastRegen:Date.now(),
      scratchPoints:0,
      scratchPointsEarned:0,
      scratchPointsSpent:0,
    },{merge:true});
    updateTicketBadge(1);
  } else {
    const updated=computeCurrentTickets(data.ticketCount, data.ticketLastRegen||Date.now());
    if(updated.count!==data.ticketCount||updated.lastChecked!==data.ticketLastRegen){
      await saveTicketState(updated.count, updated.lastChecked, data.scratchPoints||0);
    }
    updateTicketBadge(updated.count);
  }
}

/* ── Hook en onAuthStateChanged para inicializar boletos ── */
// Se llamará desde el listener de auth ya existente
window._initTicketSystem=initTicketSystem;

/* ============================================================
   SISTEMA DE MEJORAS (GOAT Points)
   - 3 características: BANQUILLO, CAMBIOS, CONVOCADOS
   - 10 niveles por característica
   - Coste: nivel 1 = 5pts, cada nivel siguiente dobla el anterior
   - Se puede deshacer (recuperar puntos)
   - Se guarda en Firestore: users/{uid}.upgrades
   ============================================================ */

/* ── Helper: leer nivel de mejora activo del usuario (cached en window) ── */
async function loadUserUpgradeLevel(id){
  try{
    if(!window._fbAuth||!window._fbAuth.currentUser) return 0;
    const snap=await window._fbDb.collection('users').doc(window._fbAuth.currentUser.uid).get();
    return (snap.exists&&snap.data().upgrades&&snap.data().upgrades[id])||0;
  }catch(e){ return 0; }
}
// Cache sincrónico — se actualiza en tiempo real via onSnapshot
(function(){
  try{
    const saved=localStorage.getItem('_g2g_upgrades');
    window._upgradeCache=saved?JSON.parse(saved):{bench:0,subs:0,scout:0,chain:0,giro:0};
  }catch(e){ window._upgradeCache={bench:0,subs:0,scout:0,chain:0,giro:0}; }
})();

let _upgradeListener=null; // referencia al listener para poder cancelarlo

function startUpgradeListener(uid){
  // Cancelar listener anterior si existe
  if(_upgradeListener){ _upgradeListener(); _upgradeListener=null; }
  if(!window._fbDb||!uid) return;
  _upgradeListener=window._fbDb.collection('users').doc(uid)
    .onSnapshot(snap=>{
      if(!snap.exists) return;
      const upgs=snap.data().upgrades||{};
      window._upgradeCache={
        bench: upgs.bench||0,
        subs:  upgs.subs||0,
        scout: upgs.scout||0,
        chain: upgs.chain||0,
        giro:  upgs.giro||0,
      };
      try{ localStorage.setItem('_g2g_upgrades',JSON.stringify(window._upgradeCache)); }catch(e){}
    }, e=>{ console.warn('upgrade listener error:',e); });
}

function stopUpgradeListener(){
  if(_upgradeListener){ _upgradeListener(); _upgradeListener=null; }
  window._upgradeCache={bench:0,subs:0,scout:0,chain:0,giro:0};
  try{ localStorage.removeItem('_g2g_upgrades'); }catch(e){}
}

// refreshUpgradeCache sigue disponible para forzar una lectura puntual
async function refreshUpgradeCache(){
  if(!window._fbAuth||!window._fbAuth.currentUser||!window._fbDb) return;
  try{
    const snap=await window._fbDb.collection('users').doc(window._fbAuth.currentUser.uid).get();
    const upgs=(snap.exists&&snap.data().upgrades)||{};
    window._upgradeCache={bench:upgs.bench||0,subs:upgs.subs||0,scout:upgs.scout||0,chain:upgs.chain||0,giro:upgs.giro||0};
    try{ localStorage.setItem('_g2g_upgrades',JSON.stringify(window._upgradeCache)); }catch(e){}
  }catch(e){}
}
// Valores efectivos con mejoras aplicadas
function getMaxBench(){ return 2 + (window._upgradeCache.bench||0); }
function getRecoveryBonus(){ return (window._upgradeCache.recovery||0)*0.10; } // 10% menos fatiga por nivel
function getMaxSubs(){  return 2 + (window._upgradeCache.subs||0); }
function getScoutTeams(){ return 2; } // ya no se usa para equipos
function getPlayersPerTeam(){ return 5 + (window._upgradeCache.scout||0); }
function getMaxGiroCharges(){ return 1 + (window._upgradeCache.giro||0); }

const UPGRADE_DEFS = [
  {
    id: 'bench', icon: '🪑',
    get name(){ return window.t?window.t('upgrade.bench'):'BANQUILLO'; },
    get desc(){ return window.t?window.t('upgrade.bench_desc'):'PLAZAS EN EL BANQUILLO'; },
    baseCost: 5, maxLevel: 5, baseValue: 2,
    tooltip: (lvl) => `${2+lvl} ${t("upgrade.bench_desc")}`
  },
  {
    id: 'subs', icon: '🔄',
    get name(){ return window.t?window.t('upgrade.subs'):'CAMBIOS'; },
    get desc(){ return window.t?window.t('upgrade.subs_desc'):'SUSTITUCIONES POR PARTIDO'; },
    baseCost: 5, maxLevel: 5, baseValue: 2,
    tooltip: (lvl) => `${2+lvl} ${t("upgrade.subs_desc")}`
  },
  {
    id: 'scout', icon: '🔭',
    get name(){ return window.t?window.t('upgrade.scout'):'CONVOCADOS'; },
    get desc(){ return window.t?window.t('upgrade.scout_desc'):'JUGADORES POR EQUIPO AL BARAJAR'; },
    baseCost: 5, maxLevel: 5, baseValue: 5,
    tooltip: (lvl) => `${5+lvl} ${t("upgrade.scout_desc")}`
  },
  {
    id: 'recovery', icon: '⚡',
    get name(){ return window.t?window.t('upgrade.recovery'):'RECUPERACIÓN'; },
    get desc(){ return window.t?window.t('upgrade.recovery_desc'):'REDUCE LA FATIGA ENTRE PARTIDOS'; },
    baseCost: 5, maxLevel: 5, baseValue: 0,
    tooltip: (lvl) => `${lvl*10}% ${t("upgrade.recovery_desc")}`
  },
  {
    id: 'chain', icon: '🔗',
    get name(){ return window.t?window.t('upgrade.chain'):'RUN ENCADENADA'; },
    get desc(){ return window.t?window.t('upgrade.chain_desc'):'JUGADORES CONSERVADOS AL ENCADENAR RUN'; },
    baseCost: 5, maxLevel: 5, baseValue: 1,
    tooltip: (lvl) => `${1+lvl} ${t("upgrade.chain_desc")}`
  },
  {
    id: 'giro', icon: '🔄',
    get name(){ return window.t?window.t('upgrade.giro'):'GIRO TÁCTICO'; },
    get desc(){ return window.t?window.t('upgrade.giro_desc'):'USOS DE GIRO TÁCTICO POR TORNEO'; },
    baseCost: 5, maxLevel: 5, baseValue: 1,
    tooltip: (lvl) => `${1+lvl} ${t("upgrade.giro_desc")}`
  },
];

// Coste acumulado para subir al nivel N (0-indexed: coste para ir de N-1 a N)
function upgradeLevelCost(def, toLevel){
  // nivel 1 = baseCost, nivel 2 = baseCost*2, nivel 3 = baseCost*4...
  return def.baseCost * Math.pow(2, toLevel - 1);
}

// Cargar upgrades de Firestore
async function loadUpgrades(){
  const user = window._fbAuth && window._fbAuth.currentUser;
  if(!user) return {};
  try{
    const snap = await window._fbDb.collection('users').doc(user.uid).get();
    return (snap.exists && snap.data().upgrades) || {};
  }catch(e){ return {}; }
}

// Guardar upgrades en Firestore
async function saveUpgrades(upgrades){
  const user = window._fbAuth && window._fbAuth.currentUser;
  if(!user) return;
  await window._fbDb.collection('users').doc(user.uid).set({upgrades}, {merge:true});
}

// Iconos SVG para mejoras (sin emoji)
const UPGRADE_ICONS = {
  bench:    '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 10v4M20 10v4M2 14h20M6 14v4M18 14v4"/></svg>',
  subs:     '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M7 16l-4-4 4-4"/><path d="M17 8l4 4-4 4"/><line x1="3" y1="12" x2="21" y2="12"/></svg>',
  scout:    '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/><path d="M11 8v6M8 11h6"/></svg>',
  recovery: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
  chain:    '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="2" y="8" width="8" height="8" rx="4"/><rect x="14" y="8" width="8" height="8" rx="4"/><line x1="9" y1="12" x2="15" y2="12"/></svg>',
  giro:     '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/></svg>',
};

// Renderizar la pestaña de mejoras
async function renderUpgradesTab(){
  const list = document.getElementById('upgradesList');
  const pointsEl = document.getElementById('upgradePointsDisplay');
  if(!list) return;
  // Guardar la posición de scroll para restaurarla tras reconstruir la
  // lista — si no, el panel salta arriba al desaparecer el botón pulsado.
  const scrollHost = document.getElementById('profileUpgradesPane');
  const savedScroll = scrollHost ? scrollHost.scrollTop : 0;

  list.innerHTML = `<div style="text-align:center;padding:20px;color:var(--text-muted);font-size:12px">${window.t?window.t('upgrade.loading'):'Cargando...'}</div>`;
  await refreshUpgradeCache();

  const user = window._fbAuth && window._fbAuth.currentUser;
  if(!user){
    list.innerHTML = `<div style="text-align:center;padding:20px;color:var(--text-muted)">${window.t?window.t('upgrade.login'):'Inicia sesión para ver las mejoras.'}</div>`;
    return;
  }

  const snap = await window._fbDb.collection('users').doc(user.uid).get();
  const data = snap.exists ? snap.data() : {};
  let currentPts = data.scratchPoints || 0;
  let upgrades = data.upgrades || {};

  const locked = isTournamentInProgress();
  if(pointsEl) pointsEl.textContent = currentPts;
  list.innerHTML = locked
    ? `<div style="text-align:center;padding:10px;color:var(--gold);font-size:11px;border:1px solid var(--gold);border-radius:6px;margin-bottom:10px">${window.t?window.t('upgrade.locked_tournament'):'🔒 Bloqueado durante el torneo — podrás comprar mejoras al terminarlo'}</div>`
    : '';

  UPGRADE_DEFS.forEach(def => {
    const currentLevel = upgrades[def.id] || 0;
    const nextCost = currentLevel < def.maxLevel ? upgradeLevelCost(def, currentLevel + 1) : null;
    const prevRefund = currentLevel > 0 ? upgradeLevelCost(def, currentLevel) : null;
    const canUpgrade = nextCost !== null && currentPts >= nextCost && !locked;
    const canDowngrade = currentLevel > 0 && !locked;
    const currentVal = def.baseValue + currentLevel;

    const bars = Array.from({length: def.maxLevel}, (_, i) =>
      `<div class="upgrade-bar ${i < currentLevel ? 'filled' : ''}"></div>`
    ).join('');

    const costHtml = nextCost !== null
      ? `<span class="cost-star">★</span>${nextCost}`
      : `<span style="font-size:9px;color:var(--text-muted);letter-spacing:1px">${window.t?window.t('upgrade.max'):'MAX'}</span>`;

    const row = document.createElement('div');
    row.className = 'upgrade-row';
    row.id = `upgrade-row-${def.id}`;
    row.innerHTML = `
      <div class="upgrade-row-top">
        <div class="upgrade-icon" style="color:var(--accent)">${UPGRADE_ICONS[def.id]||''}</div>
        <div class="upgrade-label-block">
          <div class="upgrade-name">${def.name}</div>
          <div class="upgrade-desc">${def.desc}</div>
        </div>
        <div class="upgrade-value-pill">${def.tooltip(currentLevel)}</div>
      </div>
      <div class="upgrade-row-bottom">
        <div class="upgrade-bars">${bars}</div>
        <div class="upgrade-controls">
          <div class="upgrade-cost-badge">${costHtml}</div>
          <button class="upgrade-btn minus" data-id="${def.id}" title="${(window.t?window.t('upgrade.refund'):'Recuperar {0} pts').replace('{0}',prevRefund||0)}" ${canDowngrade?'':'disabled'}>−</button>
          <button class="upgrade-btn plus" data-id="${def.id}" title="${(window.t?window.t('upgrade.cost_title'):'Coste: {0} pts').replace('{0}',nextCost||0)}" ${canUpgrade?'':'disabled'}>+</button>
        </div>
      </div>`;

    list.appendChild(row);
  });

  // Restaurar la posición de scroll ya reconstruida la lista, para que
  // el modal no salte arriba al desaparecer el botón que se pulsó.
  if(scrollHost) requestAnimationFrame(()=>{ scrollHost.scrollTop = savedScroll; });

  // Event listeners
  list.querySelectorAll('.upgrade-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      if(isTournamentInProgress()) return; // por si acaso, aparte del disabled
      const id = btn.dataset.id;
      const def = UPGRADE_DEFS.find(d => d.id === id);
      if(!def) return;
      btn.disabled = true;
      playSound('select');

      const freshSnap = await window._fbDb.collection('users').doc(user.uid).get();
      const freshData = freshSnap.exists ? freshSnap.data() : {};
      let pts = freshData.scratchPoints || 0;
      let upgs = freshData.upgrades || {};
      let lvl = upgs[id] || 0;

      if(btn.classList.contains('plus')){
        const cost = upgradeLevelCost(def, lvl + 1);
        if(lvl >= def.maxLevel || pts < cost) return;
        lvl++; pts -= cost;
      } else {
        if(lvl <= 0) return;
        pts += upgradeLevelCost(def, lvl); lvl--;
      }

      upgs[id] = lvl;
      await window._fbDb.collection('users').doc(user.uid).set({
        scratchPoints: pts, upgrades: upgs,
        scratchPointsSpent: freshData.scratchPointsSpent || 0
      }, {merge: true});
      unlockAchievement('upgrade_once');
      await refreshUpgradeCache(); // actualizar valores efectivos en juego

      const pEl = document.getElementById('upgradePointsDisplay');
      if(pEl) pEl.textContent = pts;
      const statPts = document.getElementById('pstat-scratch-pts');
      if(statPts) statPts.textContent = pts;

      renderUpgradesTab();
    });
  });
}

/* ============================================================
   SISTEMA DE HABILIDADES (Skills)
   - Modificadores especiales comprables con GOAT Points
   - Se pueden activar/desactivar — al desactivar se recuperan los puntos
   - Se guardan en Firestore: users/{uid}.skills
   ============================================================ */

const SKILL_DEFS = [
  // === TÁCTICA ===
  {
    id: 'estratega', get category(){ return window.t?window.t('skill.category.tactica'):'TÁCTICA'; },
    get name(){ return window.t?window.t('skill.estratega'):'ESTRATEGA'; }, cost: 40,
    icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v4l3 3"/></svg>',
    get tooltip(){ return window.t?window.t('skill.estratega_desc'):'Muestra la mejor contra-estrategia antes de cada partido.'; },
  },
  {
    id: 'capitan', get category(){ return window.t?window.t('skill.category.tactica'):'TÁCTICA'; },
    get name(){ return window.t?window.t('skill.capitan'):'CAPITÁN'; }, cost: 30,
    icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
    get tooltip(){ return window.t?window.t('skill.capitan_desc'):'Si vas perdiendo en el descanso, tu ataque sube un 10% en la segunda parte.'; },
  },
  {
    id: 'remontada', get category(){ return window.t?window.t('skill.category.tactica'):'TÁCTICA'; },
    get name(){ return window.t?window.t('skill.remontada'):'REMONTADA'; }, cost: 60,
    icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M18 15l-6-6-6 6"/></svg>',
    get tooltip(){ return window.t?window.t('skill.remontada_desc'):'Si vas perdiendo de 2 o más goles, tu ataque sube un 35% el resto del partido.'; },
  },
  {
    id: 'penaltis', get category(){ return window.t?window.t('skill.category.tactica'):'TÁCTICA'; },
    get name(){ return window.t?window.t('skill.penaltis'):'ESPECIALISTA EN PENALTIS'; }, cost: 35,
    icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><line x1="12" y1="3" x2="12" y2="21"/><line x1="3" y1="12" x2="21" y2="12"/></svg>',
    get tooltip(){ return window.t?window.t('skill.penaltis_desc'):'Aumenta la probabilidad de anotar en tandas de penaltis en un 15%.'; },
  },
  // === PLANTILLA ===
  {
    id: 'medico', get category(){ return window.t?window.t('skill.category.plantilla'):'PLANTILLA'; },
    get name(){ return window.t?window.t('skill.medico'):'MÉDICO DE ÉLITE'; }, cost: 50,
    icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>',
    get tooltip(){ return window.t?window.t('skill.medico_desc'):'Las lesiones leves se recuperan automáticamente al acabar el partido.'; },
  },
  {
    id: 'ojeador', get category(){ return window.t?window.t('skill.category.plantilla'):'PLANTILLA'; },
    get name(){ return window.t?window.t('skill.ojeador'):'OJEADOR'; }, cost: 25,
    icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>',
    get tooltip(){ return window.t?window.t('skill.ojeador_desc'):'Al barajar equipos siempre aparece al menos un jugador con 85 o más de rating.'; },
  },
  {
    id: 'cazatalentos', get category(){ return window.t?window.t('skill.category.plantilla'):'PLANTILLA'; },
    get name(){ return window.t?window.t('skill.cazatalentos'):'CAZATALENTOS'; }, cost: 30,
    icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    get tooltip(){ return window.t?window.t('skill.cazatalentos_desc'):'Los jugadores fuera de su posición natural solo pierden un 5% de rendimiento.'; },
  },
  {
    id: 'veterano', get category(){ return window.t?window.t('skill.category.plantilla'):'PLANTILLA'; },
    get name(){ return window.t?window.t('skill.veterano'):'VETERANO'; }, cost: 45,
    icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
    get tooltip(){ return window.t?window.t('skill.veterano_desc'):'Los jugadores con 85+ de rating no pueden recibir tarjeta roja directa.'; },
  },
  // === ECONOMÍA ===
  {
    id: 'coleccionista', get category(){ return window.t?window.t('skill.category.economia'):'ECONOMÍA'; },
    get name(){ return window.t?window.t('skill.coleccionista'):'COLECCIONISTA'; }, cost: 20,
    icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>',
    get tooltip(){ return window.t?window.t('skill.coleccionista_desc'):'Cada casilla buena del ticket (moneda o cabra) da 1 punto extra.'; },
  },
  {
    id: 'patrocinador', get category(){ return window.t?window.t('skill.category.economia'):'ECONOMÍA'; },
    get name(){ return window.t?window.t('skill.patrocinador'):'PATROCINADOR'; }, cost: 20,
    icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
    get tooltip(){ return window.t?window.t('skill.patrocinador_desc'):'Ganas 1 GOAT Point extra al clasificarte para cuartos de final.'; },
  },
];

// Cache de habilidades activas
window._skillCache = {};

function startSkillListener(uid){
  if(!window._fbDb||!uid) return;
  window._fbDb.collection('users').doc(uid).onSnapshot(snap=>{
    if(!snap.exists) return;
    window._skillCache = (snap.data().skills)||{};
  });
}

// Efecto real de ESTRATEGA: devuelve la mejor contra-estrategia
window.getEstrategaHint = function(){
  if(window._duelId) return null; // deshabilitada en duelos multijugador
  if(!window._skillCache.estratega) return null;
  if(!nextOpponent) return null;
  const rivalKey = getRivalStrategyKey(nextOpponent);
  // Buscar qué estrategia mía contrarresta al rival
  for(const [key, s] of Object.entries(STRATEGIES||{})){
    if(s.counters === rivalKey) return {key, name:s.name};
  }
  return null;
};

async function renderSkillsTab(){
  const list = document.getElementById('skillsList');
  const pointsEl = document.getElementById('skillPointsDisplay');
  if(!list) return;
  // Guardar la posición de scroll para restaurarla tras reconstruir la
  // lista — si no, el panel salta arriba al desaparecer el botón pulsado.
  const scrollHost = document.getElementById('profileNotesPane');
  const savedScroll = scrollHost ? scrollHost.scrollTop : 0;
  list.innerHTML=`<div style="text-align:center;padding:20px;color:var(--text-muted);font-size:12px">${window.t?window.t('skill.loading'):'Cargando...'}</div>`;
  const user = window._fbAuth&&window._fbAuth.currentUser;
  if(!user){ list.innerHTML=`<div style="text-align:center;padding:20px;color:var(--text-muted)">${window.t?window.t('skill.login'):'Inicia sesión para ver las habilidades.'}</div>`; return; }
  const snap = await window._fbDb.collection('users').doc(user.uid).get();
  const data = snap.exists?snap.data():{};
  let pts = data.scratchPoints||0;
  let skills = data.skills||{};
  if(pointsEl) pointsEl.textContent=pts;
  list.innerHTML='';
  list.style.overflowX='hidden';
  list.style.width='100%';
  list.style.paddingRight='12px';
  const skillsLocked = isTournamentInProgress();
  if(skillsLocked){
    const banner=document.createElement('div');
    banner.style.cssText='text-align:center;padding:10px;color:var(--gold);font-size:11px;border:1px solid var(--gold);border-radius:6px;margin-bottom:6px';
    banner.textContent=window.t?window.t('skill.locked_tournament'):'🔒 Bloqueado durante el torneo — podrás activar/desactivar habilidades al terminarlo';
    list.appendChild(banner);
  }

  // Agrupar por categoría, 2 columnas por tipo
  const categories = [...new Set(SKILL_DEFS.map(d=>d.category))];
  categories.forEach(cat=>{
    const catDefs = SKILL_DEFS.filter(d=>d.category===cat);
    const label = document.createElement('div');
    label.style.cssText='font-family:"Bebas Neue",Impact,sans-serif;font-size:11px;letter-spacing:2px;color:var(--text-muted);border-bottom:1px solid var(--line);padding-bottom:4px;margin:12px 0 8px';
    label.textContent=cat;
    list.appendChild(label);
    const grid = document.createElement('div');
    grid.className='skill-grid';
    grid.style.cssText='display:grid;grid-template-columns:1fr 1fr;gap:6px';
    list.appendChild(grid);
    catDefs.forEach(def=>{
      const active = !!skills[def.id];
      const btn = document.createElement('button');
      btn.className='skill-toggle-btn';
      btn.dataset.id=def.id;
      // Mismo tamaño para todos: height fijo con flex column centrado
      btn.style.cssText=`display:flex;flex-direction:column;align-items:center;justify-content:space-between;gap:0;border:2px solid ${active?'var(--gold)':'var(--line)'};background:${active?'rgba(201,162,39,.12)':'var(--panel)'};color:${active?'var(--gold)':'var(--text)'};cursor:${skillsLocked?'not-allowed':'pointer'};transition:.15s;text-align:center;width:100%;box-sizing:border-box;overflow:hidden;height:160px;opacity:${skillsLocked?.55:1}`;
      const iconPart=`<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;padding:12px 8px 8px;flex:1">
        <span style="color:${active?'var(--gold)':'var(--accent)'}">${def.icon.replace(/width="22"/g,'width="26"').replace(/height="22"/g,'height="26"')}</span>
        <span style="font-family:'Bebas Neue',Impact,sans-serif;font-size:13px;letter-spacing:.8px;color:${active?'var(--gold)':'var(--text)'};line-height:1.1">${def.name}</span>
        <span style="font-size:10px;color:${active?'var(--accent)':'var(--text-muted)'};line-height:1.4;padding:0 4px">${def.tooltip}</span>
      </div>`;
      const footerPart=`<div style="width:100%;padding:6px;background:${active?'rgba(201,162,39,.15)':'rgba(0,0,0,.15)'};border-top:1px solid ${active?'rgba(201,162,39,.3)':'var(--line)'}">
        <span style="font-family:'Bebas Neue',Impact,sans-serif;font-size:12px;color:${active?'var(--gold)':'var(--text-muted)'};letter-spacing:1px">${active?(window.t?window.t('skill.active_footer'):'✓ ACTIVA · PULSA PARA DESACTIVAR'):'★ '+def.cost+' PTS'}</span>
      </div>`;
      btn.innerHTML=iconPart+footerPart;
      btn.addEventListener('click', async()=>{
        if(skillsLocked) return;
        btn.disabled=true;
        playSound('select');
        const fs2=await window._fbDb.collection('users').doc(user.uid).get();
        const fd=fs2.exists?fs2.data():{};
        let p=fd.scratchPoints||0;
        let sk=fd.skills||{};
        if(sk[def.id]){
          delete sk[def.id]; p+=def.cost;
        } else {
          if(p<def.cost){ btn.disabled=false; return; }
          sk[def.id]=true; p-=def.cost;
        }
        await window._fbDb.collection('users').doc(user.uid).update({
          scratchPoints: p,
          skills: sk
        });
        const pEl=document.getElementById('skillPointsDisplay');
        if(pEl) pEl.textContent=p;
        const statPts=document.getElementById('pstat-scratch-pts');
        if(statPts) statPts.textContent=p;
        // Logros de habilidades
        unlockAchievement('use_skill');
        if(Object.keys(sk).length>=3) unlockAchievement('use_3_skills');
        if(Object.keys(sk).length>=5) unlockAchievement('5_skills');
        renderSkillsTab();
      });
      grid.appendChild(btn);
    });
  });

  // Restaurar la posición de scroll ya reconstruida la lista, para que
  // el modal no salte arriba al desaparecer el botón que se pulsó.
  if(scrollHost) requestAnimationFrame(()=>{ scrollHost.scrollTop = savedScroll; });

  // Eliminar el viejo listener loop que ya no existe
}

/* showPatchNotes — llamado desde Ajustes */
window.showPatchNotes=function(){
  const o=document.getElementById('patchNotesOverlay');
  if(o) o.style.display='flex';
};

/* ============================================================
   SISTEMA DE LOGROS
   Dificultad → recompensa: básico=1, intermedio=2, difícil=3, mítico=25
   Se guardan en Firestore: users/{uid}.achievements (set de ids)
   ============================================================ */

const ACHIEVEMENT_DEFS = [
  // BÁSICOS — 1 PT
  {id:'first_match',      tier:'básico',  pts:1,  icon:'ph-megaphone',        name:'PITIDO INICIAL',       desc:'Completa tu primer partido'},
  {id:'first_win',        tier:'básico',  pts:1,  icon:'ph-trophy',         name:'PRIMERA VICTORIA',     desc:'Gana tu primer partido'},
  {id:'first_ticket',     tier:'básico',  pts:1,  icon:'ph-ticket',         name:'PRIMER RASCA',         desc:'Gana puntos en tu primer ticket'},
  {id:'clean_sheet',      tier:'básico',  pts:1,  icon:'ph-shield-check',   name:'PORTERÍA A CERO',      desc:'Gana un partido sin encajar ningún gol'},
  {id:'no_subs_win',      tier:'básico',  pts:1,  icon:'ph-swap',          name:'SIN ROTACIONES',       desc:'Gana un partido sin usar ningún cambio'},
  {id:'first_groups',     tier:'básico',  pts:1,  icon:'ph-flag', name:'FASE SUPERADA',        desc:'Clasifícate para octavos de final'},
  {id:'score_5',          tier:'básico',  pts:1,  icon:'ph-soccer-ball',    name:'GOLEADA',              desc:'Marca 5 goles o más en un partido'},
  {id:'win_comeback',     tier:'básico',  pts:1,  icon:'ph-arrow-bend-up-left','name':'VUELTA AL PARTIDO',  desc:'Gana un partido después de ir perdiendo'},
  {id:'use_skill',        tier:'básico',  pts:1,  icon:'ph-lightning',      name:'PRIMER PODER',         desc:'Activa tu primera habilidad'},
  {id:'full_bench',       tier:'básico',  pts:1,  icon:'ph-users',          name:'PLANTILLA COMPLETA',   desc:'Llega a un partido con el banquillo lleno'},
  {id:'hattrick_player',  tier:'básico',  pts:1,  icon:'ph-number-three',            name:'HAT-TRICK',            desc:'Un mismo jugador marca 3 goles en un partido'},
  {id:'win_no_concede2',  tier:'básico',  pts:1,  icon:'ph-wall',           name:'DOBLE CERROJO',        desc:'No encajes goles en 2 partidos consecutivos'},
  {id:'all_stars',        tier:'básico',  pts:1,  icon:'ph-star',           name:'ONCE PERFECTO',        desc:'Coloca los 11 titulares en su posición natural ★'},
  {id:'first_pen_win',    tier:'básico',  pts:1,  icon:'ph-crosshair',      name:'NERVIOS DE ACERO',     desc:'Gana una tanda de penaltis'},
  {id:'upgrade_once',     tier:'básico',  pts:1,  icon:'ph-arrow-circle-up','name':'PRIMERA MEJORA',     desc:'Sube por primera vez cualquier mejora'},

  // INTERMEDIOS — 2 PTS
  {id:'groups_unbeaten',  tier:'intermedio', pts:2, icon:'ph-shield',        name:'INVICTO EN GRUPOS',   desc:'Pasa la fase de grupos sin perder ningún partido'},
  {id:'groups_no_concede',tier:'intermedio', pts:2, icon:'ph-shield-star', name:'MURALLA EN GRUPOS',   desc:'No encajes ningún gol en toda la fase de grupos'},
  {id:'quarters',         tier:'intermedio', pts:2, icon:'ph-medal',         name:'CUARTOS',              desc:'Clasifícate para cuartos de final'},
  {id:'semis',            tier:'intermedio', pts:2, icon:'ph-medal', name:'SEMIFINAL',              desc:'Llega a semifinales'},
  {id:'comeback_2',       tier:'intermedio', pts:2, icon:'ph-arrow-fat-lines-up',  name:'REMONTADA ÉPICA',     desc:'Gana un partido después de ir perdiendo de 2 goles'},
  {id:'perfect_tactic',   tier:'intermedio', pts:2, icon:'ph-graph',      name:'TÁCTICA MAESTRA',     desc:'Usa la contra-estrategia perfecta y gana el partido'},
  {id:'no_injuries_semis',tier:'intermedio', pts:2, icon:'ph-plus-circle', name:'HIERRO FORJADO',      desc:'Llega a semifinales sin ningún jugador lesionado'},
  {id:'score_7',          tier:'intermedio', pts:2, icon:'ph-fire',          name:'ARROLLADOR',           desc:'Marca 7 goles o más en un partido'},
  {id:'5_nineties',       tier:'intermedio', pts:2, icon:'ph-crown',         name:'EQUIPO DE LEYENDA',   desc:'Forma un equipo con 5 jugadores de rating 90 o superior'},
  {id:'two_pen_wins',     tier:'intermedio', pts:2, icon:'ph-target',        name:'REY DE PENALTIS',     desc:'Gana dos tandas de penaltis en el mismo torneo'},
  {id:'use_3_skills',     tier:'intermedio', pts:2, icon:'ph-toolbox',     name:'ESPECIALISTA',         desc:'Activa simultáneamente 3 habilidades distintas'},
  {id:'win_5_row',        tier:'intermedio', pts:2, icon:'ph-trend-up',      name:'RACHA GANADORA',      desc:'Gana 5 partidos consecutivos'},
  {id:'50_goat_pts',      tier:'intermedio', pts:2, icon:'ph-coins',         name:'BUEN CONTRATO',       desc:'Acumula 50 GOAT Points sin gastar ninguno'},
  {id:'score_10_group',   tier:'intermedio', pts:2, icon:'ph-chart-bar',     name:'MÁQUINA GOLEADORA',   desc:'Marca 10 goles o más en toda la fase de grupos'},
  {id:'win_all_groups',   tier:'intermedio', pts:2, icon:'ph-check-square',  name:'PLENO EN GRUPOS',     desc:'Gana los 3 partidos de la fase de grupos'},

  // DIFÍCILES — 3 PTS
  {id:'champion',         tier:'difícil', pts:3, icon:'ph-trophy',          name:'CAMPEÓN MUNDIAL',      desc:'Gana el Mundial'},
  {id:'champion_unbeaten',tier:'difícil', pts:3, icon:'ph-star',       name:'CAMPEÓN INVICTO',      desc:'Gana el Mundial sin perder ningún partido'},
  {id:'all_wins',         tier:'difícil', pts:3, icon:'ph-circles-four',        name:'SIETE DE SIETE',       desc:'Gana los 7 partidos del torneo sin empatar'},
  {id:'100_pts',          tier:'difícil', pts:3, icon:'ph-bank',           name:'CAJA FUERTE',          desc:'Acumula 100 GOAT Points sin gastar ninguno'},
  {id:'concede_1',        tier:'difícil', pts:3, icon:'ph-lock',            name:'BAJO SIETE LLAVES',    desc:'Encaja solo 1 gol o menos en todo el torneo'},
  {id:'5_skills',         tier:'difícil', pts:3, icon:'ph-lightning',       name:'MANAGER TOTAL',        desc:'Activa simultáneamente 5 habilidades'},
  {id:'hattrick_final',   tier:'difícil', pts:3, icon:'ph-number-three',             name:'HÉROE DE LA FINAL',    desc:'Un jugador marca 3 goles en la final del Mundial'},
  {id:'10_clean_sheets',  tier:'difícil', pts:3, icon:'ph-shield-check',    name:'PORTERO LEGENDARIO',   desc:'Consigue 10 porterías a cero a lo largo de tus partidas'},
  {id:'pen_win_final',    tier:'difícil', pts:3, icon:'ph-crosshair','name':'FINAL EN PENALTIS',  desc:'Gana la final del Mundial en la tanda de penaltis'},
  {id:'all_achievements_basic', tier:'difícil', pts:3, icon:'ph-seal-check','name':'PROFESIONAL',       desc:'Desbloquea todos los logros básicos'},

  // MÍTICO — 25 PTS
  {id:'triple_crown',     tier:'mítico',  pts:25, icon:'ph-crown',   name:'GOAT ABSOLUTO',        desc:'Gana el Mundial 3 veces'},
];

const TIER_COLOR = {básico:'#aaa', intermedio:'#2ecc71', difícil:'#e67e22', mítico:'#f0c419'};
function getTierLabel(tier){
  return {
    básico:      window.t?window.t('tier.pts.basic')     :'★ 1 PT',
    intermedio:  window.t?window.t('tier.pts.intermediate'):'★ 2 PTS',
    difícil:     window.t?window.t('tier.pts.hard')      :'★ 3 PTS',
    mítico:      window.t?window.t('tier.pts.mythic')    :'★ 25 PTS',
  }[tier]||'';
}

// Cache de logros
window._achievementsCache = new Set();

function startAchievementsListener(uid){
  if(!window._fbDb||!uid) return;
  window._fbDb.collection('users').doc(uid).onSnapshot(snap=>{
    if(!snap.exists) return;
    const achs = snap.data().achievements||[];
    window._achievementsCache = new Set(achs);
  });
}

window._pendingAchievements = []; // logros ganados durante partido, se muestran al final

async function unlockAchievement(id){
  if(window._achievementsCache.has(id)) return; // ya desbloqueado
  const user = window._fbAuth&&window._fbAuth.currentUser;
  if(!user) return;
  const def = ACHIEVEMENT_DEFS.find(a=>a.id===id);
  if(!def) return;
  window._achievementsCache.add(id);
  try{
    const snap = await window._fbDb.collection('users').doc(user.uid).get();
    const d = snap.exists?snap.data():{};
    const current = d.achievements||[];
    if(current.includes(id)) return;
    const newPts = (d.scratchPoints||0)+def.pts;
    await window._fbDb.collection('users').doc(user.uid).set({
      achievements:[...current,id],
      scratchPoints: newPts,
      scratchPointsEarned:(d.scratchPointsEarned||0)+def.pts
    },{merge:true});
    // Si hay partido activo, encolar para mostrar al final
    if(document.getElementById('matchOverlay')&&document.getElementById('matchOverlay').innerHTML!=''){
      window._pendingAchievements.push(def);
    } else {
      showAchievementToast(def);
    }
    showGoatPointsBadge();
    // Badge en la pestaña LOGROS
    const ab=document.getElementById('achievementsBadge');
    if(ab){ ab.style.display='inline-block'; try{localStorage.setItem('_g2g_ach_pending','1');}catch(e){} }
    // Actualizar displays de puntos
    const pEl=document.getElementById('upgradePointsDisplay');
    if(pEl) pEl.textContent=newPts;
    const pEl2=document.getElementById('skillPointsDisplay');
    if(pEl2) pEl2.textContent=newPts;
    const pEl3=document.getElementById('pstat-scratch-pts');
    if(pEl3) pEl3.textContent=newPts;
  }catch(e){ console.warn('Achievement error:',e); }
}

function showAchievementToast(def){
  const toast=document.createElement('div');
  toast.style.cssText=`position:fixed;bottom:80px;left:50%;transform:translateX(-50%);
    background:#1a1a0a;border:2px solid ${TIER_COLOR[def.tier]};
    padding:12px 20px;z-index:99999;display:flex;align-items:center;gap:12px;
    font-family:'Bebas Neue',Impact,sans-serif;min-width:280px;max-width:90vw;
    animation:slideUpToast .4s ease;box-shadow:0 8px 24px rgba(0,0,0,.6)`;
  toast.innerHTML=`
    <i class="ph ph-bold ${def.icon}" style="font-size:28px;color:${TIER_COLOR[def.tier]}"></i>
    <div>
      <div style="font-size:10px;letter-spacing:2px;color:${TIER_COLOR[def.tier]};margin-bottom:2px">${t("match.achievement_unlocked")} · ${getTierLabel(def.tier)}</div>
      <div style="font-size:16px;color:#fff;letter-spacing:1px">${window.t?window.t('ach.'+def.id)||def.name:def.name}</div>
      <div style="font-size:11px;color:#aaa;margin-top:2px">${window.t?window.t('ach.'+def.id+'.d')||def.desc:def.desc}</div>
    </div>`;
  document.body.appendChild(toast);
  setTimeout(()=>{ toast.style.transition='opacity .5s'; toast.style.opacity='0'; setTimeout(()=>toast.remove(),500); },4000);
}

async function checkAllBasicAchievements(unlocked){
  const basics=ACHIEVEMENT_DEFS.filter(a=>a.tier==='básico').map(a=>a.id);
  if(basics.every(id=>unlocked.has(id))) unlockAchievement('all_achievements_basic');
}
async function renderAchievementsTab(){
  const list=document.getElementById('achievementsList');
  if(!list) return;
  list.innerHTML=`<div style="text-align:center;padding:20px;color:var(--text-muted);font-size:12px">${window.t?window.t('skill.loading'):'Cargando...'}</div>`;
  const user=window._fbAuth&&window._fbAuth.currentUser;
  if(!user){ list.innerHTML=`<div style="text-align:center;padding:20px;color:var(--text-muted)">${window.t?window.t('achievements.login'):'Inicia sesión para ver tus logros.'}</div>`; return; }
  const snap=await window._fbDb.collection('users').doc(user.uid).get();
  const unlocked=new Set((snap.exists&&snap.data().achievements)||[]);
  const total=ACHIEVEMENT_DEFS.length;
  const done=[...unlocked].filter(id=>ACHIEVEMENT_DEFS.find(a=>a.id===id)).length;
  list.innerHTML='';
  list.style.paddingRight='12px';

  // Progreso general
  const progress=document.createElement('div');
  progress.style.cssText='display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;font-family:"Bebas Neue",Impact,sans-serif';
  progress.innerHTML=`<span style="font-size:13px;color:var(--text-muted);letter-spacing:1px">${done} / ${total} ${window.t?window.t('achievements.progress'):'LOGROS'}</span>
    <span style="font-size:13px;color:var(--gold)">${ACHIEVEMENT_DEFS.filter(a=>unlocked.has(a.id)).reduce((s,a)=>s+a.pts,0)} ${window.t?window.t('achievements.pts_earned'):'PTS GANADOS'}</span>`;
  list.appendChild(progress);

  // Grid 2 columnas
  const grid=document.createElement('div');
  grid.style.cssText='display:grid;grid-template-columns:1fr 1fr;gap:6px;padding-right:4px';
  list.appendChild(grid);

  ACHIEVEMENT_DEFS.forEach(def=>{
    const isUnlocked=unlocked.has(def.id);
    const isLight=document.body.classList.contains('light-theme');
    const card=document.createElement('div');
    const lockedBg=isLight?'#ede8df':'#1a1e20';
    const unlockedBg=isLight?'#e8f4ec':'rgba(0,0,0,.3)';
    const borderColor=isUnlocked?TIER_COLOR[def.tier]:(isLight?'#d4cec4':'var(--line)');
    card.style.cssText='display:flex;align-items:center;gap:10px;padding:10px;border:1px solid '+borderColor+';background:'+(isUnlocked?unlockedBg:lockedBg)+';position:relative;overflow:hidden';
    const achName=window.t?window.t('ach.'+def.id)||def.name:def.name;
    const achDesc=window.t?window.t('ach.'+def.id+'.d')||def.desc:def.desc;
    const iconColor=isUnlocked?'#c9a227':(isLight?'#bbb':'var(--text-muted)');
    const iconHtml='<i class="ph ph-bold '+def.icon+'" style="font-size:26px;flex-shrink:0;color:'+iconColor+';'+(isUnlocked?'':' opacity:.5')+'"></i>';
    const checkHtml=isUnlocked?'<i class="ph ph-bold ph-check" style="position:absolute;top:5px;right:6px;font-size:12px;color:'+(TIER_COLOR[def.tier]||'#c9a227')+'" ></i>':'';
    const tierColor=TIER_COLOR[def.tier]||'#aaa';
    const tierLabel=getTierLabel(def.tier)||'';
    const nameColor=isUnlocked?(isLight?'#1a1a1a':'#fff'):(isLight?'#333':'var(--text-muted)');
    const descColor=isUnlocked?(isLight?'#444':'#aaa'):(isLight?'#666':'var(--text-muted)');
    card.innerHTML=iconHtml+checkHtml+
      '<div style="min-width:0;flex:1">'+ 
      '<div style="font-size:12px;letter-spacing:.8px;color:'+nameColor+';line-height:1.2;font-weight:700">'+achName+'</div>'+
      '<div style="font-size:9px;color:'+descColor+';line-height:1.4;margin-top:2px">'+achDesc+'</div>'+
      '<div style="font-size:9px;color:'+tierColor+';letter-spacing:1px;margin-top:3px">'+tierLabel+'</div>'+
      '</div>';
    grid.appendChild(card);
  });
}


// Añadir CSS para el toast
(function(){
  const s=document.createElement('style');
  s.textContent=`@keyframes slideUpToast{from{transform:translateX(-50%) translateY(20px);opacity:0}to{transform:translateX(-50%) translateY(0);opacity:1}}`;
  document.head.appendChild(s);
})();


/* ============================================================
   APLICAR TRADUCCIONES — recorre data-i18n y actualiza textos
   ============================================================ */
window.applyTranslations = function(){
  // Actualizar todos los elementos con data-i18n (texto plano, solo leaf nodes)
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key=el.dataset.i18n;
    const text=window.t(key);
    if(text!==key) el.textContent=text;
  });
  // Actualizar placeholders
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{
    const key=el.dataset.i18nPlaceholder;
    const text=window.t(key);
    if(text!==key) el.placeholder=text;
  });
  document.querySelectorAll('[data-i18n-html]').forEach(el=>{
    const key=el.dataset.i18nHtml;
    const text=window.t(key);
    if(text!==key) el.innerHTML=text;
  });
  // Re-renderizar el tip actual en el idioma nuevo
  renderCurrentTip();
  // Re-renderizar lista de formaciones (labels traducibles)
  if(typeof renderFormationList==='function') renderFormationList(currentFormation.category);
  // Re-renderizar info card de formación si está visible
  if(typeof lockFormationDisplay==='function'){
    const infoCard=document.getElementById('formationInfoCard');
    if(infoCard&&infoCard.style.display!=='none') lockFormationDisplay();
  }
  // Re-renderizar formación en resumen móvil
  if(typeof renderMobileFormationInfo==='function') renderMobileFormationInfo();
  // Re-renderizar convocados y banquillo (cabeceras de tabla y textos dinámicos)
  if(typeof updateConvocadosTable==='function') updateConvocadosTable();
  if(typeof updateBenchTable==='function') updateBenchTable();
  if(typeof updateDraftCounter==='function') updateDraftCounter();
  // Re-renderizar ranking si está visible (overlay o panel móvil)
  const rankOv=document.getElementById('rankingOverlay');
  if(rankOv&&rankOv.style.display!=='none'&&typeof window.loadRanking==='function') window.loadRanking('rankingTableDesktop');
  const rankPanel=document.getElementById('rankingPanel');
  if(rankPanel&&rankPanel.classList.contains('mob-active')&&typeof window.loadRanking==='function') window.loadRanking('rankingTable');
  // Re-renderizar historial de resultados (nombres de países y cabeceras de tabla)
  if(typeof renderMatchHistory==='function') renderMatchHistory();
  if(typeof renderRivalBox==='function' && document.getElementById('rivalBox') && document.getElementById('rivalBox').style.display!=='none') renderRivalBox();
  if(typeof renderWeather==='function') renderWeather();
  // Re-renderizar welcome si está visible
  const wo=document.getElementById('welcomeOverlay');
  if(wo&&wo.style.display!=='none'){
    const wt=document.getElementById('welcomeText');
    const wrb=document.getElementById('welcomeRegisterBtn');
    const isGuest=wrb&&wrb.style.display!=='none';
    if(wt) wt.innerHTML=window.t?window.t(isGuest?'welcome.text_guest':'welcome.text_user'):'';
    if(wrb&&isGuest) wrb.textContent=window.t?window.t('welcome.register'):'REGÍSTRATE';
  }
  // Re-renderizar selección de equipo si está visible (sin animación de slot)
  if(window._lastTeamChoice){
    const {t1,p1,t2,p2,isBench}=window._lastTeamChoice;
    const isMobile=window.innerWidth<=1050;
    const targetEl=isMobile?document.getElementById('playerCard'):playerCardEl;
    if(targetEl&&targetEl.querySelector('.team-option')){
      const title=isBench?(window.t?window.t('draft.choose_bench'):'ELIGE JUGADOR DE BANQUILLO'):(window.t?window.t('draft.choose_team'):'ELIGE UNA SELECCIÓN');
      targetEl.innerHTML=`<div class="box"><div class="selection-title">${title}</div><div class="team-options">${teamOptionHTML(t1,p1)}${teamOptionHTML(t2,p2)}</div></div>`;
    }
  }
  // Re-renderizar roster si está visible
  if(window._lastRoster){
    const {team,players}=window._lastRoster;
    const isMobile=window.innerWidth<=1050;
    const targetEl=isMobile?document.getElementById('playerCard'):playerCardEl;
    if(targetEl&&targetEl.querySelector('.roster-modal')){
      showRosterModal(team,players);
    }
  }
  if(document.getElementById('profileOverlay')&&document.getElementById('profileOverlay').style.display!=='none'){
    if(typeof renderUpgradesTab==='function'&&document.getElementById('profileUpgradesPane')&&document.getElementById('profileUpgradesPane').classList.contains('profile-tab-pane-active')) renderUpgradesTab();
    if(typeof renderSkillsTab==='function'&&document.getElementById('profileNotesPane')&&document.getElementById('profileNotesPane').classList.contains('profile-tab-pane-active')) renderSkillsTab();
    if(typeof renderAchievementsTab==='function'&&document.getElementById('profileAchievementsPane')&&document.getElementById('profileAchievementsPane').classList.contains('profile-tab-pane-active')) renderAchievementsTab();
  }
  // Actualizar botones de idioma activo
  ['Es','En','Pt','Fr','De','It'].forEach(l=>{
    const lang=l.toLowerCase();
    const active=window.LANG===lang;
    const style=active?';border-color:var(--gold);color:var(--gold)':';border-color:var(--line);color:var(--text)';
    const b1=document.getElementById('lang'+l+'Btn');
    const b2=document.getElementById('lang'+l+'Btn2');
    if(b1) b1.style.cssText+=style;
    if(b2) b2.style.cssText+=style;
  });
  // Botones del header
  // ranking-btn text handled by data-i18n span inside
  // Tabs móvil
  const mobLabels=[
    ['mob-tab-campo','mob.campo'],['mob-tab-equipo','mob.equipo'],
    ['mob-tab-rival','mob.rival'],['mob-tab-historial','mob.historial'],
    ['mob-tab-info','mob.info'],['mob-tab-ranking','mob.ranking'],
  ];
  mobLabels.forEach(([id,key])=>{
    const btn=document.getElementById(id);
    if(!btn) return;
    const icon=btn.querySelector('i,.mob-tab-icon');
    const badge=btn.querySelector('.mob-tab-badge');
    const label=btn.querySelector('.mob-tab-label');
    if(label) label.textContent=window.t(key);
  });
  // Botones de acción principales
  const selectBtn=document.querySelector('[onclick*="showTeamSelectModal"],.main-action-btn');
  // Actualizar el sort label de convocados
  const sortLabel=document.getElementById('convSortLabel');
  if(sortLabel){
    const CONV_SORT_LABELS_I18N={arrival:'draft.sort_arrival',position:'draft.sort_position',rating:'draft.sort_rating'};
    sortLabel.textContent=window.t(CONV_SORT_LABELS_I18N[window.convSortMode]||'draft.sort_position');
  }
  // Re-renderizar historial (nombres de países y cabeceras de tabla en tiempo real)
  if(typeof renderMatchHistory==='function') renderMatchHistory();
};

/* ════════════════════════════════════════════════════════════
   SISTEMA DE AMIGOS / MULTIJUGADOR
   Solo accesible con sesión iniciada y debug mode (CHEATS_ACTIVE) activo.
   Colección Firestore: 'friends' — documento por relación:
   { userId, friendId, friendUsername, status: 'pending'|'accepted', createdAt, requestedBy }
   ════════════════════════════════════════════════════════════ */

/* Listeners en vivo del modal de amigos — se activan al abrir, se desconectan al cerrar */
let mpUnsubFriends1=null, mpUnsubFriends2=null, mpUnsubRequests=null, mpUnsubDuels=null;

window.openMpOverlay = function(){
  const ov=$id('mpOverlay');
  if(!ov) return;
  playSound('select');
  ov.style.display='flex';
  if(window.applyTranslations) window.applyTranslations();
  startMpLiveListeners();
};

window.closeMpOverlay = function(){
  const ov=$id('mpOverlay');
  if(ov) ov.style.display='none';
  stopMpLiveListeners();
};

function startMpLiveListeners(){
  stopMpLiveListeners(); // por seguridad, evita duplicados si se reabre rápido
  const auth=window._fbAuth, db=window._fbDb;
  const user=auth&&auth.currentUser;
  if(!user||!db) return;
  // Solicitudes pendientes recibidas — tiempo real (un solo where, filtro en JS)
  mpUnsubRequests=db.collection('friends')
    .where('friendId','==',user.uid)
    .onSnapshot(()=>renderPendingRequests(), e=>console.error('mpUnsubRequests error:',e));
  // Amistades aceptadas (en ambas direcciones) — tiempo real (un solo where, filtro en JS)
  mpUnsubFriends1=db.collection('friends')
    .where('userId','==',user.uid)
    .onSnapshot(()=>renderFriendsList(), e=>console.error('mpUnsubFriends1 error:',e));
  mpUnsubFriends2=db.collection('friends')
    .where('friendId','==',user.uid)
    .onSnapshot(()=>renderFriendsList(), e=>console.error('mpUnsubFriends2 error:',e));
  // Desafíos de duelo recibidos — tiempo real (un solo where, filtro en JS)
  mpUnsubDuels=db.collection('duels')
    .where('opponentId','==',user.uid)
    .onSnapshot(()=>renderPendingDuels(), e=>console.error('mpUnsubDuels error:',e));
}

function stopMpLiveListeners(){
  if(mpUnsubFriends1){ mpUnsubFriends1(); mpUnsubFriends1=null; }
  if(mpUnsubFriends2){ mpUnsubFriends2(); mpUnsubFriends2=null; }
  if(mpUnsubRequests){ mpUnsubRequests(); mpUnsubRequests=null; }
  if(mpUnsubDuels){ mpUnsubDuels(); mpUnsubDuels=null; }
}

/* Añadir amigo por nombre de usuario o email — solo usuarios YA registrados en Firestore */
async function mpAddFriend(){
  playSound('select');
  const input=$id('mpFriendInput');
  const errEl=$id('mpAddFriendErr');
  const okEl=$id('mpAddFriendOk');
  if(errEl){errEl.style.display='none';errEl.textContent='';}
  if(okEl){okEl.style.display='none';okEl.textContent='';}
  const query=(input?input.value:'').trim();
  if(!query){
    if(errEl){errEl.textContent=tk('mp.err_empty');errEl.style.display='block';}
    return;
  }
  const auth=window._fbAuth, db=window._fbDb;
  const user=auth&&auth.currentUser;
  if(!user){
    if(errEl){errEl.textContent=tk('mp.err_login');errEl.style.display='block';}
    return;
  }
  const btn=$id('mpAddFriendBtn');
  if(btn){btn.disabled=true;btn.textContent=tk('mp.searching');}
  try{
    // Buscar por username_lower o por email exacto — solo usuarios registrados
    let targetDoc=null;
    const isEmail=query.includes('@');
    if(isEmail){
      const snap=await db.collection('users').where('email','==',query.toLowerCase()).get();
      if(!snap.empty) targetDoc=snap.docs[0];
    }else{
      const snap=await db.collection('users').where('username_lower','==',query.toLowerCase()).get();
      if(!snap.empty) targetDoc=snap.docs[0];
    }
    if(!targetDoc){
      if(errEl){errEl.textContent=tk('mp.err_not_found');errEl.style.display='block';}
      return;
    }
    const targetUid=targetDoc.id;
    const targetData=targetDoc.data();
    if(targetUid===user.uid){
      if(errEl){errEl.textContent=tk('mp.err_self');errEl.style.display='block';}
      return;
    }
    // Comprobar si ya existe relación (en cualquier dirección) — un solo where, filtro en JS
    // IMPORTANTE: ambas queries deben filtrar por un campo == auth.uid (requisito de las
    // reglas de seguridad de Firestore, que exigen poder demostrar el acceso sin ejecutar
    // la query primero). Por eso existing2 usa friendId==user.uid, no userId==targetUid.
    const existing1=await db.collection('friends')
      .where('userId','==',user.uid).get();
    const existing2=await db.collection('friends')
      .where('friendId','==',user.uid).get();
    const already1=existing1.docs.some(d=>d.data().friendId===targetUid);
    const already2=existing2.docs.some(d=>d.data().userId===targetUid);
    if(already1 || already2){
      if(errEl){errEl.textContent=tk('mp.err_already');errEl.style.display='block';}
      return;
    }
    // Obtener username propio
    const mySnap=await db.collection('users').doc(user.uid).get();
    const myUsername=mySnap.exists?mySnap.data().username:user.email;
    // Crear solicitud pendiente (bidireccional con un solo doc + status)
    await db.collection('friends').add({
      userId:user.uid, userUsername:myUsername,
      friendId:targetUid, friendUsername:targetData.username||targetData.email,
      status:'pending', requestedBy:user.uid,
      createdAt:Date.now()
    });
    if(okEl){okEl.textContent=tk('mp.request_sent').replace('{0}',targetData.username||targetData.email);okEl.style.display='block';}
    if(input) input.value='';
  }catch(e){
    console.error('mpAddFriend error:',e);
    if(errEl){errEl.textContent=tk('mp.err_generic');errEl.style.display='block';}
  }finally{
    if(btn){btn.disabled=false;btn.textContent=tk('mp.add_btn');}
  }
}

/* Cargar solicitudes pendientes recibidas */
async function renderPendingRequests(){
  const auth=window._fbAuth, db=window._fbDb;
  const user=auth&&auth.currentUser;
  const section=$id('mpRequestsSection');
  const list=$id('mpRequestsList');
  if(!user||!db||!section||!list) return;
  try{
    const snap=await db.collection('friends')
      .where('friendId','==',user.uid).get();
    const pendingDocs=snap.docs.filter(d=>d.data().status==='pending');
    if(!pendingDocs.length){ section.style.display='none'; return; }
    section.style.display='block';
    list.innerHTML='';
    pendingDocs.forEach(doc=>{
      const d=doc.data();
      const row=document.createElement('div');
      row.className='mp-row';
      row.innerHTML=`
        <span class="mp-row-name">${mpEsc(d.userUsername||'???')}</span>
        <div style="display:flex;gap:6px">
          <button class="mp-accept-btn mp-btn-accept" data-id="${doc.id}">${tk('mp.accept')}</button>
          <button class="mp-reject-btn mp-btn-reject" data-id="${doc.id}">${tk('mp.reject')}</button>
        </div>`;
      list.appendChild(row);
    });
    list.querySelectorAll('.mp-accept-btn').forEach(b=>b.addEventListener('click',()=>mpRespondRequest(b.dataset.id,true)));
    list.querySelectorAll('.mp-reject-btn').forEach(b=>b.addEventListener('click',()=>mpRespondRequest(b.dataset.id,false)));
  }catch(e){console.error('renderPendingRequests error:',e);}
}

async function mpRespondRequest(docId,accept){
  playSound('select');
  const db=window._fbDb;
  if(!db) return;
  try{
    if(accept){
      await db.collection('friends').doc(docId).update({status:'accepted', acceptedAt:Date.now()});
    }else{
      await db.collection('friends').doc(docId).delete();
    }
    // El refresco es automático vía onSnapshot — no se requiere llamada manual
  }catch(e){console.error('mpRespondRequest error:',e);}
}

/* Cargar lista de amigos aceptados */
/* Eliminar amigo de la lista (con confirmación) */
async function mpRemoveFriend(docId, username){
  const ok=await mpShowConfirmRemove(username);
  if(!ok) return;
  const db=window._fbDb;
  if(!db) return;
  try{
    await db.collection('friends').doc(docId).delete();
    // El refresco es automático vía onSnapshot — no se requiere llamada manual
  }catch(e){
    console.error('mpRemoveFriend error:',e);
    alert(tk('mp.err_generic'));
  }
}

/* Modal de confirmación in-app para eliminar amigo (sustituye al confirm() nativo) */
function mpShowConfirmRemove(username){
  return new Promise(resolve=>{
    const ov=$id('mpConfirmRemoveOverlay');
    const txt=$id('mpConfirmRemoveText');
    const okBtn=$id('mpConfirmRemoveOk');
    const cancelBtn=$id('mpConfirmRemoveCancel');
    if(!ov||!txt||!okBtn||!cancelBtn){ resolve(false); return; }
    txt.textContent=(tk('mp.confirm_remove')||'¿Eliminar a {0} de tus amigos?').replace('{0}', username||'');
    ov.style.display='flex';
    const cleanup=(result)=>{
      ov.style.display='none';
      okBtn.removeEventListener('click', onOk);
      cancelBtn.removeEventListener('click', onCancel);
      ov.removeEventListener('click', onOverlayClick);
      resolve(result);
    };
    const onOk=()=>cleanup(true);
    const onCancel=()=>cleanup(false);
    const onOverlayClick=(e)=>{ if(e.target===ov) cleanup(false); };
    okBtn.addEventListener('click', onOk);
    cancelBtn.addEventListener('click', onCancel);
    ov.addEventListener('click', onOverlayClick);
  });
}

async function renderFriendsList(){
  const auth=window._fbAuth, db=window._fbDb;
  const user=auth&&auth.currentUser;
  const list=$id('mpFriendsList');
  if(!user||!db||!list) return;
  list.innerHTML=`<div class="mp-empty-state">${tk('mp.loading')}</div>`;
  try{
    const snap1=await db.collection('friends')
      .where('userId','==',user.uid).get();
    const snap2=await db.collection('friends')
      .where('friendId','==',user.uid).get();
    const friends=[];
    snap1.forEach(doc=>{const d=doc.data();if(d.status==='accepted')friends.push({id:doc.id,uid:d.friendId,username:d.friendUsername});});
    snap2.forEach(doc=>{const d=doc.data();if(d.status==='accepted')friends.push({id:doc.id,uid:d.userId,username:d.userUsername});});
    if(!friends.length){
      list.innerHTML=`<div class="mp-empty-state">${tk('mp.no_friends')}</div>`;
      return;
    }
    list.innerHTML='';
    const table=document.createElement('table');
    table.className='mp-friends-table';
    table.innerHTML=`<thead><tr>
        <th data-i18n="mp.col_friend">${tk('mp.col_friend')}</th>
        <th class="mp-col-action"></th>
        <th class="mp-col-action"></th>
      </tr></thead><tbody></tbody>`;
    const tbody=table.querySelector('tbody');
    friends.forEach(f=>{
      const row=document.createElement('tr');
      row.className='mp-friend-row';
      row.innerHTML=`
        <td class="mp-row-name">${mpEsc(f.username||'???')}</td>
        <td class="mp-col-action"><button class="mp-challenge-btn mp-btn-challenge" data-uid="${f.uid}" data-username="${mpEsc(f.username||'')}" title="${tk('mp.challenge')}">${tk('mp.challenge')}</button></td>
        <td class="mp-col-action"><button class="mp-remove-btn mp-btn-remove" data-id="${f.id}" data-username="${mpEsc(f.username||'')}" title="${tk('mp.remove')}">✕</button></td>`;
      tbody.appendChild(row);
    });
    list.appendChild(table);
    list.querySelectorAll('.mp-remove-btn').forEach(b=>b.addEventListener('click',()=>mpRemoveFriend(b.dataset.id, b.dataset.username)));
    list.querySelectorAll('.mp-challenge-btn').forEach(b=>b.addEventListener('click',()=>mpChallengeFriend(b.dataset.uid, b.dataset.username, b)));
  }catch(e){
    console.error('renderFriendsList error:',e);
    list.innerHTML=`<div class="mp-empty-state" style="color:var(--red)">${tk('mp.err_generic')}</div>`;
  }
}

function mpEsc(s){ return String(s==null?'':s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

/* ════════════════════════════════════════════════════════════
   DUELO — CÁLCULO DE PARTIDO (Fase 3, primera entrega)
   Reutiliza las mismas fórmulas que playMatch() en solitario
   (tacticalModifier, poissonSample, STRATEGIES) pero aplicadas de
   forma simétrica a dos plantillas reales en vez de jugador-vs-IA.
   NOTA: esta primera versión no incluye lesiones/tarjetas en vivo
   durante el partido (ver aviso en el resumen del chat).
   ════════════════════════════════════════════════════════════ */
function duelSquadPower(squad){
  const pl=(squad.pitch||[]).slice(0,11);
  const avg=pl.length?pl.reduce((s,p)=>s+(p.rating||75),0)/pl.length:75;
  const bonusBoost=Object.values(squad.teamStats||{}).reduce((a,b)=>a+(Math.abs(b)||0),0)*0.12;
  const fatigueAvg=pl.length?pl.reduce((s,p)=>s+(p.fatigue===undefined?100:p.fatigue),0)/pl.length:100;
  const fatiguePenalty=(100-fatigueAvg)/100*3.5;
  return avg + bonusBoost - fatiguePenalty;
}
function duelStreakBonus(squad){
  let bonus=0;
  (squad.pitch||[]).forEach(p=>{
    if(p.placedPos && ["DC","EI","ED","MC"].includes(p.placedPos)){
      const streak=(squad.scorerStreaks&&squad.scorerStreaks[p.name])||0;
      bonus+=Math.min(streak,MAX_STREAK_BONUS)*0.015;
    }
  });
  return bonus;
}
function duelCounterModifier(myKey, rivalKey){
  if(!myKey && !rivalKey) return {myScoreMod:0, oppScoreMod:0};
  const rivalStrat=STRATEGIES[rivalKey], myStrat=STRATEGIES[myKey];
  const rivalCountersMe = rivalStrat && rivalStrat.counters===myKey;
  const iCounterRival    = myStrat && myStrat.counters===rivalKey;
  const iPartiallyCounterRival = myStrat && myStrat.partialCounters && myStrat.partialCounters.includes(rivalKey);
  let mod=0;
  if(iCounterRival)               mod=0.16;
  else if(iPartiallyCounterRival) mod=0.08;
  else if(rivalCountersMe)        mod=-0.10;
  else if(myKey && myKey===rivalKey) mod=-0.04;
  return {myScoreMod:mod, oppScoreMod:-mod*0.5};
}
function duelRollCards(pitchArr){
  const carded=[];
  (pitchArr||[]).forEach(p=>{
    const r=Math.random();
    const minute=Math.floor(5+Math.random()*90);
    if(r<RED_RISK_PER_PLAYER){ carded.push({player:{name:p.name}, type:'red', minute}); }
    else if(r<RED_RISK_PER_PLAYER+YELLOW_RISK_PER_PLAYER){ carded.push({player:{name:p.name}, type:'yellow', minute}); }
  });
  return carded;
}
function duelRollInjuries(pitchArr, foulerPool){
  const injured=[];
  (pitchArr||[]).forEach(p=>{
    if(injured.length>=1) return;
    if(Math.random()<0.06){
      const r=Math.random();
      let type, foulCard=null;
      if(r<0.5){ type='leve'; foulCard=Math.random()<0.8?'yellow':null; }
      else if(r<0.85){ type='básica'; foulCard=Math.random()<0.6?'yellow':'red'; }
      else { type='grave'; foulCard='red'; }
      const minute=Math.floor(20+Math.random()*65);
      let foulerName=null;
      if(foulCard && foulerPool && foulerPool.length){
        foulerName=foulerPool[Math.floor(Math.random()*foulerPool.length)].name;
      }
      injured.push({name:p.name, type, _foulCard:foulCard, injury:{foulCard,type}, minute, foulerName});
    }
  });
  return injured;
}
function computeDuelMatchResult(challengerSquad, opponentSquad, challengerStrategy, opponentStrategy){
  const chalPower=duelSquadPower(challengerSquad);
  const oppPower=duelSquadPower(opponentSquad);
  const diff=(chalPower-oppPower)*0.03;
  const tactical=tacticalModifier(challengerSquad.teamStats||{}, opponentSquad.teamStats||{});
  const counter=duelCounterModifier(challengerStrategy, opponentStrategy);
  const chalMorale=((challengerSquad.teamMorale||0)/50)*0.15;
  const oppMorale=((opponentSquad.teamMorale||0)/50)*0.15;
  const chalStreak=duelStreakBonus(challengerSquad);
  const oppStreak=duelStreakBonus(opponentSquad);
  const weatherDelta=weatherLambdaEffect(); // condición compartida del partido, igual para ambos
  const chalCaptain=(challengerSquad.skills&&challengerSquad.skills.capitan&&(challengerSquad.teamMorale||0)<0)?0.10:0;
  const oppCaptain=(opponentSquad.skills&&opponentSquad.skills.capitan&&(opponentSquad.teamMorale||0)<0)?0.10:0;
  const chalLambda=Math.max(0.25, 1.15+diff+tactical.myScoreMod+counter.myScoreMod+chalMorale+chalStreak+weatherDelta+chalCaptain);
  const oppLambda=Math.max(0.25, 1.15-diff+tactical.oppScoreMod+counter.oppScoreMod+oppMorale+oppStreak+weatherDelta+oppCaptain);
  let challengerGoals=poissonSample(chalLambda);
  let opponentGoals=poissonSample(oppLambda);
  if(challengerSquad.skills&&challengerSquad.skills.remontada&&opponentGoals>=challengerGoals+2){
    challengerGoals=poissonSample(chalLambda*1.35);
  }
  if(opponentSquad.skills&&opponentSquad.skills.remontada&&challengerGoals>=opponentGoals+2){
    opponentGoals=poissonSample(oppLambda*1.35);
  }
  // Fatiga real de los titulares tras el partido — misma fórmula que en solitario
  const challengerFatigue={}, opponentFatigue={};
  (challengerSquad.pitch||[]).slice(0,11).forEach(p=>{
    challengerFatigue[p.name]=Math.max(0, Math.round((p.fatigue===undefined?100:p.fatigue)-(2+Math.random()*4)));
  });
  (opponentSquad.pitch||[]).slice(0,11).forEach(p=>{
    opponentFatigue[p.name]=Math.max(0, Math.round((p.fatigue===undefined?100:p.fatigue)-(2+Math.random()*4)));
  });
  const challengerCards=duelRollCards(challengerSquad.pitch);
  const opponentCards=duelRollCards(opponentSquad.pitch);
  const challengerInjuries=duelRollInjuries(challengerSquad.pitch, opponentSquad.pitch);
  const opponentInjuries=duelRollInjuries(opponentSquad.pitch, challengerSquad.pitch);
  const possession=Math.round(45+Math.random()*20);
  // Goleadores, minutos y tiros — calculados aquí (por el retador) y
  // guardados, para que ambos dispositivos vean exactamente los mismos
  // nombres y minutos en vez de sortearlos cada uno por su cuenta.
  const chalAttackers=(challengerSquad.pitch||[]).filter(p=>p.placedPos&&["DC","EI","ED","MC"].includes(p.placedPos));
  const oppAttackers=(opponentSquad.pitch||[]).filter(p=>p.placedPos&&["DC","EI","ED","MC"].includes(p.placedPos));
  const chalPool=chalAttackers.length?chalAttackers:(challengerSquad.pitch||[]);
  const oppPool=oppAttackers.length?oppAttackers:(opponentSquad.pitch||[]);
  const chalMinutes=[]; for(let i=0;i<challengerGoals;i++) chalMinutes.push(Math.floor(5+Math.random()*85));
  const oppMinutes=[]; for(let i=0;i<opponentGoals;i++) oppMinutes.push(Math.floor(5+Math.random()*85));
  chalMinutes.sort((a,b)=>a-b); oppMinutes.sort((a,b)=>a-b);
  const challengerGoalEvents=chalMinutes.map(min=>({name:chalPool.length?chalPool[Math.floor(Math.random()*chalPool.length)].name:null, minute:min}));
  const opponentGoalEvents=oppMinutes.map(min=>({name:oppPool.length?oppPool[Math.floor(Math.random()*oppPool.length)].name:null, minute:min}));
  const shotsChallenger=challengerGoals*2+Math.floor(Math.random()*5)+3;
  const shotsOpponent=opponentGoals*2+Math.floor(Math.random()*4)+2;
  return {challengerGoals, opponentGoals, challengerFatigue, opponentFatigue, challengerCards, opponentCards,
    challengerInjuries, opponentInjuries, possession, challengerGoalEvents, opponentGoalEvents, shotsChallenger, shotsOpponent,
    challengerBaseLambda:chalLambda, opponentBaseLambda:oppLambda};
}

/* Pantalla de selección de estrategia para el partido actual del duelo */
/* Pantalla de estrategia + gestión de plantilla, usada tanto para el
   partido 1 como para los siguientes — usa los elementos REALES del
   juego (banquillo + panel de rival con selector de estrategia), igual
   que en solitario, nunca un popup superpuesto. */
/* Hash determinista simple — con la misma semilla (duelId+partido) da
   siempre el mismo resultado en los dos navegadores, sin tener que
   escribir nada extra a Firestore para sincronizar la decisión. */
function mpSimpleHash(str){
  let h=0;
  for(let i=0;i<str.length;i++){ h=(h*31+str.charCodeAt(i))|0; }
  return Math.abs(h);
}
/* Rueda de prensa antes de un partido del duelo — misma probabilidad
   que en solitario. Si toca, le aparece a AMBOS jugadores (semilla
   compartida), cada uno respondiendo la suya. El temporizador de
   gestión no empieza hasta que esta pantalla se cierra. */
function mpMaybeShowPressConference(idx, callback){
  const seed=(window._duelId||'')+':'+idx;
  const roll=mpSimpleHash(seed+':roll')%100;
  if(roll>=30){ callback(); return; }
  const events=getPressEvents();
  if(!events||!events.length){ callback(); return; }
  const eventIdx=mpSimpleHash(seed+':event')%events.length;
  showPressEventModal(events[eventIdx], ()=>{ pendingPrediction=null; callback(); });
}

function mpShowStrategyAndBenchPhase(){
  const idx=window._duelMatchIndex;
  mpMaybeShowPressConference(idx, ()=>mpRenderStrategyAndBenchPhase(idx));
}

function mpRenderStrategyAndBenchPhase(idx){
  selectedMatchStrategy=null;
  if(idx===0){
    // Giro Táctico: usos disponibles para todo el duelo (misma cantidad
    // real que en solitario: 1 base + mejora comprada).
    window._giroCharges=getMaxGiroCharges();
  }
  swapsUsedThisMatch=0;
  convSortMode='position';
  swapSelection=null;
  // Limpiar cualquier resto de la ventana de partido anterior
  const mo=document.getElementById('matchOverlay');
  if(mo) mo.innerHTML='';
  const liveExit=document.getElementById('duelLiveExitLink'); if(liveExit) liveExit.remove();
  const matchBadge=document.getElementById('duelMatchBadge'); if(matchBadge) matchBadge.remove();
  mpHideDuelOverlay();

  document.getElementById("benchSection").style.display="block";
  document.getElementById("moraleSection").style.display="block";
  document.getElementById("rivalBox").style.display="block";
  const matchHistoryBox=document.getElementById("matchHistoryBox"); if(matchHistoryBox) matchHistoryBox.style.display="none";
  const playBtn=document.getElementById("playMatchBtn"); if(playBtn) playBtn.style.display="none";
  // Por si se llega aquí tras recargar a mitad de duelo (sin pasar por el
  // draft normal), asegurar que estos botones siguen ocultos.
  const rollBtnEl=document.getElementById("rollBtn"); if(rollBtnEl) rollBtnEl.style.display="none";
  const qbWrap=document.getElementById("quickBuildWrap"); if(qbWrap) qbWrap.style.display="none";
  refreshPitchRatings();
  updateConvocadosTable();
  updateBenchTable();
  renderMorale();

  // Cabecera del panel de rival, adaptada a un oponente humano
  const rivalInfo=document.getElementById('rivalInfo');
  if(rivalInfo) rivalInfo.innerHTML=`<div style="text-align:center;padding:4px 0 8px">
      <i class="ph ph-bold ph-user" style="font-size:26px;color:#7b9cff"></i>
      <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:16px;margin-top:4px">${mpEsc(window._duelOpponentUsername||'')}</div>
    </div>`;
  const rivalHint=document.getElementById('rivalHint');
  if(rivalHint) rivalHint.innerHTML=`<div class="style-label">${(tk('mp.duel_match_of')||'PARTIDO {0} DE 5').replace('{0}', String(idx+1))}</div>`;
  const weatherDisplay=document.getElementById('weatherDisplay'); if(weatherDisplay) weatherDisplay.style.display='none';

  renderStrategySelector();

  // Cambiar el punto de interés móvil al panel del rival al empezar
  // la gestión del equipo (partido 1 o entre partidos)
  if(typeof switchMobileTab==='function') setTimeout(()=>switchMobileTab('rival'), 150);

  let actionsWrap=document.getElementById('duelStrategyActions');
  if(!actionsWrap){
    actionsWrap=document.createElement('div');
    actionsWrap.id='duelStrategyActions';
    const rb=document.getElementById('rivalBox');
    if(rb) rb.appendChild(actionsWrap);
  }
  actionsWrap.innerHTML=`
    <button id="duelConfirmStrategyBtn" class="modal-btn" style="width:100%;margin-top:10px">${tk('mp.duel_confirm_strategy')||'CONFIRMAR Y ESPERAR AL RIVAL'}</button>
    <div id="duelStrategyWaitMsg" style="display:none;font-size:12px;color:var(--text-muted);margin-top:8px;text-align:center">${tk('mp.duel_waiting_strategy')||'Esperando la estrategia del rival...'}</div>`;
  const btn=document.getElementById('duelConfirmStrategyBtn');
  if(btn) btn.addEventListener('click', mpConfirmStrategyAndSquad);

  // Cuenta atrás de 30s — barra fina de progreso bajo el header, no lo tapa.
  let bar=document.getElementById('duelBetweenBar');
  if(!bar){
    bar=document.createElement('div');
    bar.id='duelBetweenBar';
    bar.style.cssText='position:fixed;left:0;right:0;z-index:70000;background:rgba(20,32,44,.94);padding:4px 10px;font-family:"Bebas Neue",Impact,sans-serif;letter-spacing:.5px;font-size:11px;color:#7ec3ff;display:flex;align-items:center;gap:8px';
    bar.innerHTML=`<span id="duelBarLabel" style="white-space:nowrap"></span>
      <div style="flex:1;height:6px;background:#0d1620;border-radius:3px;overflow:hidden">
        <div id="duelBarFill" style="height:100%;width:100%;background:linear-gradient(90deg,#4a90d9,#7ec3ff)"></div>
      </div>`;
    document.body.appendChild(bar);
  }
  mpAttachStickyBarScroll('duelBetweenBar');
  bar.style.display='flex';
  const totalMs=30000;
  const deadline=Date.now()+totalMs;
  const labelEl=document.getElementById('duelBarLabel');
  const fillEl=document.getElementById('duelBarFill');
  const matchLabel=(tk('mp.duel_match_of')||'PARTIDO {0} DE 5').replace('{0}', String(idx+1));
  const tick=()=>{
    const msLeft=deadline-Date.now();
    if(msLeft<=0){
      if(_duelTimerInterval){ clearInterval(_duelTimerInterval); _duelTimerInterval=null; }
      mpConfirmStrategyAndSquad();
      return;
    }
    const secLeft=Math.ceil(msLeft/1000);
    checkCountdownBeep(secLeft, 'duelStrategyBar');
    if(labelEl) labelEl.textContent=`${matchLabel} — `+(tk('mp.duel_between_time')||'⏱️ {0}s').replace('{0}', String(secLeft));
    if(fillEl) fillEl.style.width=Math.max(0, msLeft/totalMs*100)+'%';
  };
  tick();
  _duelTimerInterval=setInterval(tick,200);
}

/* Envía plantilla (por si hubo cambios) + estrategia elegida para el
   partido actual, y espera a que el rival haga lo mismo. */
async function mpConfirmStrategyAndSquad(){
  playSound('select');
  if(_duelTimerInterval){ clearInterval(_duelTimerInterval); _duelTimerInterval=null; }
  const bar=document.getElementById('duelBetweenBar'); if(bar) bar.style.display='none';
  mpDetachStickyBarScroll('duelBetweenBar');
  const db=window._fbDb;
  if(!db||!window._duelId) return;
  const btn=document.getElementById('duelConfirmStrategyBtn');
  if(btn) btn.disabled=true;
  const waitMsg=document.getElementById('duelStrategyWaitMsg');
  if(waitMsg) waitMsg.style.display='block';
  const idx=window._duelMatchIndex;
  const squad={
    pitch: usedPlayers.map(p=>({name:p.name, rating:p.rating, positions:p.positions, placedPos:p.placedPos, fatigue:(p.fatigue===undefined?100:p.fatigue)})),
    bench: bench.map(p=>({name:p.name, rating:p.rating, positions:p.positions})),
    formation: currentFormation,
    teamStats:{...teamStats},
    teamMorale: (typeof teamMorale!=='undefined')?teamMorale:0,
    scorerStreaks: usedPlayers.reduce((acc,p)=>{ if(scorerStreaks[p.name]) acc[p.name]=scorerStreaks[p.name]; return acc; },{}),
    skills: window._skillCache?{...window._skillCache}:{}
  };
  const squadField=window._duelRole==='challenger'?'challengerSquad':'opponentSquad';
  const stratField=window._duelRole==='challenger'?`m${idx}_challengerStrategy`:`m${idx}_opponentStrategy`;
  try{
    await db.collection('duels').doc(window._duelId).update({
      [squadField]: squad,
      [stratField]: selectedMatchStrategy||'__none__',
      currentMatchIndex: idx
    });
  }catch(e){ console.error('mpConfirmStrategyAndSquad error:',e); }
  document.getElementById("benchSection").style.display="none";
  document.getElementById("moraleSection").style.display="none";
  document.getElementById("rivalBox").style.display="none";
  mpShowWaitingPopup(`${(tk('mp.duel_match_of')||'PARTIDO {0} DE 5').replace('{0}', String(idx+1))}<br><span style="font-size:12px;font-weight:normal">${tk('mp.duel_waiting_strategy')||'Esperando la estrategia del rival...'}</span>`);
  mpWatchForMatchResult();
}

/* Espera a que ambas estrategias estén enviadas. El retador calcula el
   resultado y lo guarda; ambos lo leen de ahí para verlo idéntico. */
function mpWatchForMatchResult(){
  const db=window._fbDb;
  if(!db||!window._duelId) return;
  const idx=window._duelMatchIndex;
  const resultField=`m${idx}_result`;
  const chalKey=`m${idx}_challengerStrategy`, oppKey=`m${idx}_opponentStrategy`;
  const unsub=db.collection('duels').doc(window._duelId).onSnapshot(async snap=>{
    const d=snap.data();
    if(!d) return;
    if(d.status==='cancelled'){ unsub(); mpExitDuelMode(); location.reload(); return; }
    if(d[resultField]){ unsub(); mpPlayDuelMatchAnimation(d[resultField], d.challengerSquad, d.opponentSquad); return; }
    if(window._duelRole==='challenger' && d[chalKey]!==undefined && d[oppKey]!==undefined){
      unsub();
      const chalStrategy=d[chalKey]==='__none__'?null:d[chalKey];
      const oppStrategy=d[oppKey]==='__none__'?null:d[oppKey];
      const result=computeDuelMatchResult(d.challengerSquad, d.opponentSquad, chalStrategy, oppStrategy);
      try{ await db.collection('duels').doc(window._duelId).update({[resultField]: result}); }
      catch(e){ console.error('mpWatchForMatchResult compute error:',e); }
      mpPlayDuelMatchAnimation(result, d.challengerSquad, d.opponentSquad);
    }
  }, e=>console.error('mpWatchForMatchResult error:',e));
}

/* Resultado del partido actual — versión simple (marcador), sin animación
   minuto a minuto todavía. */
/* Genera el resumen de goles con el mismo formato HTML que usa
   generateMatchSummary() en solitario — showLiveMatch() ya sabe
   interpretarlo, así que no hace falta tocar esa función. */
function generateDuelMatchSummary(myGoalEvents, rivalGoalEvents, myShots, rivalShots, opponentUsername, myPossession){
  const possession=myPossession!==undefined?myPossession:50;
  const oppPoss=100-possession;
  const scorers=[];
  const myGoalLines=(myGoalEvents||[]).map(ev=>{
    if(ev.name) scorers.push(ev.name);
    return `<li>⚽ ${ev.name?mpEsc(ev.name):'Desconocido'} <span class="goal-min">(${ev.minute}')</span></li>`;
  });
  generateDuelMatchSummary._scorers=scorers; // para la racha de goleador, igual que en solitario
  generateDuelMatchSummary._lastStats={possession, oppPoss, shots:myShots, oppShots:rivalShots};
  const oppGoalLines=(rivalGoalEvents||[]).map(ev=>
    `<li>⚽ ${ev.name?mpEsc(ev.name):mpEsc(opponentUsername)} <span class="goal-min">(${ev.minute}')</span></li>`);
  const myLabel=(window.myTeamName||myTeamName||'TU EQUIPO');
  const goalsHTML=`
  <div class="goals-columns">
    <div class="goals-col">
      <div class="goals-col-header"><i class="ph ph-bold ph-user" style="color:#4a90d9;vertical-align:middle;margin-right:2px"></i> ${myLabel}</div>
      <ul class="goals-list">${myGoalLines.length?myGoalLines.join(''):'<li class="no-goal">Sin goles</li>'}</ul>
    </div>
    <div class="goals-col">
      <div class="goals-col-header"><i class="ph ph-bold ph-user" style="color:#e74c3c;vertical-align:middle;margin-right:2px"></i> ${mpEsc(opponentUsername)}</div>
      <ul class="goals-list">${oppGoalLines.length?oppGoalLines.join(''):'<li class="no-goal">Sin goles</li>'}</ul>
    </div>
  </div>`;
  const tt=k=>window.t?window.t(k):k;
  return `<strong>${tt("match.possession")||'Posesión'}:</strong> ${myLabel} ${possession}% · ${mpEsc(opponentUsername)} ${oppPoss}%<br>
<strong>${tt("match.shots")||'Tiros'}:</strong> ${myShots} – ${rivalShots}
${goalsHTML}`;
}

/* Reproduce el partido con la MISMA animación minuto a minuto que el
   modo un jugador, reutilizando showLiveMatch() sin modificarlo. */
function mpPlayDuelMatchAnimation(result, challengerSquad, opponentSquad){
  const myGoals=window._duelRole==='challenger'?result.challengerGoals:result.opponentGoals;
  const rivalGoals=window._duelRole==='challenger'?result.opponentGoals:result.challengerGoals;
  const mySquad=window._duelRole==='challenger'?challengerSquad:opponentSquad;
  const rivalSquad=window._duelRole==='challenger'?opponentSquad:challengerSquad;
  const myCards=(window._duelRole==='challenger'?result.challengerCards:result.opponentCards)||[];
  const rivalCards=(window._duelRole==='challenger'?result.opponentCards:result.challengerCards)||[];
  const myInjuries=(window._duelRole==='challenger'?result.challengerInjuries:result.opponentInjuries)||[];
  const rivalInjuries=(window._duelRole==='challenger'?result.opponentInjuries:result.challengerInjuries)||[];
  const won=myGoals>rivalGoals, draw=myGoals===rivalGoals;
  // Aplicar la fatiga real calculada por el retador a mi propia plantilla local
  const myFatigueMap=(window._duelRole==='challenger'?result.challengerFatigue:result.opponentFatigue)||{};
  usedPlayers.forEach(p=>{ if(myFatigueMap[p.name]!==undefined) p.fatigue=myFatigueMap[p.name]; });
  const myGoalEvents=(window._duelRole==='challenger'?result.challengerGoalEvents:result.opponentGoalEvents)||[];
  const rivalGoalEvents=(window._duelRole==='challenger'?result.opponentGoalEvents:result.challengerGoalEvents)||[];
  const myShots=(window._duelRole==='challenger'?result.shotsChallenger:result.shotsOpponent)||0;
  const rivalShots=(window._duelRole==='challenger'?result.shotsOpponent:result.shotsChallenger)||0;
  updateScorerStreaks(generateDuelMatchSummary._scorers||[]);
  const myPossession=window._duelRole==='challenger'?result.possession:(100-result.possession);
  const summary=generateDuelMatchSummary(myGoalEvents, rivalGoalEvents, myShots, rivalShots, window._duelOpponentUsername||'Rival', myPossession);
  mpHideDuelOverlay();
  document.getElementById("benchSection").style.display="none";
  document.getElementById("moraleSection").style.display="none";
  window._duelLastMatchStats={myGoals,rivalGoals,myCards,rivalCards,myInjuries,rivalInjuries,won,draw};
  // Contexto para Giro Táctico en duelo — permite recalcular el tramo
  // restante lo pida quien lo pida, sin depender del retador.
  window._giroDuelCtx={
    duelId: window._duelId,
    matchIndex: window._duelMatchIndex,
    myRole: window._duelRole,
    mySquad, rivalSquad,
    challengerSquad, opponentSquad,
    opponentUsername: window._duelOpponentUsername,
    result
  };
  window._giroLambdaCtx=null; // este contexto es solo de solitario, no aplica aquí
  showLiveMatch(myGoals, rivalGoals, summary, [], myInjuries, won, draw, null, myCards, null, {injuries:rivalInjuries, cards:rivalCards});
  mpAddDuelExitLinkToLiveMatch();
}

/* Pequeño enlace de abandono flotante durante la animación en vivo,
   ya que en solitario no existe (no se puede "abandonar" contra la IA). */
function mpAddDuelExitLinkToLiveMatch(){
  let link=document.getElementById('duelLiveExitLink');
  if(link) link.remove();
  link=document.createElement('div');
  link.id='duelLiveExitLink';
  link.textContent=tk('mp.duel_exit')||'ABANDONAR ENCUENTRO';
  link.style.cssText='position:fixed;bottom:12px;right:12px;z-index:90000;cursor:pointer;color:#ff7e7e;background:#3a1a1a;border:1px solid #d94a4a;font-family:"Bebas Neue",Impact,sans-serif;font-size:14px;letter-spacing:.5px;padding:10px 16px;border-radius:5px';
  link.addEventListener('click', mpAbandonDuel);
  document.body.appendChild(link);
}

/* Tras ver el resultado: si quedan partidos, ventana de 15s para tocar
   convocados/banquillo; si era el 5º, resumen final. */
/* ════════════════════════════════════════════════════════════════
   TANDA DE PENALTIS — exclusiva de duelo multijugador. Si un partido
   del duelo termina en empate, en vez de contar como empate se juega
   esta tanda visual (5 lanzamientos cada uno + muerte súbita, reglas
   Mundial) para decidir un ganador real de ese partido.
   Diseño de sincronización: en cada lanzamiento hay un tirador y un
   portero (se alternan). El TIRADOR es siempre quien resuelve el
   lanzamiento y avanza a la siguiente ronda — el otro simplemente
   adopta el resultado ya escrito, sin recalcular nada (mismo patrón
   que el resto del duelo). El RETADOR es quien inicializa la tanda
   (evita que los dos la inicien a la vez).
   ════════════════════════════════════════════════════════════════ */
const PENALTY_ZONES=[
  {id:'arriba_izquierda', x:18, y:30},
  {id:'arriba_derecha',   x:85, y:30},
  {id:'centro',           x:51, y:40},
  {id:'abajo_izquierda',  x:18, y:49},
  {id:'abajo_derecha',    x:85, y:49},
];
const PENALTY_KICK_MS=5000;
// Tiempo que tardan los dos dispositivos en terminar de ver la animación
// del lanzamiento anterior (2000ms chuta + 1400ms resultado + 450ms
// respiro) antes de que aparezcan los círculos del siguiente — hay que
// sumarlo al plazo, si no los 5s ya se han comido casi enteros para
// cuando el jugador por fin puede elegir.
const PENALTY_ANIM_DELAY_MS=3850;

function mpPenaltyShooterRoleForKick(kickNum){
  // Pares = retador tira, impares = rival tira — igual en la tanda
  // base (5 rondas) y en la muerte súbita.
  return kickNum%2===0 ? 'challenger' : 'opponent';
}

async function mpMaybeStartPenalties(){
  const db=window._fbDb;
  const idx=window._duelMatchIndex;
  if(!db||!window._duelId) return;
  const ref=db.collection('duels').doc(window._duelId);
  if(window._duelRole==='challenger'){
    // Solo el retador inicializa, para evitar que los dos lo hagan a la vez
    try{
      const snap=await ref.get();
      const d=snap.exists?snap.data():{};
      if(!d[`m${idx}_penActive`]){
        await ref.update({
          [`m${idx}_penActive`]: true,
          [`m${idx}_penHistory`]: [],
          [`m${idx}_penCurrent`]: {kickNum:0, shooterRole:mpPenaltyShooterRoleForKick(0), deadline:Date.now()+PENALTY_KICK_MS, shooterZone:null, keeperZone:null}
        });
      }
    }catch(e){ console.error('[Penaltis] init falló:', e); }
  }
  mpRenderPenaltyShootoutScreen();
}

function mpRenderPenaltyShootoutScreen(){
  const overlay=document.getElementById('matchOverlay');
  if(!overlay) return;
  overlay.innerHTML=`
    <div class="match-modal" style="max-width:520px;padding:14px;display:flex;flex-direction:column;align-items:center;gap:8px">
      <div style="font-family:'Bebas Neue',Impact,sans-serif;color:var(--gold);letter-spacing:1.5px;font-size:16px">TANDA DE PENALTIS</div>
      <div id="penScoreLine" style="font-family:'Bebas Neue',Impact,sans-serif;font-size:26px;letter-spacing:2px">0 – 0</div>
      <div id="penKickLabel" style="font-size:11px;color:var(--text-muted)"></div>
      <div id="penTurnLabel" style="font-family:'Bebas Neue',Impact,sans-serif;font-size:14px;letter-spacing:1px"></div>
      <div style="width:90%;max-width:280px;height:4px;background:#222;border-radius:3px;overflow:hidden">
        <div id="penTimerFill" style="height:100%;width:100%;background:var(--gold);transition:width .1s linear"></div>
      </div>
      <div id="penSub" style="font-size:12px;color:var(--gold);min-height:14px;font-weight:700"></div>
      <div id="penStageWrap" style="position:relative;width:min(90vw,86vh,460px);height:min(90vw,86vh,460px);margin:0 auto">
        <img src="assets/penaltis/escenario.png" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain">
        <img id="penBalon" src="assets/penaltis/balon_iddle.png" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain">
        <img id="penPortero" src="" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain">
        <img id="penJugador" src="" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain">
        <div id="penZones" style="position:absolute;inset:0"></div>
      </div>
      <div id="penHistoryRow" style="display:flex;gap:5px;flex-wrap:wrap;justify-content:center;margin-top:4px"></div>
    </div>`;
  mpPenaltyAttachListener();
}

let mpPenListenerUnsub=null, mpPenTimerHandle=null, mpPenRenderedKick=-1, mpPenMyChoice=null;
let mpPenAnimatedCount=0, mpPenAnimating=false, mpPenPendingFinish=null, mpPenResolvingKick=-1;
function mpPenaltyAttachListener(){
  mpPenaltyDetachListener();
  mpPenAnimatedCount=0; mpPenAnimating=false; mpPenPendingFinish=null;
  mpPenRenderedKick=-1; mpPenResolvingKick=-1;
  const db=window._fbDb;
  if(!db||!window._duelId) return;
  const idx=window._duelMatchIndex;
  mpPenListenerUnsub=db.collection('duels').doc(window._duelId).onSnapshot(snap=>{
    const d=snap.data();
    if(!d) return;
    if(d.status==='cancelled'){ mpPenaltyDetachListener(); mpExitDuelMode(); location.reload(); return; }
    const hist=d[`m${idx}_penHistory`]||[];
    const cur=d[`m${idx}_penCurrent`];
    const winner=d[`m${idx}_penWinner`];

    // Si hay un lanzamiento en el historial que este dispositivo aún no
    // ha animado, reproducirlo ANTES que cualquier otra cosa — así los
    // dos ven exactamente la misma secuencia, en todos los penaltis.
    if(hist.length>mpPenAnimatedCount){
      const entry=hist[mpPenAnimatedCount];
      mpPenAnimatedCount++;
      mpPenPendingFinish=winner?{winnerRole:winner, history:hist}:null;
      mpPenAnimating=true;
      mpPlayPenaltyAnimationForEntry(entry).then(()=>{
        // Actualizar el marcador ya con este lanzamiento incluido
        const shownHist=hist.slice(0,mpPenAnimatedCount);
        const myGoalsPen=shownHist.filter(h=>h.shooterRole===window._duelRole&&h.result==='gol').length;
        const rivalGoalsPen=shownHist.filter(h=>h.shooterRole!==window._duelRole&&h.result==='gol').length;
        const sl=document.getElementById('penScoreLine'); if(sl) sl.textContent=`${myGoalsPen} – ${rivalGoalsPen}`;
        const hrow=document.getElementById('penHistoryRow');
        if(hrow){
          hrow.innerHTML=shownHist.map(h=>{
            const mine=h.shooterRole===window._duelRole;
            const color=h.result==='gol'?'#4ade80':'#e05a4e';
            return `<span style="width:10px;height:10px;border-radius:50%;background:${color};border:1px solid ${mine?'#4a90d9':'#e74c3c'}"></span>`;
          }).join('');
        }
        // Pequeño respiro antes de pasar al siguiente lanzamiento — se
        // mantiene "animando" activo durante la pausa para que ningún
        // aviso del listener se cuele a mitad y solape fotogramas.
        setTimeout(()=>{
          mpPenAnimating=false;
          if(mpPenPendingFinish){
            mpPenaltyDetachListener();
            mpFinishPenaltiesUI(mpPenPendingFinish.winnerRole, mpPenPendingFinish.history);
          }else if(cur){
            mpRenderPenaltyKick(cur, shownHist);
            if(cur.shooterRole===window._duelRole) mpMaybeResolveAsShooter(cur, shownHist);
          }
        }, 450);
      });
      return; // no procesar nada más hasta que esta animación termine
    }

    if(winner){
      if(mpPenAnimating){ mpPenPendingFinish={winnerRole:winner, history:hist}; return; }
      mpPenaltyDetachListener();
      mpFinishPenaltiesUI(winner, hist);
      return;
    }
    if(!cur || mpPenAnimating) return;
    mpRenderPenaltyKick(cur, hist);
    // El tirador de este lanzamiento es quien resuelve, en cuanto tenga
    // los dos datos (o se agote el tiempo) — nunca el portero.
    if(cur.shooterRole===window._duelRole){
      mpMaybeResolveAsShooter(cur, hist);
    }
  }, e=>console.error('[Penaltis] listener falló:', e));
}
function mpPenaltyDetachListener(){
  if(mpPenListenerUnsub){ mpPenListenerUnsub(); mpPenListenerUnsub=null; }
  if(mpPenTimerHandle){ clearInterval(mpPenTimerHandle); mpPenTimerHandle=null; }
}

function mpRenderPenaltyKick(cur, hist){
  if(mpPenRenderedKick===cur.kickNum && !cur._forceRerender) return;
  mpPenRenderedKick=cur.kickNum;
  mpPenMyChoice=null;
  mpPenCurState=cur;
  mpPenCurHist=hist;
  const iAmShooter=cur.shooterRole===window._duelRole;
  const myName=mpEsc(window.currentUsername||(window._duelRole==='challenger'?'TÚ':'TÚ'));
  const rivalName=mpEsc(window._duelOpponentUsername||'RIVAL');
  const shooterName=iAmShooter?(myName||'TÚ'):rivalName;
  const round=Math.floor(cur.kickNum/2)+1;
  const label=round<=5?`Ronda ${round} de 5`:`Muerte súbita ${round-5}`;
  const lbl=document.getElementById('penKickLabel'); if(lbl) lbl.textContent=label;
  const turnLbl=document.getElementById('penTurnLabel');
  if(turnLbl) turnLbl.innerHTML=`<span style="color:${iAmShooter?'#4a90d9':'#e74c3c'}">${shooterName.toUpperCase()}</span> ${iAmShooter?'TIRA':'PARA'} EL PENALTI`;
  const sub=document.getElementById('penSub');
  if(sub) sub.textContent=iAmShooter?'¡Te toca lanzar! Elige tu zona':'¡Te toca parar! Elige dónde te tiras';

  // Marcador de penaltis (aciertos hasta ahora)
  const myGoalsPen=hist.filter(h=>h.shooterRole===window._duelRole && h.result==='gol').length;
  const rivalGoalsPen=hist.filter(h=>h.shooterRole!==window._duelRole && h.result==='gol').length;
  const sl=document.getElementById('penScoreLine'); if(sl) sl.textContent=`${myGoalsPen} – ${rivalGoalsPen}`;

  mpRenderPenaltyHistory(hist);

  // Capas: si soy tirador -> jugador (yo) + portero_rival; si soy portero -> jugador_rival + portero (yo)
  const jugadorImg=document.getElementById('penJugador');
  const porteroImg=document.getElementById('penPortero');
  const balonImg=document.getElementById('penBalon');
  if(jugadorImg) jugadorImg.src=`assets/penaltis/${iAmShooter?'jugador_iddle':'jugador_rival_iddle'}.png`;
  if(porteroImg) porteroImg.src=`assets/penaltis/${iAmShooter?'portero_rival_iddle':'portero_iddle'}.png`;
  if(balonImg) balonImg.src='assets/penaltis/balon_iddle.png';

  mpRenderPenaltyZones(iAmShooter, cur);
  mpStartPenaltyTimer(cur);
}

/* Marcadores de aciertos/fallos — un balón (tuyo en azul, del rival en
   rojo) relleno si acertó, hueco con aspa si falló. Más claro que los
   puntos bicolor anteriores. */
function mpRenderPenaltyHistory(hist){
  const hrow=document.getElementById('penHistoryRow');
  if(!hrow) return;
  hrow.innerHTML=hist.map(h=>{
    const mine=h.shooterRole===window._duelRole;
    const color=mine?'#4a90d9':'#e74c3c';
    const scored=h.result==='gol';
    return `<div style="width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;
      background:${scored?color:'transparent'};border:2px solid ${color};flex-shrink:0">
      <i class="ph ph-bold ${scored?'ph-check':'ph-x'}" style="font-size:12px;color:${scored?'#fff':color}"></i>
    </div>`;
  }).join('');
}

function mpEnsurePenaltyZoneStyles(){
  if(document.getElementById('penZoneStylesTag')) return;
  const style=document.createElement('style');
  style.id='penZoneStylesTag';
  style.textContent=`
    @keyframes penZonePulse{
      0%{ transform:translate(-50%,-50%) scale(1); }
      40%{ transform:translate(-50%,-50%) scale(1.35); }
      100%{ transform:translate(-50%,-50%) scale(1.15); }
    }
    .pen-zone-dot.pressed{ animation:penZonePulse .35s ease forwards; border-color:var(--gold) !important; background:rgba(255,220,120,.35) !important; box-shadow:0 0 25px 8px rgba(255,215,80,.85),inset 0 0 15px rgba(255,255,255,.5) !important; }
  `;
  document.head.appendChild(style);
}
function mpRenderPenaltyZones(iAmShooter, cur){
  mpEnsurePenaltyZoneStyles();
  const wrap=document.getElementById('penZones');
  if(!wrap) return;
  wrap.innerHTML='';
  const myField=iAmShooter?'shooterZone':'keeperZone';
  if(cur[myField]){ wrap.style.display='none'; return; } // ya elegí, ocultar círculos
  wrap.style.display='block';
  PENALTY_ZONES.forEach(z=>{
    const dot=document.createElement('div');
    dot.className='pen-zone-dot';
    dot.style.cssText=`position:absolute;left:${z.x}%;top:${z.y}%;transform:translate(-50%,-50%);width:15%;height:15%;border-radius:50%;background:rgba(255,255,255,.12);border:4px solid #fff;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.5),inset 0 0 10px rgba(255,255,255,.15);transition:transform .15s ease;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;outline:none;touch-action:manipulation`;
    dot.addEventListener('click', ()=>{
      dot.classList.add('pressed');
      // Ocultar el resto de zonas al instante, dejando la pulsación visible
      Array.from(wrap.children).forEach(c=>{ if(c!==dot) c.style.visibility='hidden'; });
      setTimeout(()=>mpSubmitPenaltyChoice(z.id), 200);
    });
    wrap.appendChild(dot);
  });
}

let mpPenCurState=null, mpPenCurHist=[];
function mpStartPenaltyTimer(cur){
  if(mpPenTimerHandle) clearInterval(mpPenTimerHandle);
  const fill=document.getElementById('penTimerFill');
  let lastBeepSec=null;
  mpPenTimerHandle=setInterval(()=>{
    const remainMs=Math.max(0, cur.deadline-Date.now());
    const remainSec=Math.ceil(remainMs/1000);
    if(remainSec!==lastBeepSec){ lastBeepSec=remainSec; checkCountdownBeep(remainSec,'penalty'); }
    if(fill) fill.style.width=(remainMs/PENALTY_KICK_MS*100)+'%';
    if(remainMs<=0){
      clearInterval(mpPenTimerHandle); mpPenTimerHandle=null;
      // Al agotarse el tiempo hay que forzar la resolución — si no,
      // nadie vuelve a comprobar nada hasta que alguien escriba algo
      // en Firestore, y el juego se queda esperando indefinidamente.
      if(cur.shooterRole===window._duelRole) mpMaybeResolveAsShooter(cur, mpPenCurHist);
    }
  }, 100);
}

async function mpSubmitPenaltyChoice(zoneId){
  if(mpPenMyChoice) return; // ya elegí esta ronda
  mpPenMyChoice=zoneId;
  playSound('select');
  const wrap=document.getElementById('penZones');
  if(wrap) wrap.style.display='none';
  const sub=document.getElementById('penSub'); if(sub) sub.textContent='Esperando al rival...';
  const db=window._fbDb;
  if(!db||!window._duelId) return;
  const idx=window._duelMatchIndex;
  try{
    const snap=await db.collection('duels').doc(window._duelId).get();
    const d=snap.exists?snap.data():{};
    const cur=d[`m${idx}_penCurrent`];
    if(!cur) return;
    const iAmShooter=cur.shooterRole===window._duelRole;
    const field=iAmShooter?'shooterZone':'keeperZone';
    await db.collection('duels').doc(window._duelId).update({[`m${idx}_penCurrent.${field}`]: zoneId});
  }catch(e){ console.error('[Penaltis] envío de elección falló:', e); }
}

async function mpMaybeResolveAsShooter(cur, hist){
  if(mpPenResolvingKick===cur.kickNum) return; // ya en proceso
  const timeUp=Date.now()>=cur.deadline;
  const bothPicked=cur.shooterZone && cur.keeperZone;
  if(!bothPicked && !timeUp) return;
  mpPenResolvingKick=cur.kickNum;

  let result, shooterZone=cur.shooterZone, keeperZone=cur.keeperZone;
  if(!cur.shooterZone){
    result='fuera'; // el tirador no eligió a tiempo: disparo fuera
  }else{
    // El portero que no elige a tiempo se queda quieto en el centro,
    // como si esa fuera su elección — no es gol automático.
    if(!keeperZone) keeperZone='centro';
    result=(cur.shooterZone===keeperZone)?'para':'gol';
  }

  // No se anima aquí — la animación la dispara el listener a partir del
  // historial, igual en los dos dispositivos, para que se vea idéntica.
  const newHist=[...hist, {kickNum:cur.kickNum, shooterRole:cur.shooterRole, result, shooterZone, keeperZone}];
  const db=window._fbDb;
  const idx=window._duelMatchIndex;

  // Comprobar si la tanda ya está decidida (regla de parada anticipada,
  // igual que en un jugador)
  const chalGoals=newHist.filter(h=>h.shooterRole==='challenger'&&h.result==='gol').length;
  const oppGoals=newHist.filter(h=>h.shooterRole==='opponent'&&h.result==='gol').length;
  const chalKicksLeftBase=Math.max(0,5-newHist.filter(h=>h.shooterRole==='challenger'&&h.kickNum<10).length);
  const oppKicksLeftBase=Math.max(0,5-newHist.filter(h=>h.shooterRole==='opponent'&&h.kickNum<10).length);
  const nextKickNum=cur.kickNum+1;
  const inSuddenDeath=nextKickNum>=10;
  let decided=false, winner=null;
  if(!inSuddenDeath){
    const diff=chalGoals-oppGoals;
    if(diff>oppKicksLeftBase){ decided=true; winner='challenger'; }
    else if(-diff>chalKicksLeftBase){ decided=true; winner='opponent'; }
  }else{
    // Muerte súbita: se decide en cuanto se completa un par de tiros con marcador distinto
    if(nextKickNum%2===0 && chalGoals!==oppGoals){ decided=true; winner=chalGoals>oppGoals?'challenger':'opponent'; }
  }

  try{
    if(decided){
      await db.collection('duels').doc(window._duelId).update({
        [`m${idx}_penHistory`]: newHist,
        [`m${idx}_penWinner`]: winner,
        [`m${idx}_penCurrent`]: null
      });
    }else{
      await db.collection('duels').doc(window._duelId).update({
        [`m${idx}_penHistory`]: newHist,
        [`m${idx}_penCurrent`]: {kickNum:nextKickNum, shooterRole:mpPenaltyShooterRoleForKick(nextKickNum), deadline:Date.now()+PENALTY_ANIM_DELAY_MS+PENALTY_KICK_MS, shooterZone:null, keeperZone:null}
      });
    }
  }catch(e){ console.error('[Penaltis] avance de ronda falló:', e); }
}

/* Prepara la escena para el lanzamiento indicado (idle correcto para mi
   perspectiva) y reproduce su animación ya resuelta — se llama igual en
   los dos dispositivos, a partir del historial compartido. */
function mpPlayPenaltyAnimationForEntry(entry){
  const iShoot=entry.shooterRole===window._duelRole;
  const jugadorImg=document.getElementById('penJugador');
  const porteroImg=document.getElementById('penPortero');
  const balonImg=document.getElementById('penBalon');
  const wrap=document.getElementById('penZones'); if(wrap) wrap.style.display='none';
  if(jugadorImg) jugadorImg.src=`assets/penaltis/${iShoot?'jugador_iddle':'jugador_rival_iddle'}.png`;
  if(porteroImg) porteroImg.src=`assets/penaltis/${iShoot?'portero_rival_iddle':'portero_iddle'}.png`;
  if(balonImg){ balonImg.style.display=''; balonImg.src='assets/penaltis/balon_iddle.png'; }
  const round=Math.floor(entry.kickNum/2)+1;
  const label=round<=5?`Ronda ${round} de 5`:`Muerte súbita ${round-5}`;
  const lbl=document.getElementById('penKickLabel'); if(lbl) lbl.textContent=label;
  const myName=window.currentUsername||'TÚ';
  const rivalName=window._duelOpponentUsername||'RIVAL';
  const shooterName=mpEsc(iShoot?myName:rivalName);
  const turnLbl=document.getElementById('penTurnLabel');
  if(turnLbl) turnLbl.innerHTML=`<span style="color:${iShoot?'#4a90d9':'#e74c3c'}">${shooterName.toUpperCase()}</span> ${iShoot?'TIRA':'PARA'} EL PENALTI`;
  return mpPlayPenaltyAnimation(entry.result, entry.shooterZone, entry.keeperZone, iShoot);
}

function mpPlayPenaltyAnimation(result, shooterZone, keeperZone, iShoot){
  return new Promise(resolve=>{
    const jugadorImg=document.getElementById('penJugador');
    const porteroImg=document.getElementById('penPortero');
    const balonImg=document.getElementById('penBalon');
    const sub=document.getElementById('penSub');
    const jPrefix=iShoot?'jugador':'jugador_rival';
    const pPrefix=iShoot?'portero_rival':'portero';
    if(sub) sub.textContent='¡Chuta!';
    if(jugadorImg) jugadorImg.src=`assets/penaltis/${jPrefix}_chuta.png`;
    playSound('select');
    setTimeout(()=>{
      const zone=shooterZone||'centro';
      if(result==='fuera'){
        if(jugadorImg) jugadorImg.src=`assets/penaltis/${jPrefix}_falla.png`;
        if(balonImg) balonImg.style.display='none';
        if(sub) sub.textContent='¡FUERA!';
      }else if(result==='gol'){
        if(jugadorImg) jugadorImg.src=`assets/penaltis/${jPrefix}_gol.png`;
        if(porteroImg) porteroImg.src=keeperZone?`assets/penaltis/${pPrefix}_${keeperZone}_falla.png`:`assets/penaltis/${pPrefix}_iddle.png`;
        if(balonImg){ balonImg.style.display=''; balonImg.src=`assets/penaltis/balon_gol_${zone}.png`; }
        if(sub) sub.textContent='¡GOL!';
        playSound('goal');
      }else{ // para
        if(jugadorImg) jugadorImg.src=`assets/penaltis/${jPrefix}_falla.png`;
        if(porteroImg) porteroImg.src=`assets/penaltis/${pPrefix}_${keeperZone}_para.png`;
        if(balonImg) balonImg.style.display='none';
        if(sub) sub.textContent='¡PARADA!';
      }
      setTimeout(resolve, 1400);
    }, 2000);
  });
}

function mpFinishPenaltiesUI(winnerRole, history){
  const sub=document.getElementById('penSub');
  const iWon=winnerRole===window._duelRole;
  if(sub) sub.textContent=iWon?'¡GANAS LA TANDA DE PENALTIS!':'Pierdes la tanda de penaltis';
  playSound(iWon?'victory':'defeat');
  if(window._duelLastMatchStats) Object.assign(window._duelLastMatchStats, {won:iWon, draw:false, decidedByPenalties:true});
  const myPenGoals=history.filter(h=>h.shooterRole===window._duelRole&&h.result==='gol').length;
  const rivalPenGoals=history.filter(h=>h.shooterRole!==window._duelRole&&h.result==='gol').length;
  const st=window._duelLastMatchStats||{};
  setTimeout(()=>{
    const overlay=document.getElementById('matchOverlay');
    if(overlay){
      overlay.innerHTML=`
      <div class="match-modal" style="overflow:hidden;display:flex;flex-direction:column">
        <div class="match-header">
          <div class="match-side">
            <i class="ph ph-bold ph-user" style="font-size:22px;color:#4a90d9"></i>
            <span class="match-team-name">${mpEsc(window.myTeamName||myTeamName||'TU EQUIPO')}</span>
          </div>
          <div style="text-align:center;flex:0 0 auto">
            <div class="match-scoreline" style="font-size:42px;letter-spacing:4px">${st.myGoals||0} – ${st.rivalGoals||0}</div>
            <div style="font-size:11px;color:var(--gold);margin-top:2px">${(tk('match.penalties')||'PENALTIS')} ${myPenGoals}-${rivalPenGoals}</div>
            <div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-top:4px">
              <div style="font-size:9px;font-weight:700;background:#555;color:#fff;padding:2px 7px;letter-spacing:1px;text-transform:uppercase">${tk('match.end')||'FIN'}</div>
            </div>
          </div>
          <div class="match-side">
            <i class="ph ph-bold ph-user" style="font-size:22px;color:#e74c3c"></i>
            <span class="match-team-name">${mpEsc(window._duelOpponentUsername||'RIVAL')}</span>
          </div>
        </div>
      </div>`;
    }
    mpAdvanceAfterMatch();
  }, 1600);
}

function mpAdvanceAfterMatch(){
  mpShowDuelPostMatchStats();
}

/* Estadísticas del partido recién jugado — se insertan en la MISMA
   ventana de partido (igual que showPostMatch() en solitario), no en
   un popup aparte. Ambos deben confirmar para pasar a la gestión
   previa al siguiente partido (o al resumen final). */
async function mpShowDuelPostMatchStats(){
  const db=window._fbDb;
  const idx=window._duelMatchIndex;
  const st=window._duelLastMatchStats||{};
  const s=generateDuelMatchSummary._lastStats||{possession:50,oppPoss:50,shots:0,oppShots:0};
  const overlay=document.getElementById('matchOverlay');
  const modal=overlay?overlay.querySelector('.match-modal'):null;
  if(!modal){
    // Red de seguridad si por lo que sea la ventana de partido ya no está
    if(idx>=4){ mpShowDuelFinalSummary(); }else{ window._duelMatchIndex=idx+1; mpShowStrategyAndBenchPhase(); }
    return;
  }
  modal.style.overflowY='auto';

  const resultClass=st.won?'res-win-tag':st.draw?'res-draw-tag':'res-lose-tag';
  const resultText=(st.won?(tk('mp.duel_you_won')||'¡GANASTE ESTE PARTIDO!')
    :st.draw?(tk('mp.duel_draw')||'Empate')
    :(tk('mp.duel_you_lost')||'Has perdido este partido')) + (st.decidedByPenalties?' ('+(tk('match.penalties')||'PENALTIS')+')':'');
  const banner=document.createElement('div');
  banner.className=`match-result-tag ${resultClass}`;
  banner.textContent=resultText;
  banner.style.animation='slideInEvent .4s ease forwards';
  modal.appendChild(banner);

  const infoWrap=document.createElement('div');
  infoWrap.style.cssText='display:flex;flex-direction:column;gap:6px;margin-top:8px';

  const summaryDiv=document.createElement('div');
  summaryDiv.className='match-summary';
  const myLabel=(window.myTeamName||myTeamName||'TU EQUIPO');
  summaryDiv.innerHTML=`<strong>${tk('mp.duel_possession')||'Posesión'}:</strong> ${myLabel} ${s.possession}% · ${mpEsc(window._duelOpponentUsername||'')} ${s.oppPoss}%<br><strong>${tk('mp.duel_shots')||'Tiros'}:</strong> ${s.shots} – ${s.oppShots}`;
  infoWrap.appendChild(summaryDiv);

  const ILABELS={leve:'leve (1 partido)', básica:'básica (2 partidos)', grave:'grave (3 partidos)'};
  if(st.myInjuries&&st.myInjuries.length){
    const inj=document.createElement('div');
    inj.className='injury-section';
    inj.innerHTML=`<p>${(tk('match.injuries_short')||'⚠ Lesiones en {0}:').replace('{0}',myLabel)}</p><ul>${st.myInjuries.map(p=>`<li><span style="color:#e74c3c">✚</span> ${mpEsc(p.name)}: lesión ${ILABELS[p.type]||''}</li>`).join('')}</ul>`;
    infoWrap.appendChild(inj);
  }
  if(st.rivalInjuries&&st.rivalInjuries.length){
    const inj=document.createElement('div');
    inj.className='injury-section';
    inj.innerHTML=`<p>${(tk('match.injuries_short')||'⚠ Lesiones en {0}:').replace('{0}',mpEsc(window._duelOpponentUsername||''))}</p><ul>${st.rivalInjuries.map(p=>`<li><span style="color:#e74c3c">✚</span> ${mpEsc(p.name)}: lesión ${ILABELS[p.type]||''}</li>`).join('')}</ul>`;
    infoWrap.appendChild(inj);
  }
  const allCards=[...(st.myCards||[]), ...(st.rivalCards||[])];
  if(allCards.length){
    const CARD_LABELS={yellow:{icon:'🟨',text:'amarilla'}, red:{icon:'🟥',text:'roja directa — sancionado'}};
    const cd=document.createElement('div');
    cd.className='card-section';
    cd.innerHTML=`<p>${tk('match.cards_short')||'📋 Tarjetas:'}</p><ul>${allCards.map(c=>{const l=CARD_LABELS[c.type]||CARD_LABELS.yellow; return `<li>${l.icon} ${mpEsc(c.player.name)}: ${l.text}</li>`;}).join('')}</ul>`;
    infoWrap.appendChild(cd);
  }

  // Evaluar si la estrategia elegida fue acertada
  try{
    if(db&&window._duelId){
      const snap=await db.collection('duels').doc(window._duelId).get();
      const d=snap.data()||{};
      const chalKey=d[`m${idx}_challengerStrategy`], oppKey=d[`m${idx}_opponentStrategy`];
      const myKey=window._duelRole==='challenger'?chalKey:oppKey;
      if(myKey && myKey!=='__none__' && modal.isConnected){
        const mod=window._duelRole==='challenger'
          ?duelCounterModifier(chalKey,oppKey).myScoreMod
          :duelCounterModifier(chalKey,oppKey).oppScoreMod;
        const myName=STRATEGIES[myKey]?STRATEGIES[myKey].name:myKey;
        const verdict=mod>0.1?(tk('mp.duel_strat_great')||'¡Gran elección! Superó la estrategia rival')
          :mod>0?(tk('mp.duel_strat_good')||'Buena lectura del rival')
          :mod<0?(tk('mp.duel_strat_bad')||'El rival te leyó mejor esta vez')
          :(tk('mp.duel_strat_neutral')||'Elección neutral, sin ventaja ni penalización');
        const stratClass=mod>0?'strategy-feedback-good':mod<0?'strategy-feedback-bad':'strategy-feedback-neutral';
        const sf=document.createElement('div');
        sf.className=`strategy-feedback ${stratClass}`;
        sf.textContent=`${(tk('mp.duel_your_strategy')||'Tu estrategia')} (${myName}): ${verdict}`;
        infoWrap.appendChild(sf);
      }
      // Giro Táctico — mostrar si alguno de los dos lo usó este partido
      // (reutiliza la misma lectura de arriba, sin gasto extra).
      const giroChal=d[`m${idx}_giroChallenger`], giroOpp=d[`m${idx}_giroOpponent`];
      const myGiro=window._duelRole==='challenger'?giroChal:giroOpp;
      const rivalGiro=window._duelRole==='challenger'?giroOpp:giroChal;
      if(myGiro){
        const gc=document.createElement('div');
        gc.className='match-summary';
        gc.style.cssText='border:1px solid var(--gold);border-radius:8px;padding:10px;display:flex;align-items:center;gap:10px';
        gc.innerHTML=myGiro.noPick
          ? `<i class="ph ph-bold ph-notebook" style="font-size:26px;color:#4a90d9;flex-shrink:0"></i><div><strong style="color:var(--gold)">${tk('giro.used_title')||'Giro Táctico usado'}</strong>: ${tk('giro.no_pick')||'no se eligió ninguna carta a tiempo'} (min ${myGiro.minute}')</div>`
          : `<i class="ph ph-bold ph-notebook" style="font-size:26px;color:#4a90d9;flex-shrink:0"></i><div><strong style="color:var(--gold)">${tk('giro.used_title')||'Giro Táctico usado'}: ${mpEsc(myGiro.cardName)}</strong><br><span style="color:#bfe8c9">${mpEsc(myGiro.pos)}</span> · <span style="color:#f3c6c1">${mpEsc(myGiro.neg)}</span></div>`;
        infoWrap.appendChild(gc);
      }
      if(rivalGiro){
        const gc=document.createElement('div');
        gc.className='match-summary';
        gc.style.cssText='border:1px solid #4a90d9;border-radius:8px;padding:10px;display:flex;align-items:center;gap:10px';
        const rivalName=mpEsc(window._duelOpponentUsername||'Rival');
        gc.innerHTML=rivalGiro.noPick
          ? `<i class="ph ph-bold ph-notebook" style="font-size:26px;color:#e74c3c;flex-shrink:0"></i><div><strong style="color:#7ec3ff">${rivalName} ${(tk('giro.rival_used')||'usó Giro Táctico')}</strong>: ${tk('giro.no_pick')||'no eligió ninguna carta a tiempo'} (min ${rivalGiro.minute}')</div>`
          : `<i class="ph ph-bold ph-notebook" style="font-size:26px;color:#e74c3c;flex-shrink:0"></i><div><strong style="color:#7ec3ff">${rivalName} ${(tk('giro.rival_used')||'usó Giro Táctico')}: ${mpEsc(rivalGiro.cardName)}</strong><br><span style="color:#bfe8c9">${mpEsc(rivalGiro.pos)}</span> · <span style="color:#f3c6c1">${mpEsc(rivalGiro.neg)}</span></div>`;
        infoWrap.appendChild(gc);
      }
    }
  }catch(e){ console.error('mpShowDuelPostMatchStats strategy error:',e); }

  const waitMsg=document.createElement('div');
  waitMsg.id='duelPostMatchWaitMsg';
  waitMsg.style.cssText='display:none;font-size:12px;color:var(--text-muted);margin-top:8px;text-align:center';
  waitMsg.textContent=tk('mp.duel_waiting_continue')||'Esperando a que el rival confirme...';
  infoWrap.appendChild(waitMsg);

  modal.appendChild(infoWrap);

  const btn=document.createElement('button');
  btn.className='modal-btn';
  btn.id='duelPostMatchContinueBtn';
  btn.textContent=tk('mp.duel_continue')||'CONTINUAR';
  btn.style.marginTop='10px';
  btn.addEventListener('click', mpConfirmPostMatchContinue);
  modal.appendChild(btn);
}

async function mpConfirmPostMatchContinue(){
  playSound('select');
  const db=window._fbDb;
  if(!db||!window._duelId) return;
  const btn=document.getElementById('duelPostMatchContinueBtn');
  if(btn) btn.disabled=true;
  const waitMsg=document.getElementById('duelPostMatchWaitMsg');
  if(waitMsg) waitMsg.style.display='block';
  const idx=window._duelMatchIndex;
  const field=window._duelRole==='challenger'?`m${idx}_challengerContinued`:`m${idx}_opponentContinued`;
  try{ await db.collection('duels').doc(window._duelId).update({[field]:true}); }
  catch(e){ console.error('mpConfirmPostMatchContinue error:',e); }
  mpWatchForBothContinued(idx);
}

/* Espera a que ambos hayan confirmado "continuar" tras ver las
   estadísticas del partido. Reutilizable también al retomar tras recargar. */
function mpWatchForBothContinued(idx){
  const db=window._fbDb;
  if(!db||!window._duelId) return;
  const chalField=`m${idx}_challengerContinued`, oppField=`m${idx}_opponentContinued`;
  const unsub=db.collection('duels').doc(window._duelId).onSnapshot(snap=>{
    const d=snap.data();
    if(!d) return;
    if(d.status==='cancelled'){ unsub(); mpExitDuelMode(); location.reload(); return; }
    if(d[chalField] && d[oppField]){
      unsub();
      if(idx>=4){ mpShowDuelFinalSummary(); }
      else{ window._duelMatchIndex=idx+1; mpShowStrategyAndBenchPhase(); }
    }
  }, e=>console.error('mpWatchForBothContinued error:',e));
}

/* Resumen final: solo vencedor + estadísticas globales de los 5 partidos. */
async function mpShowDuelFinalSummary(){
  const db=window._fbDb;
  if(!db||!window._duelId) return;
  let d={};
  try{
    const snap=await db.collection('duels').doc(window._duelId).get();
    d=snap.data()||{};
  }catch(e){ console.error('mpShowDuelFinalSummary error:',e); }
  let myWins=0, rivalWins=0, myGoalsTotal=0, rivalGoalsTotal=0, draws=0;
  let myCardsTotal=0, rivalCardsTotal=0, myInjuriesTotal=0, rivalInjuriesTotal=0;
  let myGiroUses=0, rivalGiroUses=0;
  let possessionSum=0, playedCount=0, biggestWinIdx=-1, biggestWinMargin=0, cleanSheets=0, rivalCleanSheets=0;
  const rows=[];
  for(let i=0;i<5;i++){
    const r=d[`m${i}_result`];
    if(!r) continue;
    playedCount++;
    const myG=window._duelRole==='challenger'?r.challengerGoals:r.opponentGoals;
    const rG=window._duelRole==='challenger'?r.opponentGoals:r.challengerGoals;
    const myC=(window._duelRole==='challenger'?r.challengerCards:r.opponentCards)||[];
    const rC=(window._duelRole==='challenger'?r.opponentCards:r.challengerCards)||[];
    const myI=(window._duelRole==='challenger'?r.challengerInjuries:r.opponentInjuries)||[];
    const rI=(window._duelRole==='challenger'?r.opponentInjuries:r.challengerInjuries)||[];
    const myPoss=window._duelRole==='challenger'?r.possession:(100-(r.possession||50));
    possessionSum+=(myPoss||50);
    myGoalsTotal+=myG; rivalGoalsTotal+=rG;
    myCardsTotal+=myC.length; rivalCardsTotal+=rC.length;
    myInjuriesTotal+=myI.length; rivalInjuriesTotal+=rI.length;
    if(d[`m${i}_${window._duelRole==='challenger'?'giroChallenger':'giroOpponent'}`]) myGiroUses++;
    if(d[`m${i}_${window._duelRole==='challenger'?'giroOpponent':'giroChallenger'}`]) rivalGiroUses++;
    if(rG===0) cleanSheets++;
    if(myG===0) rivalCleanSheets++;
    let res=myG>rG?'W':myG<rG?'L':'D';
    let penIndicator='';
    const penWinner=d[`m${i}_penWinner`];
    if(res==='D' && penWinner){
      res=penWinner===window._duelRole?'W':'L';
      penIndicator=' <span style="font-size:9px;opacity:.7">(pen.)</span>';
    }
    if(res==='W') myWins++; else if(res==='L') rivalWins++; else draws++;
    if(res==='W' && (myG-rG)>biggestWinMargin){ biggestWinMargin=myG-rG; biggestWinIdx=i; }
    const resColor=res==='W'?'#4ade80':res==='L'?'#ff7e7e':'var(--text-muted)';
    rows.push(`<div class="mp-stat-row"><span>${tk('mp.duel_match_short')||'Partido'} ${i+1}</span><span style="color:${resColor}">${myG} - ${rG}${penIndicator}</span></div>`);
  }
  const avgPoss=playedCount?Math.round(possessionSum/playedCount):50;
  let iWin=myWins>rivalWins, iLose=myWins<rivalWins;
  let tiebreakNote='';
  if(myWins===rivalWins){
    const myDiff=myGoalsTotal-rivalGoalsTotal, rivalDiff=rivalGoalsTotal-myGoalsTotal;
    if(myDiff!==rivalDiff){
      iWin=myDiff>rivalDiff; iLose=!iWin;
      tiebreakNote=tk('mp.duel_tiebreak_goals')||'(empate en partidos ganados, decidido por diferencia de goles)';
    }else if(avgPoss!==(100-avgPoss)){
      iWin=avgPoss>(100-avgPoss); iLose=!iWin;
      tiebreakNote=tk('mp.duel_tiebreak_possession')||'(empate en partidos y goles, decidido por posesión media)';
    }
  }
  const outcome = iWin
    ? (tk('mp.duel_final_won')||'¡HAS GANADO EL DUELO!')
    : iLose
      ? (tk('mp.duel_final_lost')||'Has perdido el duelo')
      : (tk('mp.duel_final_tie')||'Duelo empatado');
  playSound(iWin?'victory':iLose?'defeat':'whistle');

  // Frase narrativa con algún dato destacado
  let narrative='';
  if(biggestWinIdx>=0){
    narrative=(tk('mp.duel_final_narrative_win')||'Tu mejor actuación fue en el partido {0}, ganando por {1} goles de diferencia.')
      .replace('{0}', String(biggestWinIdx+1)).replace('{1}', String(biggestWinMargin));
  }else if(myGoalsTotal>rivalGoalsTotal){
    narrative=(tk('mp.duel_final_narrative_goals')||'Marcaste {0} goles en total, {1} más que tu rival.')
      .replace('{0}', String(myGoalsTotal)).replace('{1}', String(myGoalsTotal-rivalGoalsTotal));
  }else if(cleanSheets>0){
    narrative=(tk('mp.duel_final_narrative_clean')||'Mantuviste la portería a cero en {0} de {1} partidos.')
      .replace('{0}', String(cleanSheets)).replace('{1}', String(playedCount));
  }

  const myLabel=(window.myTeamName||myTeamName||'TU EQUIPO');

  mpShowDuelOverlay(`
    <i class="ph ph-bold ph-trophy" style="font-size:34px;color:var(--gold);display:block;margin-bottom:6px"></i>
    <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:22px;color:var(--gold)">${outcome}</div>
    ${tiebreakNote?`<div style="font-size:11px;color:var(--text-muted);margin-top:2px">${tiebreakNote}</div>`:''}
    <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:26px;margin:6px 0">${myWins} - ${rivalWins}</div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0;border-top:1px solid var(--line);margin-top:8px">
      <div style="text-align:center;padding:8px 6px;border-right:1px solid var(--line)">
        <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:13px;color:var(--gold)">${mpEsc(myLabel)}</div>
      </div>
      <div style="text-align:center;padding:8px 6px">
        <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:13px">${mpEsc(window._duelOpponentUsername||'')}</div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr auto 1fr;align-items:center;font-size:12px">
      <div style="text-align:center;padding:3px 0">${myWins}</div><div style="text-align:center;color:var(--text-muted);font-size:10px;padding:0 8px">${tk('mp.duel_final_matches')||'Partidos ganados'}</div><div style="text-align:center;padding:3px 0">${rivalWins}</div>
      <div style="text-align:center;padding:3px 0">${myGoalsTotal}</div><div style="text-align:center;color:var(--text-muted);font-size:10px;padding:0 8px">${tk('mp.duel_final_goals')||'Goles'}</div><div style="text-align:center;padding:3px 0">${rivalGoalsTotal}</div>
      <div style="text-align:center;padding:3px 0">${avgPoss}%</div><div style="text-align:center;color:var(--text-muted);font-size:10px;padding:0 8px">${tk('mp.duel_possession')||'Posesión media'}</div><div style="text-align:center;padding:3px 0">${100-avgPoss}%</div>
      <div style="text-align:center;padding:3px 0">${myCardsTotal}</div><div style="text-align:center;color:var(--text-muted);font-size:10px;padding:0 8px">${tk('mp.duel_final_cards_short')||'Tarjetas'}</div><div style="text-align:center;padding:3px 0">${rivalCardsTotal}</div>
      <div style="text-align:center;padding:3px 0">${myInjuriesTotal}</div><div style="text-align:center;color:var(--text-muted);font-size:10px;padding:0 8px">${tk('mp.duel_final_injuries_short')||'Lesionados'}</div><div style="text-align:center;padding:3px 0">${rivalInjuriesTotal}</div>
      <div style="text-align:center;padding:3px 0">${cleanSheets}</div><div style="text-align:center;color:var(--text-muted);font-size:10px;padding:0 8px">${tk('mp.duel_final_clean_sheets')||'Porterías a cero'}</div><div style="text-align:center;padding:3px 0">${rivalCleanSheets}</div>
      <div style="text-align:center;padding:3px 0">${myGiroUses}</div><div style="text-align:center;color:var(--text-muted);font-size:10px;padding:0 8px">${tk('giro.final_uses')||'Giros Tácticos usados'}</div><div style="text-align:center;padding:3px 0">${rivalGiroUses}</div>
    </div>

    ${narrative?`<div style="font-size:12px;color:var(--gold);font-style:italic;border-top:1px solid var(--line);margin-top:10px;padding-top:8px">${narrative}</div>`:''}

    <div style="text-align:left;border-top:1px solid var(--line);margin-top:10px;padding-top:8px">
      <div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">${tk('mp.duel_final_breakdown')||'Partido a partido'}</div>
      ${rows.join('')}
    </div>

    <button id="duelExitBtn" class="modal-btn" style="width:100%;margin-top:14px">${tk('mp.duel_finish')||'FINALIZAR'}</button>
  `, true);
  const exitBtn=document.getElementById('duelExitBtn');
  if(exitBtn) exitBtn.addEventListener('click', async()=>{
    try{ await db.collection('duels').doc(window._duelId).update({status:'finished'}); }catch(e){}
    mpExitDuelMode();
    location.reload();
  });
}

/* ════════════════════════════════════════════════════════════
   SISTEMA DE DUELOS (Fase 1: invitación y aceptación)
   Colección Firestore: 'duels' — documento por desafío:
   { challengerId, challengerUsername, opponentId, opponentUsername,
     status: 'pending'|'accepted'|'rejected'|'cancelled', createdAt }
   La fase de draft sincronizado y la simulación de partidos se
   implementan en fases posteriores sobre esta base.
   ════════════════════════════════════════════════════════════ */

/* Enviar desafío a un amigo */
async function mpChallengeFriend(targetUid, targetUsername, btnEl){
  playSound('select');
  const auth=window._fbAuth, db=window._fbDb;
  const user=auth&&auth.currentUser;
  if(!user||!db) return;
  if(btnEl) btnEl.disabled=true;
  try{
    // Evitar duplicar un desafío ya pendiente con el mismo rival (un solo where, filtro en JS)
    const mine=await db.collection('duels').where('challengerId','==',user.uid).get();
    const already=mine.docs.some(d=>{const x=d.data();return x.opponentId===targetUid && x.status==='pending';});
    if(already){
      showToast((tk('mp.duel_pending_own')||'Ya tienes un desafío pendiente con {0}').replace('{0}',targetUsername||''), 'toast-neg');
      return;
    }
    const mySnap=await db.collection('users').doc(user.uid).get();
    const myUsername=(mySnap.exists&&(mySnap.data().username||mySnap.data().email))||user.email||'???';
    await db.collection('duels').add({
      challengerId:user.uid, challengerUsername:myUsername,
      opponentId:targetUid, opponentUsername:targetUsername,
      status:'pending', createdAt:Date.now()
    }).then(ref=>{
      try{ sessionStorage.setItem('g2g_pending_challenge_id', ref.id); }catch(e){}
    });
    showToast((tk('mp.duel_sent')||'Desafío enviado a {0}').replace('{0}',targetUsername||''), 'toast-pos');
  }catch(e){
    console.error('mpChallengeFriend error:',e);
    showToast(tk('mp.err_generic'), 'toast-neg');
  }finally{
    if(btnEl) btnEl.disabled=false;
  }
}

/* Cargar desafíos de duelo pendientes recibidos */
async function renderPendingDuels(){
  const auth=window._fbAuth, db=window._fbDb;
  const user=auth&&auth.currentUser;
  const section=$id('mpDuelsSection');
  const list=$id('mpDuelsList');
  if(!user||!db||!section||!list) return;
  try{
    const snap=await db.collection('duels')
      .where('opponentId','==',user.uid).get();
    const pendingDocs=snap.docs.filter(d=>d.data().status==='pending');
    if(!pendingDocs.length){ section.style.display='none'; return; }
    section.style.display='block';
    list.innerHTML='';
    pendingDocs.forEach(doc=>{
      const d=doc.data();
      const row=document.createElement('div');
      row.className='mp-row';
      row.innerHTML=`
        <span class="mp-row-name">${mpEsc(d.challengerUsername||'???')}</span>
        <button class="mp-btn-accept" data-id="${doc.id}">${tk('mp.accept')}</button>
        <button class="mp-btn-reject" data-id="${doc.id}">${tk('mp.reject')}</button>`;
      list.appendChild(row);
    });
    list.querySelectorAll('.mp-btn-accept').forEach(b=>b.addEventListener('click',()=>mpRespondDuel(b.dataset.id,true)));
    list.querySelectorAll('.mp-btn-reject').forEach(b=>b.addEventListener('click',()=>mpRespondDuel(b.dataset.id,false)));
  }catch(e){
    console.error('renderPendingDuels error:',e);
  }
}

/* Aceptar o rechazar un desafío de duelo recibido */
async function mpRespondDuel(docId, accept){
  playSound('select');
  const db=window._fbDb;
  const auth=window._fbAuth;
  const user=auth&&auth.currentUser;
  if(!db||!user) return;
  try{
    if(accept){
      const draftStartAt=Date.now();
      await db.collection('duels').doc(docId).update({status:'accepted', acceptedAt:draftStartAt, draftStartAt});
      const snap=await db.collection('duels').doc(docId).get();
      const d=snap.data();
      mpEnterDuelMode(docId, d, user.uid);
    }else{
      await db.collection('duels').doc(docId).update({status:'rejected'});
    }
  }catch(e){
    console.error('mpRespondDuel error:',e);
    alert(tk('mp.err_generic'));
  }
}

/* ════════════════════════════════════════════════════════════
   DUELO — DRAFT SINCRONIZADO (Fase 2)
   Guarda el duelo activo en sessionStorage y recarga, igual que ya
   hace la Run Encadenada con 'g2g_inherited'. Así el draft arranca
   siempre limpio, sin arrastrar estado de una partida anterior.
   ════════════════════════════════════════════════════════════ */
let _duelTimerInterval=null;
let _duelWatcherUnsub=null;

/* Guarda el duelo en sessionStorage y recarga la página para entrar limpio */
/* Overlay reutilizable para las pantallas del duelo — ahora como un
   popup centrado (mismo estilo que el resto de modales del juego),
   sobre un fondo semitransparente, no una pantalla negra completa. */
function mpShowDuelOverlay(innerHtml, wide){
  let ov=document.getElementById('duelOverlay');
  if(!ov){
    ov=document.createElement('div');
    ov.id='duelOverlay';
    ov.style.cssText='position:fixed;inset:0;z-index:80000;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;padding:16px;overflow-y:auto';
    document.body.appendChild(ov);
  }
  ov.innerHTML=`<div class="auth-modal" style="${wide?'max-width:560px;':''}text-align:center;overflow-y:auto">${innerHtml}</div>`;
  ov.style.display='flex';
  return ov;
}
function mpHideDuelOverlay(){
  const ov=document.getElementById('duelOverlay');
  if(ov) ov.style.display='none';
}
/* Popup simple de "esperando..." reutilizado en varios puntos del flujo */
function mpShowWaitingPopup(text){
  mpShowDuelOverlay(`
    <i class="ph ph-bold ph-hourglass-medium" style="font-size:28px;color:#7b9cff;display:block;margin-bottom:10px"></i>
    <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:16px;color:var(--gold);letter-spacing:.5px">${text}</div>`);
}

function mpEnterDuelMode(duelId, duelData, myUid){
  const isChallenger=duelData.challengerId===myUid;
  const info={
    duelId,
    role: isChallenger?'challenger':'opponent',
    opponentUsername: isChallenger?duelData.opponentUsername:duelData.challengerUsername,
    draftStartAt: duelData.draftStartAt||Date.now()
  };
  try{ sessionStorage.setItem('g2g_duel_active', JSON.stringify(info)); }catch(e){}
  location.reload();
}

/* Vigila (para el retador) si el rival ha aceptado su desafío saliente,
   incluso con el modal de multijugador cerrado. */
function startDuelWatcher(uid){
  stopDuelWatcher();
  const db=window._fbDb;
  if(!db) return;
  _duelWatcherUnsub=db.collection('duels')
    .where('challengerId','==',uid)
    .onSnapshot(snap=>{
      // Si ya estoy en un duelo activo, no reaccionar (evita bucles de recarga)
      let active=null;
      try{ active=JSON.parse(sessionStorage.getItem('g2g_duel_active')||'null'); }catch(e){}
      if(active) return;
      // Solo reaccionar al desafío que YO envié en esta sesión — evita que duelos
      // antiguos ya aceptados (de pruebas previas) vuelvan a arrastrar al jugador.
      let pendingId=null;
      try{ pendingId=sessionStorage.getItem('g2g_pending_challenge_id'); }catch(e){}
      if(!pendingId) return;
      snap.docChanges().forEach(ch=>{
        if(ch.doc.id!==pendingId) return;
        const d=ch.doc.data();
        if(d.status==='accepted'){
          try{ sessionStorage.removeItem('g2g_pending_challenge_id'); }catch(e){}
          mpEnterDuelMode(ch.doc.id, d, uid);
        }
      });
    }, e=>console.error('startDuelWatcher error:',e));
}
function stopDuelWatcher(){
  if(_duelWatcherUnsub){ _duelWatcherUnsub(); _duelWatcherUnsub=null; }
}

/* Aviso (circulito rojo) en el botón MULTIJUGADOR cuando hay una
   solicitud de amistad o un desafío de duelo pendientes, sin necesidad
   de abrir el modal. Un solo where por consulta, filtro en JS. */
let _mpNotifFriendsUnsub=null, _mpNotifDuelsUnsub=null;
let _mpNotifState={friends:false, duels:false};
function mpUpdateNotifBadge(){
  const badge=document.getElementById('mpNotifBadge');
  if(!badge) return;
  badge.style.display=(_mpNotifState.friends||_mpNotifState.duels)?'block':'none';
}
function startMpNotificationListener(uid){
  stopMpNotificationListener();
  const db=window._fbDb;
  if(!db) return;
  _mpNotifFriendsUnsub=db.collection('friends')
    .where('friendId','==',uid)
    .onSnapshot(snap=>{
      _mpNotifState.friends=snap.docs.some(d=>d.data().status==='pending');
      mpUpdateNotifBadge();
    }, e=>console.error('mpNotif friends error:',e));
  _mpNotifDuelsUnsub=db.collection('duels')
    .where('opponentId','==',uid)
    .onSnapshot(snap=>{
      _mpNotifState.duels=snap.docs.some(d=>d.data().status==='pending');
      mpUpdateNotifBadge();
    }, e=>console.error('mpNotif duels error:',e));
}
function stopMpNotificationListener(){
  if(_mpNotifFriendsUnsub){ _mpNotifFriendsUnsub(); _mpNotifFriendsUnsub=null; }
  if(_mpNotifDuelsUnsub){ _mpNotifDuelsUnsub(); _mpNotifDuelsUnsub=null; }
  _mpNotifState={friends:false, duels:false};
  const badge=document.getElementById('mpNotifBadge');
  if(badge) badge.style.display='none';
}

/* Al cargar la página: si hay un duelo activo en sessionStorage, retomarlo
   consultando su estado real en Firestore (no confiar solo en lo local). */
/* Inactividad en duelo: si un jugador no interactúa con nada durante
   más de 1 minuto mientras el duelo está activo, la partida finaliza
   automáticamente — reutiliza el mismo mecanismo que "abandonar duelo",
   así se integra con cualquier pantalla en la que esté el jugador. */
function startDuelInactivityMonitor(){
  stopDuelInactivityMonitor();
  _duelLastInteraction=Date.now();
  if(!_duelInteractionListenersAttached){
    _duelInteractionListenersAttached=true;
    ['click','touchstart','keydown'].forEach(evt=>{
      document.addEventListener(evt, ()=>{ _duelLastInteraction=Date.now(); }, {passive:true});
    });
  }
  _duelInactivityInterval=setInterval(()=>{
    if(!window._duelId){ stopDuelInactivityMonitor(); return; }
    if(Date.now()-_duelLastInteraction>60000){
      stopDuelInactivityMonitor();
      console.log('[Duelo] finalizado automáticamente por inactividad (más de 1 minuto sin interacción)');
      mpAbandonDuel();
    }
  }, 10000);
}
function stopDuelInactivityMonitor(){
  if(_duelInactivityInterval){ clearInterval(_duelInactivityInterval); _duelInactivityInterval=null; }
}

async function initDuelModeFromSession(){
  let info=null;
  try{ info=JSON.parse(sessionStorage.getItem('g2g_duel_active')||'null'); }catch(e){}
  if(!info) return;
  window._duelId=info.duelId;
  window._duelRole=info.role;
  window._duelOpponentUsername=info.opponentUsername;
  window._duelDraftDeadline=info.draftStartAt+DUEL_DRAFT_SECONDS*1000;
  startDuelInactivityMonitor();
  // La pantalla de bienvenida ("EMPEZAR A JUGAR") es obligatoria en cada carga;
  // en modo duelo la saltamos, ya que el jugador ya confirmó explícitamente al
  // aceptar/lanzar el desafío.
  const wo=document.getElementById("welcomeOverlay");
  if(wo) wo.style.display="none";
  // Ocultar elementos de menú irrelevantes en modo duelo
  const mpwQ=document.getElementById("multiplayerWrap");
  if(mpwQ) mpwQ.style.display="none";
  const qb=document.getElementById("quickBuildWrap"); // se sigue usando internamente al agotar el tiempo
  // Comprobar el estado real del duelo para decidir si mostrar el draft o la espera
  try{
    const db=window._fbDb;
    // La sesión de auth puede tardar un instante en estar lista tras el reload
    let tries=0;
    while(!window._fbDb && tries<20){ await new Promise(r=>setTimeout(r,150)); tries++; }
    const snap=await window._fbDb.collection('duels').doc(window._duelId).get();
    if(!snap.exists){ mpExitDuelMode(); return; }
    const d=snap.data();
    const myReadyField=window._duelRole==='challenger'?'challengerReady':'opponentReady';
    if(!d[myReadyField]){
      startDuelDraftTimer();
      return;
    }
    if(!d.challengerReady || !d.opponentReady){
      mpShowDuelWaitingScreen();
      return;
    }
    // Ambos equipos ya listos: retomar exactamente en el partido/sub-fase
    // correctos, en vez de reiniciar siempre desde el partido 1.
    const idx=d.currentMatchIndex||0;
    window._duelMatchIndex=idx;
    const myStratField=window._duelRole==='challenger'?`m${idx}_challengerStrategy`:`m${idx}_opponentStrategy`;
    if(d[`m${idx}_result`]!==undefined){
      // El resultado de este partido ya se calculó (aplicar la fatiga
      // guardada es seguro repetirlo, no se duplica).
      mpPlayDuelMatchAnimation(d[`m${idx}_result`], d.challengerSquad, d.opponentSquad);
    }else if(d[myStratField]!==undefined){
      // Ya envié mi estrategia para este partido — esperar/calcular el resultado
      mpShowWaitingPopup(`${(tk('mp.duel_match_of')||'PARTIDO {0} DE 5').replace('{0}', String(idx+1))}<br><span style="font-size:12px;font-weight:normal">${tk('mp.duel_waiting_strategy')||'Esperando la estrategia del rival...'}</span>`);
      mpWatchForMatchResult();
    }else{
      // Aún no he elegido estrategia para este partido
      mpShowStrategyAndBenchPhase();
    }
  }catch(e){
    console.error('initDuelModeFromSession error:',e);
    startDuelDraftTimer(); // fallback: mostrar el temporizador igualmente
  }
}

/* Salir de modo duelo (usado ante error o duelo cancelado/inexistente) */
function mpExitDuelMode(){
  try{ sessionStorage.removeItem('g2g_duel_active'); }catch(e){}
  try{ sessionStorage.removeItem('g2g_pending_challenge_id'); }catch(e){}
  window._duelId=null;
  if(_duelTimerInterval){ clearInterval(_duelTimerInterval); _duelTimerInterval=null; }
  stopDuelInactivityMonitor();
}

/* Barra de cuenta atrás del draft — visible en todo momento durante el
   draft/banquillo cuando hay un duelo activo. Al agotarse, autocompleta
   con el mismo método que EQUIPO RÁPIDO (quickBuild), sin duplicarlo. */
function startDuelDraftTimer(){
  let bar=document.getElementById('duelDraftTimerBar');
  if(!bar){
    bar=document.createElement('div');
    bar.id='duelDraftTimerBar';
    bar.style.cssText='position:fixed;left:0;right:0;z-index:70000;background:#1a2a3a;border-bottom:2px solid #4a90d9;color:#7ec3ff;text-align:center;padding:6px 10px;font-family:"Bebas Neue",Impact,sans-serif;letter-spacing:1px;font-size:15px;display:flex;align-items:center;justify-content:center;gap:14px';
    const span=document.createElement('span');
    span.id='duelDraftTimerText';
    const exitLink=document.createElement('span');
    exitLink.id='duelDraftExitLink';
    exitLink.textContent=tk('mp.duel_exit')||'ABANDONAR ENCUENTRO';
    exitLink.style.cssText='cursor:pointer;color:#ff7e7e;font-size:12px;border:1px solid #d94a4a;padding:2px 8px;border-radius:3px';
    exitLink.addEventListener('click', mpAbandonDuel);
    bar.appendChild(span);
    bar.appendChild(exitLink);
    document.body.appendChild(bar);
  }
  mpAttachStickyBarScroll('duelDraftTimerBar');
  const textEl=document.getElementById('duelDraftTimerText')||bar;
  bar.style.display='flex';
  const tick=()=>{
    const msLeft=window._duelDraftDeadline-Date.now();
    if(msLeft<=0){
      textEl.textContent=(tk('mp.duel_draft_time_up')||'⏱️ ¡Tiempo agotado! Completando equipo automáticamente...');
      clearInterval(_duelTimerInterval);
      _duelTimerInterval=null;
      if(phase==='draft'||phase==='bench') quickBuild();
      return;
    }
    const s=Math.ceil(msLeft/1000);
    checkCountdownBeep(s, 'duelDraftBar');
    const mm=Math.floor(s/60), ss=s%60;
    textEl.textContent=(tk('mp.duel_draft_time')||'⏱️ Construye tu equipo: {0}:{1}')
      .replace('{0}', String(mm)).replace('{1}', String(ss).padStart(2,'0'));
  };
  tick();
  _duelTimerInterval=setInterval(tick,1000);
}

/* Se ejecuta cuando MI draft/banquillo ha terminado (manual o por tiempo
   agotado). Serializa mi plantilla y la guarda en el duelo. */
async function mpOnDraftComplete(){
  if(_duelTimerInterval){ clearInterval(_duelTimerInterval); _duelTimerInterval=null; }
  const bar=document.getElementById('duelDraftTimerBar');
  if(bar) bar.style.display='none';
  mpDetachStickyBarScroll('duelDraftTimerBar');
  // En modo duelo startMatchPhase() no se ejecuta, así que este botón no
  // se oculta por el camino normal — lo ocultamos aquí explícitamente.
  const qb=document.getElementById("quickBuildWrap");
  if(qb) qb.style.display="none";
  const db=window._fbDb;
  if(!db||!window._duelId) return;
  const squad={
    pitch: usedPlayers.map(p=>({name:p.name, rating:p.rating, positions:p.positions, placedPos:p.placedPos, fatigue:(p.fatigue===undefined?100:p.fatigue)})),
    bench: bench.map(p=>({name:p.name, rating:p.rating, positions:p.positions})),
    formation: currentFormation,
    teamOVR: typeof baseTeamOVR!=='undefined'?baseTeamOVR:computeTeamOVR(),
    // Foto del perfil táctico real (attack/defense/pace/passing/technique),
    // ya calculado a partir de las selecciones históricas fichadas + formación.
    // Se usará tal cual como perfil del rival real en los partidos del duelo.
    teamStats:{...teamStats},
    // Foto de moral y racha en el momento de terminar el equipo — se
    // actualizarán partido a partido con las mismas fórmulas que en solitario.
    // La racha es por jugador (scorerStreaks), no un número único de equipo.
    teamMorale: (typeof teamMorale!=='undefined')?teamMorale:0,
    scorerStreaks: usedPlayers.reduce((acc,p)=>{ if(scorerStreaks[p.name]) acc[p.name]=scorerStreaks[p.name]; return acc; },{}),
    skills: window._skillCache?{...window._skillCache}:{}
  };
  const readyField=window._duelRole==='challenger'?'challengerReady':'opponentReady';
  const squadField=window._duelRole==='challenger'?'challengerSquad':'opponentSquad';
  try{
    await db.collection('duels').doc(window._duelId).update({
      [squadField]: squad,
      [readyField]: true
    });
  }catch(e){
    console.error('mpOnDraftComplete error:',e);
  }
  mpShowDuelWaitingScreen();
}

/* Pantalla de espera mientras el rival termina su equipo. Escucha el
   duelo en tiempo real; cuando ambos están listos, Fase 3 (motor de
   partidos) tomará el relevo desde aquí. */
function mpShowDuelWaitingScreen(){
  mpShowDuelOverlay(`
    <i class="ph ph-bold ph-users" style="font-size:34px;color:#7b9cff;display:block;margin-bottom:10px"></i>
    <div style="font-family:'Bebas Neue',Impact,sans-serif;font-size:17px;letter-spacing:.5px;margin-bottom:16px" id="duelWaitingText">${tk('mp.duel_waiting')||'Esperando a que tu rival termine su equipo...'}</div>
    <button id="duelExitBtn" style="width:100%;padding:10px 22px;background:#3a1a1a;border:1px solid #d94a4a;color:#ff7e7e;font-family:'Bebas Neue',Impact,sans-serif;font-size:13px;letter-spacing:1px;border-radius:4px;cursor:pointer">${tk('mp.duel_exit')||'ABANDONAR ENCUENTRO'}</button>`);
  const exitBtn=document.getElementById('duelExitBtn');
  if(exitBtn) exitBtn.addEventListener('click', mpAbandonDuel);
  const db=window._fbDb;
  if(!db||!window._duelId) return;
  const unsub=db.collection('duels').doc(window._duelId).onSnapshot(snap=>{
    const d=snap.data();
    if(!d) return;
    if(d.status==='cancelled'){
      // El rival ha salido del duelo — liberar y volver al juego normal
      unsub();
      mpExitDuelMode();
      location.reload();
      return;
    }
    if(d.challengerReady && d.opponentReady){
      if(window._duelMatchesStarted) return; // evita disparar dos veces
      window._duelMatchesStarted=true;
      unsub();
      mpHideDuelOverlay(); // si no, se queda tapando la rueda de prensa/estrategia
      window._duelMatchIndex=0;
      mpShowStrategyAndBenchPhase();
      return;
    }
  }, e=>console.error('mpShowDuelWaitingScreen error:',e));
}

/* Salir voluntariamente de un duelo (desde la pantalla de espera).
   Marca el duelo como cancelado para que el rival también salga. */
async function mpAbandonDuel(){
  playSound('select');
  const db=window._fbDb;
  if(db&&window._duelId){
    try{ await db.collection('duels').doc(window._duelId).update({status:'cancelled'}); }
    catch(e){ console.error('mpAbandonDuel error:',e); }
  }
  mpExitDuelMode();
  location.reload();
}

// Wiring directo (sin depender de DOMContentLoaded, que ya puede haberse disparado
// para cuando este script se ejecuta vía document.write con cache-busting)
(function(){
  const mpBtn=document.getElementById('multiplayerBtn');
  if(mpBtn) mpBtn.addEventListener('click', window.openMpOverlay);
  const addBtn=document.getElementById('mpAddFriendBtn');
  if(addBtn) addBtn.addEventListener('click', mpAddFriend);
  const input=document.getElementById('mpFriendInput');
  if(input) input.addEventListener('keydown', e=>{ if(e.key==='Enter') mpAddFriend(); });
})();
// Delegación de respaldo: garantiza el click incluso si el listener directo
// no llegó a engancharse a tiempo (timing de carga del script).
document.addEventListener('click', e=>{
  if(e.target && e.target.id==='multiplayerBtn') window.openMpOverlay();
});

// Aplicar traducciones al cargar
document.addEventListener('DOMContentLoaded',()=>{
  if(window.applyTranslations) window.applyTranslations();
});
